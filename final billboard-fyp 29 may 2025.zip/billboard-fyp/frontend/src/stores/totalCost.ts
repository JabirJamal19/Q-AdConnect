import { create } from "zustand";

interface PaymentDetails {
  billboardTitle: string;
  duration: number;
  startDate: string;
  endDate: string;
  ratePerDay: number;
  total: number;
}

interface TotalCostStore {
  paymentDetails: PaymentDetails | null;
  setPaymentDetails: (details: PaymentDetails) => void;
  clearPaymentDetails: () => void;
}

export const useTotalCostStore = create<TotalCostStore>((set) => ({
  paymentDetails: null,
  setPaymentDetails: (details) => {
    // Validate numbers before setting
    const validDetails = {
      ...details,
      duration: isNaN(details.duration) ? 0 : details.duration,
      ratePerDay: isNaN(details.ratePerDay) ? 0 : details.ratePerDay,
      total: isNaN(details.total) ? 0 : details.total,
    };

    console.log("Setting payment details:", validDetails);
    set({ paymentDetails: validDetails });
  },
  clearPaymentDetails: () => set({ paymentDetails: null }),
}));
