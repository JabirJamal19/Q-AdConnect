import { create } from "zustand";

interface AuthState {
  user: any | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (token: string, user: any) => void;
  logout: () => void;
  setAuth: (user: any, token: string) => void;
  clearAuth: () => void;
  updateUserName: (name: string) => void;
}


const getUserFromStorage = () => {
  const userStr = localStorage.getItem("user");
  if (userStr) {
    try {
      return JSON.parse(userStr);
    } catch (e) {
      console.error("Error parsing user from localStorage:", e);
      return null;
    }
  }
  return null;
};

export const useAuthStore = create<AuthState>((set) => {
 
  const storedUser = getUserFromStorage();
  const storedToken = localStorage.getItem("token");
  const initialIsAuthenticated = !!storedToken;


  console.log("AuthStore initial state:", {
    user: storedUser,
    token: storedToken ? "[TOKEN EXISTS]" : null,
    isAuthenticated: initialIsAuthenticated
  });

  return {
    user: storedUser,
    token: storedToken,
    isAuthenticated: initialIsAuthenticated,

    login: (token, user) => {
      const cleanToken = token.replace("Bearer ", "");
      localStorage.setItem("token", cleanToken);
      localStorage.setItem("user", JSON.stringify(user));

      
      console.log("AuthStore login:", {
        user: user ? { ...user, role: user.role } : null,
        token: cleanToken ? "[TOKEN SET]" : null,
        isAuthenticated: true
      });

      set({ user, token: cleanToken, isAuthenticated: true });
    },

  logout: () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    console.log("AuthStore logout: clearing auth state");
    set({ user: null, token: null, isAuthenticated: false });
  },

  setAuth: (user, token) => {
    const cleanToken = token.replace("Bearer ", "");
    localStorage.setItem("token", cleanToken);
    localStorage.setItem("user", JSON.stringify(user));
    console.log("AuthStore setAuth:", {
      user: user ? { ...user, role: user.role } : null,
      token: cleanToken ? "[TOKEN SET]" : null
    });
    set({ user, token: cleanToken, isAuthenticated: true });
  },

  clearAuth: () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    console.log("AuthStore clearAuth: clearing auth state");
    set({ user: null, token: null, isAuthenticated: false });
  },

  updateUserName: (name) =>
    set((state) => {
      const updatedUser = state.user ? { ...state.user, name } : null;
      if (updatedUser) {
        localStorage.setItem("user", JSON.stringify(updatedUser));
        console.log("AuthStore updateUserName:", { name, updatedUser });
      }
      return { user: updatedUser };
    }),
  };
});
