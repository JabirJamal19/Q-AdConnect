import { create } from "zustand";
import { persist } from "zustand/middleware";

interface BookingDetails {
  total: number;
  duration: number;
  ratePerDay: number;
  startDate: string;
  endDate: string;
  billboardTitle: string;
  bookingId: string | null;
}

interface BookingStore {
  bookingDetails: BookingDetails | null;
  setBookingContextForPayment: (details: BookingDetails) => void;
  clearBookingContext: () => void;
}

export const useBookingStore = create<BookingStore>()(
  persist(
    (set) => ({
      bookingDetails: null,
      setBookingContextForPayment: (details) =>
        set({ bookingDetails: details }),
      clearBookingContext: () => set({ bookingDetails: null }),
    }),
    {
      name: "booking-storage", 
    }
  )
);
