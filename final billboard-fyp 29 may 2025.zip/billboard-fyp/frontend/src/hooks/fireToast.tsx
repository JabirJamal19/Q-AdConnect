import toast from "react-hot-toast";

interface AlertSetting {
  id: string;
  value: string | number;
  criterion: string;
  para: string;
  type: string;
}

interface DataJSON {
  [key: string]: {
    [key: string]: number;
  };
}

// Assume dataJSON is defined elsewhere
declare const dataJSON: DataJSON;

const createToast = (title: string, message: string, type: string) => {
  toast.custom((t) => (
    <div
      className={`max-w-md w-full ${
        type === "0"
          ? "bg-green-600"
          : type === "1"
            ? "bg-yellow-600"
            : "bg-red-600"
      } shadow-lg rounded-lg flex ring-1 ring-black ring-opacity-5 ${
        t.visible ? "animate-enter" : "animate-leave"
      }`}
    >
      <div className="flex-1 p-4">
        <p className="text-sm font-medium text-white">{title}</p>
        <p className="mt-1 text-sm text-white">{message}</p>
      </div>
      <button
        onClick={() => toast.dismiss(t.id)}
        className="p-4 text-white hover:opacity-50 focus:outline-none"
        aria-label="Close"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M6 18L18 6M6 6l12 12"
          />
        </svg>
      </button>
    </div>
  ));
};

const getConditionMessage = (
  criterion: string,
  para: string,
  id: string,
  value: number,
  realValue: number
): string => {
  const messages = {
    "0": `${para} of ${id} goes down by ${realValue}`,
    "1": `${para} of ${id} goes up by ${realValue}`,
    "2": `${para} of ${id} is smaller than ${realValue}`,
    "3": `${para} of ${id} is greater than ${realValue}`,
    "4": `${para} of ${id} is equal to ${realValue}`,
  };
  return messages[criterion] || messages["4"];
};

const evaluateCondition = (
  criterion: string,
  value: number,
  dataValue: number
): boolean => {
  switch (criterion) {
    case "0":
      return value <= -dataValue;
    case "1":
    case "3":
      return value >= dataValue;
    case "2":
      return value <= dataValue;
    default:
      return value === dataValue;
  }
};

const fireToast = () => {
  const alertSettings = localStorage.getItem("alertSettings");
  if (!alertSettings) return;

  const settings: AlertSetting[] = JSON.parse(alertSettings);

  settings.forEach((setting) => {
    const value =
      typeof setting.value === "string"
        ? parseFloat(setting.value)
        : setting.value;
    if (isNaN(value)) return;

    const para =
      setting.criterion < "2" ? `delta_${setting.para}` : setting.para;

    if (setting.id === "ALL") {
      Object.keys(dataJSON).forEach((id) => {
        const dataValue = dataJSON[id][para];
        const realValue = setting.criterion === "0" ? -dataValue : dataValue;

        if (evaluateCondition(setting.criterion, value, dataValue)) {
          createToast(
            id,
            getConditionMessage(
              setting.criterion,
              setting.para,
              id,
              value,
              realValue
            ),
            setting.type
          );
        }
      });
    } else {
      const dataValue = dataJSON[setting.id][para];
      const realValue = setting.criterion === "0" ? -dataValue : dataValue;

      if (evaluateCondition(setting.criterion, value, dataValue)) {
        createToast(
          setting.id,
          getConditionMessage(
            setting.criterion,
            setting.para,
            setting.id,
            value,
            realValue
          ),
          setting.type
        );
      }
    }
  });
};

export default fireToast;
