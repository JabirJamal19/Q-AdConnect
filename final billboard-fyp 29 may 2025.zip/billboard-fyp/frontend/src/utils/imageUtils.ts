
export const getImageUrl = (url?: string | null): string => {
  console.log("getImageUrl called with:", url);

  if (!url) {
    console.log("No URL provided, returning default placeholder");
    return "/qadconnect.png";
  }

  
  if (url.startsWith("http://") || url.startsWith("https://")) {
    console.log("URL is already absolute, returning as is");
    return url;
  }


  if (url.match(/\d{13,}/) && !url.includes("placeholder")) {
    console.log("Using placeholder for timestamped image:", url);
    return "/qadconnect.png";
  }

  
  const baseUrl = window.location.origin;

  
  const cleanUrl = url.startsWith("/") ? url.substring(1) : url;

  const fullUrl = `${baseUrl}/${cleanUrl}`;
  console.log("Constructed image URL:", fullUrl);

  return fullUrl;
};


export const handleImageError = (
  event: React.SyntheticEvent<HTMLImageElement, Event>,
  fallbackUrl: string = "/qadconnect.png"
): void => {
  const img = event.currentTarget;

  
  if (img.dataset.retried === "true") {
    img.src = fallbackUrl;
    return;
  }

  img.dataset.retried = "true";


  console.log("Image load error:", {
    originalSrc: img.src,
    fallbackUrl: fallbackUrl,
    element: img.alt || "unnamed image",
  });

  console.log("Setting fallback image:", fallbackUrl);
  img.src = fallbackUrl;
};
