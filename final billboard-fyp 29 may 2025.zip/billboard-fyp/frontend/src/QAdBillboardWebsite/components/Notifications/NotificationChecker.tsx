import { useEffect } from "react";
import axios from "../../../axiosInstance";
import { useAuthStore } from "../../../stores/authStore";
import { useNotificationStore } from "../../../stores/notificationStore";
import { useBookingStore } from "../../../stores/bookingStore";

/**
 * Component that periodically checks for notifications
 * This component doesn't render anything, it just runs side effects
 */
const NotificationChecker = () => {
  const { isAuthenticated, token, user } = useAuthStore();
  const { addNotification } = useNotificationStore();
  // We use the booking store but don't need the details directly
  useBookingStore();

  // Only run notification checks for customer users
  const isCustomer = user?.role === "customer";

  // Check for content approval notifications
  useEffect(() => {
    if (!isAuthenticated || !token || !isCustomer) return;

    // Function to check for bookings with content_approved status
    const checkContentApproval = async () => {
      try {
        const response = await axios.get(
          "/api/booking/my-bookings?status=content_approved",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (response.data.status === 1 && response.data.data.length > 0) {
          // For each content_approved booking, create a notification if we haven't already
          response.data.data.forEach((booking: any) => {
            // Check if we've already notified about this booking
            const notificationKey = `content_approved_${booking._id}`;
            if (!localStorage.getItem(notificationKey)) {
              // Create notification
              addNotification({
                title: "Content Approved",
                message: `Great news! Your content for "${booking.billboardId.title}" has been approved by the agency. Please proceed with payment to continue.`,
                type: "success",
                link: `/payment/${booking._id}`,
                bookingId: booking._id,
              });

              // Mark as notified
              localStorage.setItem(notificationKey, "true");
            }
          });
        }
      } catch (error) {
        console.error("Error checking for content approval:", error);
      }
    };

    // Check immediately on mount
    checkContentApproval();

    // Then check periodically
    const interval = setInterval(checkContentApproval, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [isAuthenticated, token, addNotification, isCustomer]);

  // Check for payment verification notifications
  useEffect(() => {
    if (!isAuthenticated || !token || !isCustomer) return;

    // Function to check for bookings with payment_verified status
    const checkPaymentVerification = async () => {
      try {
        const response = await axios.get(
          "/api/booking/my-bookings?status=payment_verified,paid",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (response.data.status === 1 && response.data.data.length > 0) {
          // For each payment_verified booking, create a notification if we haven't already
          response.data.data.forEach((booking: any) => {
            // Check if we've already notified about this booking
            const notificationKey = `payment_verified_${booking._id}`;
            if (!localStorage.getItem(notificationKey)) {
              // Create notification
              addNotification({
                title:
                  booking.status === "payment_verified"
                    ? "Payment Verified"
                    : "Payment Received",
                message:
                  booking.status === "payment_verified"
                    ? `Your payment for "${booking.billboardId.title}" has been verified by the agency. Your billboard will be activated soon.`
                    : `Your payment for "${booking.billboardId.title}" has been received and is awaiting verification by the agency.`,
                type: "success",
                link: `/user-booking`,
                bookingId: booking._id,
              });

              // Mark as notified
              localStorage.setItem(notificationKey, "true");
            }
          });
        }
      } catch (error) {
        console.error("Error checking for payment verification:", error);
      }
    };

    // Check immediately on mount
    checkPaymentVerification();

    // Then check periodically
    const interval = setInterval(checkPaymentVerification, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [isAuthenticated, token, addNotification, isCustomer]);

  // Check for rejected content notifications
  useEffect(() => {
    if (!isAuthenticated || !token || !isCustomer) return;

    // Function to check for bookings with rejected content
    const checkRejectedContent = async () => {
      try {
        const response = await axios.get(
          "/api/booking/my-bookings?status=content_rejected,content_rejected_resubmit",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (response.data.status === 1 && response.data.data.length > 0) {
          // For each rejected content booking, create a notification if we haven't already
          response.data.data.forEach((booking: any) => {
            // Check if we've already notified about this booking
            const notificationKey = `content_rejected_${booking._id}`;
            if (!localStorage.getItem(notificationKey)) {
              // Create notification
              addNotification({
                title: "Content Rejected",
                message: `Your content for "${booking.billboardId.title}" has been rejected. ${booking.status === "content_rejected_resubmit" ? "You can resubmit new content." : ""}`,
                type: "error",
                link: `/user-booking`,
                bookingId: booking._id,
              });

              // Mark as notified
              localStorage.setItem(notificationKey, "true");
            }
          });
        }
      } catch (error) {
        console.error("Error checking for rejected content:", error);
      }
    };

    // Check immediately on mount
    checkRejectedContent();

    // Then check periodically
    const interval = setInterval(checkRejectedContent, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [isAuthenticated, token, addNotification, isCustomer]);

  // Check for billboard activation notifications
  useEffect(() => {
    if (!isAuthenticated || !token || !isCustomer) return;

    // Function to check for bookings with live status
    const checkBillboardActivation = async () => {
      try {
        const response = await axios.get(
          "/api/booking/my-bookings?status=live",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (response.data.status === 1 && response.data.data.length > 0) {
          // For each live booking, create a notification if we haven't already
          response.data.data.forEach((booking: any) => {
            // Check if we've already notified about this booking
            const notificationKey = `billboard_activated_${booking._id}`;
            if (!localStorage.getItem(notificationKey)) {
              // Create notification
              addNotification({
                title: "Billboard Activated",
                message: `Congratulations! Your billboard "${booking.billboardId.title}" has been set live by the agency. Your advertising campaign has officially started.`,
                type: "success",
                link: `/user-booking`,
                bookingId: booking._id,
              });

              // Mark as notified
              localStorage.setItem(notificationKey, "true");
            }
          });
        }
      } catch (error) {
        console.error("Error checking for billboard activation:", error);
      }
    };

    // Check immediately on mount
    checkBillboardActivation();

    // Then check periodically
    const interval = setInterval(checkBillboardActivation, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [isAuthenticated, token, addNotification, isCustomer]);

  // Check for payment rejection notifications
  useEffect(() => {
    if (!isAuthenticated || !token || !isCustomer) return;

    // Function to check for bookings with rejected payment
    const checkPaymentRejection = async () => {
      try {
        const response = await axios.get(
          "/api/booking/my-bookings?status=payment_rejected,payment_rejected_resubmit",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        if (response.data.status === 1 && response.data.data.length > 0) {
          // For each rejected payment booking, create a notification if we haven't already
          response.data.data.forEach((booking: any) => {
            // Check if we've already notified about this booking
            const notificationKey = `payment_rejected_${booking._id}`;
            if (!localStorage.getItem(notificationKey)) {
              // Create notification
              addNotification({
                title: "Payment Rejected",
                message: `Your payment for "${booking.billboardId.title}" has been rejected. ${booking.status === "payment_rejected_resubmit" ? "You can resubmit payment." : ""}`,
                type: "error",
                link: `/payment/${booking._id}${booking.status === "payment_rejected_resubmit" ? "?resubmit=true" : ""}`,
                bookingId: booking._id,
              });

              // Mark as notified
              localStorage.setItem(notificationKey, "true");
            }
          });
        }
      } catch (error) {
        console.error("Error checking for rejected payment:", error);
      }
    };

    // Check immediately on mount
    checkPaymentRejection();

    // Then check periodically
    const interval = setInterval(checkPaymentRejection, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [isAuthenticated, token, addNotification, isCustomer]);

  return null; // This component doesn't render anything
};

export default NotificationChecker;
