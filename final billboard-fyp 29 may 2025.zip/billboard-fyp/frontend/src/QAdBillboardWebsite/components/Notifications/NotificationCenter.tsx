import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { 
  FaBell, 
  FaCheckCircle, 
  FaInfoCircle, 
  FaExclamationTriangle, 
  FaTimesCircle,
  FaCheck,
  FaTrash,
  FaRegBell
} from "react-icons/fa";
import { useNotificationStore, Notification } from "../../../stores/notificationStore";

interface NotificationCenterProps {
  isScrolled: boolean;
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({ isScrolled }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { 
    notifications, 
    unreadCount, 
    markAsRead, 
    markAllAsRead, 
    removeNotification, 
    clearAllNotifications 
  } = useNotificationStore();
  const navigate = useNavigate();
  const notificationRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleNotificationClick = (notification: Notification) => {
    markAsRead(notification.id);
    
    if (notification.link) {
      navigate(notification.link);
      setIsOpen(false);
    }
  };

  const getNotificationIcon = (type: Notification["type"]) => {
    switch (type) {
      case "success":
        return <FaCheckCircle className="text-green-500" />;
      case "info":
        return <FaInfoCircle className="text-blue-500" />;
      case "warning":
        return <FaExclamationTriangle className="text-yellow-500" />;
      case "error":
        return <FaTimesCircle className="text-red-500" />;
      default:
        return <FaInfoCircle className="text-blue-500" />;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

    if (diffInMinutes < 60) {
      return `${diffInMinutes} min${diffInMinutes !== 1 ? 's' : ''} ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <div ref={notificationRef} className="relative">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className={`relative p-2 rounded-full ${
          isScrolled
            ? "text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)] dark:text-[var(--color-text-light)] dark:hover:bg-[var(--color-bg-tertiary)]"
            : "text-[var(--color-text-light)] hover:bg-white/10"
        }`}
        aria-label="Notifications"
      >
        {unreadCount > 0 ? (
          <>
            <FaBell className="h-5 w-5" />
            <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          </>
        ) : (
          <FaRegBell className="h-5 w-5" />
        )}
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute right-0 mt-2 w-80 max-h-[80vh] overflow-hidden bg-[var(--color-bg-primary)] dark:bg-[var(--color-bg-secondary)] rounded-xl shadow-xl border border-[var(--color-border-light)] dark:border-[var(--color-border-medium)] z-50"
          >
            <div className="p-3 border-b border-[var(--color-border-light)] dark:border-[var(--color-border-medium)] flex justify-between items-center">
              <h3 className="font-semibold text-[var(--color-text-primary)] dark:text-[var(--color-text-light)]">
                Notifications
              </h3>
              <div className="flex space-x-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-xs px-2 py-1 rounded bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors flex items-center"
                    title="Mark all as read"
                  >
                    <FaCheck className="mr-1 h-3 w-3" />
                    <span>Read all</span>
                  </button>
                )}
                {notifications.length > 0 && (
                  <button
                    onClick={clearAllNotifications}
                    className="text-xs px-2 py-1 rounded bg-red-100 text-red-700 hover:bg-red-200 transition-colors flex items-center"
                    title="Clear all notifications"
                  >
                    <FaTrash className="mr-1 h-3 w-3" />
                    <span>Clear</span>
                  </button>
                )}
              </div>
            </div>
            
            <div className="overflow-y-auto max-h-[60vh]">
              {notifications.length === 0 ? (
                <div className="py-8 text-center text-[var(--color-text-muted)]">
                  <FaRegBell className="mx-auto h-8 w-8 mb-2 opacity-50" />
                  <p>No notifications yet</p>
                </div>
              ) : (
                <div className="divide-y divide-[var(--color-border-light)] dark:divide-[var(--color-border-medium)]">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-3 hover:bg-[var(--color-bg-secondary)] dark:hover:bg-[var(--color-bg-tertiary)] transition-colors ${
                        !notification.isRead ? "bg-blue-50 dark:bg-blue-900/10" : ""
                      }`}
                    >
                      <div className="flex">
                        <div className="flex-shrink-0 mr-3 mt-1">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 cursor-pointer" onClick={() => handleNotificationClick(notification)}>
                          <div className="flex justify-between items-start">
                            <h4 className="font-medium text-[var(--color-text-primary)] dark:text-[var(--color-text-light)]">
                              {notification.title}
                            </h4>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                removeNotification(notification.id);
                              }}
                              className="text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] dark:hover:text-[var(--color-text-light)] ml-2"
                            >
                              &times;
                            </button>
                          </div>
                          <p className="text-sm text-[var(--color-text-secondary)] dark:text-[var(--color-text-muted)]">
                            {notification.message}
                          </p>
                          <div className="mt-1 text-xs text-[var(--color-text-muted)]">
                            {formatDate(notification.createdAt)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default NotificationCenter;
