import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../../../axiosInstance";
import BillboardCard from "../BillboardCard/FeaturedBillboards";

const FeaturedBillboards: React.FC = () => {
  const [billboards, setBillboards] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBillboards = async () => {
      try {
        const response = await axios.get("/api/billboard/public/list");
        if (response.data?.status === 1) {
          setBillboards(response.data.data.slice(0, 3)); // Show only first 3 billboards
        }
      } catch (error) {
        console.error("Error fetching billboards:", error);
      }
    };

    fetchBillboards();
  }, []);

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {billboards.map((billboard) => (
            <BillboardCard
              key={billboard._id}
              billboard={billboard}
              onClick={() => navigate(`/billboards/${billboard._id}`)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedBillboards;
