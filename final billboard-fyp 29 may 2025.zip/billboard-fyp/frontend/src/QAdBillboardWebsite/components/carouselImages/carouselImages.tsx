"use client";

import { Carousel } from "../../../components/ui";
import { motion } from "framer-motion";
import { HiChevronLeft, HiChevronRight } from "react-icons/hi2";

const CarouselImages = () => {
  // Array of professional billboard images
  const billboardImages = [
    {
      url: "https://images.unsplash.com/photo-1580670029149-5c00eec8bb66?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      alt: "Digital Billboard in City Night",
      caption: "Digital Advertising in Urban Landscape",
    },
    {
      url: "https://images.unsplash.com/photo-1628275656863-7f9583d880f3?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      alt: "Times Square Billboards",
      caption: "Premium Advertising Locations",
    },
    {
      url: "https://images.unsplash.com/photo-1616276323789-fc4b1c0b258a?q=80&w=1568&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      alt: "Modern LED Billboard Display",
      caption: "High-Impact Digital Displays",
    },
    {
      url: "https://images.unsplash.com/photo-1551383616-a9e150c07fca?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      alt: "Interactive Billboard Installation",
      caption: "Engaging Outdoor Media",
    },
    {
      url: "https://images.unsplash.com/photo-1613172322748-ef2456e19282?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      alt: "Smart City Billboard",
      caption: "Next-Generation Advertising Solutions",
    },
  ];

  // Custom controls with brand colors
  const customLeftControl = (
    <div className="group">
      <span className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg group-hover:from-purple-700 group-hover:to-blue-700 transition-all duration-300">
        <HiChevronLeft className="w-6 h-6 text-white" />
      </span>
    </div>
  );

  const customRightControl = (
    <div className="group">
      <span className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg group-hover:from-blue-700 group-hover:to-purple-700 transition-all duration-300">
        <HiChevronRight className="w-6 h-6 text-white" />
      </span>
    </div>
  );

  return (
    <section className="py-20 bg-gradient-to-b from-gray-100 to-white overflow-hidden">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="container mx-auto px-4"
      >
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4 relative inline-block">
            <span className="relative z-10">Featured Billboards</span>
            <span className="absolute -bottom-2 left-0 right-0 h-3 bg-gradient-to-r from-purple-400 to-blue-500 opacity-30 rounded-full"></span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our premium collection of digital and traditional
            billboards strategically located across prime locations
          </p>
        </div>

        {/* Carousel Container with enhanced styling */}
        <div className="relative mx-auto max-w-7xl">
          {/* Decorative elements */}
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-purple-500/10 rounded-full blur-xl animate-pulse" />
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-500/10 rounded-full blur-xl animate-pulse" />

          {/* Glass effect container */}
          <div className="relative backdrop-blur-sm bg-white/5 p-2 sm:p-3 md:p-4 rounded-2xl shadow-2xl overflow-hidden border border-white/10">
            {/* Enhanced Carousel */}
            <Carousel
              slideInterval={5000}
              className="rounded-xl overflow-hidden"
              indicators={true}
              indicatorType="line"
              effect="fade"
              height="h-[30rem] sm:h-[35rem] xl:h-[40rem] 2xl:h-[45rem]"
              leftControl={customLeftControl}
              rightControl={customRightControl}
            >
              {billboardImages.map((image, index) => (
                <div key={index} className="relative h-full group">
                  {/* Image with zoom effect on hover */}
                  <div className="absolute inset-0 overflow-hidden rounded-lg">
                    <img
                      src={image.url}
                      alt={image.alt}
                      className="object-cover w-full h-full transform transition-transform duration-10000 group-hover:scale-110"
                    />
                  </div>

                  {/* Enhanced caption overlay with animation */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-6 sm:p-8 md:p-10 transform transition-transform duration-500 translate-y-0">
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2, duration: 0.5 }}
                    >
                      <h3 className="text-white text-2xl sm:text-3xl font-bold mb-2">
                        {image.caption}
                      </h3>
                      <p className="text-white/80 text-sm sm:text-base max-w-2xl">
                        Premium advertising space available for your brand's
                        next campaign
                      </p>
                      <div className="mt-4 hidden sm:block">
                        <button className="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-full text-sm font-medium hover:from-purple-700 hover:to-blue-700 transition-all duration-300 shadow-lg">
                          Learn More
                        </button>
                      </div>
                    </motion.div>
                  </div>
                </div>
              ))}
            </Carousel>
          </div>
        </div>
      </motion.div>
    </section>
  );
};

export default CarouselImages;
