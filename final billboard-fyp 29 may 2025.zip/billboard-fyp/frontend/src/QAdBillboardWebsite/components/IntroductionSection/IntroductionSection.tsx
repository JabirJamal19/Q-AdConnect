import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { FaBullhorn, FaCogs, FaChartLine } from "react-icons/fa";

// Main Page that renders the three distinct sections
const IntroductionSection: React.FC = () => {
  return (
    <div className="space-y-0">
      <InfoCTASection />
      <FeaturesSection />
      <HeroSection />
    </div>
  );
};

// SECTION 1: HERO SECTION
const HeroSection: React.FC = () => {
  const navigate = useNavigate();

  return (
    <section
      className="relative h-screen flex items-center justify-center bg-cover bg-center"
      style={{
        backgroundImage:
          "url('https://www.vistarmedia.com/hubfs/Blog-Audit-Creative-v1-5.jpg')",
      }}
    >
      {/* Overlay for darker background */}
      <div className="absolute inset-0 bg-black opacity-60"></div>
      <div className="relative z-10 text-center px-4">
        <motion.h1
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-6xl font-extrabold text-white drop-shadow-2xl"
        >
          Experience the Future of Digital Advertising
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-6 text-lg md:text-2xl text-blue-100 max-w-2xl mx-auto"
        >
          Welcome to Q_AdConnect, your ultimate solution for managing, tracking,
          and creating impactful digital billboards.
        </motion.p>
        <motion.button
          onClick={() => navigate("/billboard-list")}
          whileHover={{ scale: 1.05 }}
          className="mt-10 px-8 py-4 bg-white text-[var(--color-brand-primary)] font-bold rounded-lg shadow-lg transition-transform duration-300"
        >
          View Billboards
        </motion.button>
      </div>
    </section>
  );
};

// SECTION 2: FEATURES SECTION
const FeaturesSection: React.FC = () => {
  const features = [
    {
      Icon: FaBullhorn,
      title: "Effortless Setup",
      description:
        "Kickstart your campaigns instantly with intuitive tools and customizable templates.",
    },
    {
      Icon: FaCogs,
      title: "Smart Management",
      description:
        "Manage multiple billboards effortlessly with advanced scheduling and real-time updates.",
    },
    {
      Icon: FaChartLine,
      title: "Data-Driven Insights",
      description:
        "Monitor campaign performance with comprehensive analytics and actionable insights.",
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <motion.h2
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl font-bold text-[var(--color-brand-primary)] mb-12"
        >
          Key Features
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={index} {...feature} />
          ))}
        </div>
      </div>
    </section>
  );
};

// Individual Feature Card Component
const FeatureCard: React.FC<{
  Icon: React.ElementType;
  title: string;
  description: string;
}> = ({ Icon, title, description }) => {
  return (
    <motion.div
      whileHover={{
        scale: 1.05,
        boxShadow: "0px 10px 30px rgba(0,0,0,0.2)",
      }}
      className="bg-white p-8 rounded-lg shadow-md border border-gray-200 transition-transform"
    >
      <div className="w-16 h-16 rounded-full bg-[var(--color-brand-primary)] flex items-center justify-center text-white text-2xl mx-auto mb-4">
        <Icon />
      </div>
      <h3 className="text-xl font-semibold mb-2 text-center">{title}</h3>
      <p className="text-gray-600 text-center">{description}</p>
    </motion.div>
  );
};

// SECTION 3: INFORMATION & CALL-TO-ACTION SECTION
const InfoCTASection: React.FC = () => {
  const navigate = useNavigate();

  return (
    <section className="py-20 bg-[var(--color-brand-primary)] text-white">
      <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center gap-8">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="flex-1"
        >
          <h3 className="text-3xl font-bold mb-4">Why Choose Q_AdConnect?</h3>
          <p className="text-lg mb-4">
            We prioritize simplicity, innovation, and efficiency to ensure your
            advertising campaigns make an impact. Join thousands of businesses
            already transforming their marketing strategies.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="flex-1"
        >
          <h3 className="text-3xl font-bold mb-4">Cutting-Edge Technology</h3>
          <p className="text-lg mb-4">
            Leverage our state-of-the-art tools to design visually stunning
            content, monitor your ROI, and optimize campaigns like never before.
          </p>
          <motion.button
            onClick={() => navigate("/auth")}
            whileHover={{ scale: 1.05 }}
            className="mt-4 px-8 py-4 bg-white text-[var(--color-brand-primary)] font-bold rounded-lg shadow-md transition-transform duration-300"
          >
            Get Started
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default IntroductionSection;
