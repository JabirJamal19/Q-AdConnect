import { motion } from "framer-motion";
import { FaMapMarkerAlt, FaDollarSign, FaRegClock } from "react-icons/fa";

interface BillboardCardProps {
  billboard: {
    id: string;
    title: string;
    location: string;
    price: number;
    imageUrl: string;
    availability: string;
  };
  onClick: () => void;
}

const BillboardCard: React.FC<BillboardCardProps> = ({
  billboard,
  onClick,
}) => {
  return (
    <motion.div
      whileHover={{ y: -8 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-[var(--color-bg-primary)] rounded-xl shadow-lg overflow-hidden cursor-pointer"
      onClick={onClick}
    >
      <div className="relative h-48">
        <img
          src={billboard.imageUrl}
          alt={billboard.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4">
          <span className="bg-[var(--color-brand-accent)] text-[var(--color-text-light)] px-3 py-1 rounded-full text-sm">
            Available
          </span>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-semibold text-[var(--color-text-primary)] mb-2">
          {billboard.title}
        </h3>

        <div className="space-y-2">
          <div className="flex items-center text-[var(--color-text-secondary)]">
            <FaMapMarkerAlt className="mr-2" />
            <span>{billboard.location}</span>
          </div>

          <div className="flex items-center text-[var(--color-text-secondary)]">
            <FaDollarSign className="mr-2" />
            <span>PKR {billboard.price}/day</span>
          </div>

          <div className="flex items-center text-[var(--color-text-secondary)]">
            <FaRegClock className="mr-2" />
            <span>{billboard.availability}</span>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full mt-6 bg-[var(--color-brand-primary)] text-[var(--color-text-light)] py-2 rounded-lg"
        >
          Book Now
        </motion.button>
      </div>
    </motion.div>
  );
};

export default BillboardCard;
