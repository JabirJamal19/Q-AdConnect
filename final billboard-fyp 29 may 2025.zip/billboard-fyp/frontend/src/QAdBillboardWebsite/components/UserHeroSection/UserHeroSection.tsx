import { motion } from "framer-motion";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../../../stores/authStore";

const FALLBACK_IMAGE =
  "https://images.unsplash.com/photo-1526680209043-b726aec1c86a?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";

const UserHeroSection: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();

  const videos = ["WNRuxOL81hg", "RYNydFG5Z0o", "CKQoXx6pqAA", "xAfQ7oxduF4"];
  const [currentVideo, setCurrentVideo] = useState(0);

  // Auto-switch videos every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentVideo((prevIndex) => (prevIndex + 1) % videos.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [videos.length]);

  return (
    <section className="hero-section relative w-full h-[100vh] md:h-[90vh] flex flex-col md:flex-row items-center overflow-hidden">
      {/* Background Image with subtle zoom */}
      <motion.div
        className="hero-background absolute inset-0 w-full h-full"
        initial={{ scale: 1.1 }}
        animate={{ scale: 1 }}
        transition={{ duration: 10, ease: "easeOut" }}
        style={{
          backgroundImage: `url(${FALLBACK_IMAGE})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          filter: "brightness(0.8)",
        }}
      />

      {/* Gradient Overlay */}
      <div className="hero-overlay absolute inset-0 bg-gradient-to-r from-[var(--color-brand-primary)]/80 via-[var(--color-brand-primary)]/60 to-transparent" />

      {/* Content Container */}
      <div className="hero-content relative z-10 w-full max-w-screen-xl mx-auto px-4 md:px-8 flex items-center h-full">
        <div className="content-left w-full md:w-3/5">
          <motion.div
            className="text-container space-y-4 md:space-y-8"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            {/* Subtitle */}
            <motion.p
              className="hero-subtitle text-base md:text-xl tracking-wide mt-12 text-white font-semibold"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              Digital Advertising Made Simple
            </motion.p>

            {/* Main Title */}
            <h1 className="hero-title text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
              Revolutionize Your{" "}
              <span className="highlight-text text-transparent bg-clip-text bg-white">
                Advertising
              </span>{" "}
              with{" "}
              <motion.span
                className="brand-name relative text-[var(--color-brand-primary)] font-extrabold text-4xl sm:text-5xl md:text-6xl
  bg-gradient-to-r from-yellow-400 via-orange-500 to-red-600 bg-clip-text text-transparent
  shadow-[0px_2px_4px_rgba(255,165,0,0.4),0px_4px_10px_rgba(255,69,0,0.6)] tracking-wide"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                whileHover={{
                  textShadow:
                    "0px 5px 15px rgba(255, 215, 0, 1), 0px 8px 25px rgba(255, 140, 0, 0.8)",
                  scale: 1.1,
                }}
              >
                Q_AdConnect
              </motion.span>
            </h1>

            {/* Description */}
            <p className="hero-description text-base md:text-xl text-blue-50 max-w-xl leading-relaxed">
              Transform your brand visibility with our premium billboard
              locations and smart advertising solutions.
            </p>

            {/* Action Buttons */}
            <div className="hero-buttons flex flex-col sm:flex-row gap-3 md:gap-4 pt-4">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate("/billboard-list")}
                className="btn-primary px-6 py-3 md:px-8 md:py-4 bg-white text-[var(--color-brand-primary)] font-bold rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl text-sm md:text-base hover:text-white"
              >
                View Billboards
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() =>
                  isAuthenticated
                    ? navigate("/billboard-list")
                    : navigate("/auth")
                }
                className="btn-secondary px-6 py-3 md:px-8 md:py-4 bg-transparent border-2 border-white text-white font-bold rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl text-sm md:text-base"
              >
                Book Now
              </motion.button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default UserHeroSection;
