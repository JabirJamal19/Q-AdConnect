import { useState, useEffect } from 'react';
import YouTube from 'react-youtube';

const VideoSlider = ({ videos, fallbackImage }: any) => {
  const [currentVideo, setCurrentVideo] = useState(0);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [showFallback, setShowFallback] = useState(true);

  // Handle when the video is ready
  const handleVideoReady = () => {
    // Start playing the video, then hide the fallback after 2 seconds
    setTimeout(() => {
      setShowFallback(false); // Hide the fallback image
      setVideoLoaded(true); // Mark the video as loaded

      // After 3 seconds of video play, move to the next video
      setTimeout(() => {
        setCurrentVideo((prev) => (prev + 1) % videos.length);
      }, 3000); // 3 seconds to display the video before moving to the next
    }, 2000); // Show fallback for 2 seconds before showing the video
  };

  // Handle state changes of the video (e.g., video ended)
  const handleVideoStateChange = (event: any) => {
    if (event.data === 0) {
      // Video ended
      setVideoLoaded(false); // Reset video loaded state
      setShowFallback(true); // Show fallback image when the video ends
    }
  };

  return (
    <div className="relative w-full h-full">
      {/* Persistent Text Overlay */}
      <div className="absolute top-0 left-0 w-full py-3 bg-yellow-500 text-center text-black font-bold z-10">
        <span className="text-lg">Welcome to the Q_AdConnect 🎥</span>
      </div>

      {/* Video Slider */}
      <div className="absolute top-0 left-0 w-full h-full z-0">
        {videos.map((video: any, index: any) => (
          <div
            key={index}
            className={`absolute inset-0 w-full h-[calc(100vw*(9/16))] transition-opacity duration-1000 ${
              currentVideo === index ? 'opacity-100' : 'opacity-0'
            }`}
          >
            {/* Show fallback image for 2 seconds before video starts */}
            {(!videoLoaded || showFallback) && (
              <div
                className="w-full h-full bg-cover bg-center"
                style={{ backgroundImage: `url(${fallbackImage})` }}
              ></div>
            )}

            <YouTube
              videoId={video}
              opts={{
                height: '100%',
                width: '100%',
                playerVars: {
                  autoplay: 1,
                  mute: 1,
                  controls: 0,
                  loop: 1,
                  playlist: video,
                },
              }}
              onReady={handleVideoReady} // Set video loaded state when ready
              onStateChange={handleVideoStateChange} // Handle video state changes (e.g., when video ends)
              className="absolute top-0 left-0 w-full h-full object-cover"
              style={{ pointerEvents: 'none' }} // Disable interactions with the video
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default VideoSlider;
