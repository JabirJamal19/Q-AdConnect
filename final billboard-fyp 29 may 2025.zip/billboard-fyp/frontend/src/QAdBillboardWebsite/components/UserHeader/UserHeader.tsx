// website users header
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuthStore } from "../../../stores/authStore";
import axios from "../../../axiosInstance";
import {
  FaHome,
  FaClipboardList,
  FaFileAlt,
  FaHeadset,
  FaUser,
  FaSignOutAlt,
  FaCog,
  FaBars,
  FaTimes,
  FaSignInAlt,
} from "react-icons/fa";
import NotificationCenter from "../Notifications/NotificationCenter";

const UserHeader: React.FC = () => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const { isAuthenticated, user, login, logout } = useAuthStore();
  const [isScrolled, setIsScrolled] = useState(false);

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Fetch user data
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (isAuthenticated && token) {
      axios
        .get("/api/user/me", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        .then((response) => {
          if (response.data?.user) {
            const { name, email, role } = response.data.user;
            login(token, { name, email, role });
          }
        })
        .catch((error) => {
          console.error("Failed to fetch user data:", error);
          if (
            error.response?.status === 401 ||
            error.response?.status === 403
          ) {
            logout();
            localStorage.removeItem("token");
            if (window.location.pathname === "/profile") {
              navigate("/auth/signin");
            }
          }
        });
    }
  }, [isAuthenticated, login, logout, navigate]);

  const handleNavigation = (path: string) => {
    if (path === "/profile" && !isAuthenticated) {
      navigate("/auth/signin");
      return;
    }
    setMenuOpen(false);
    setDropdownOpen(false);
    navigate(path);
  };

  const handleLogout = () => {
    logout();
    localStorage.removeItem("token");
    navigate("/");
    setDropdownOpen(false);
  };

  const menuItems = [
    { name: "Home", path: "/", icon: FaHome },
    { name: "Billboards", path: "/billboard-list", icon: FaClipboardList },
    ...(isAuthenticated
      ? [{ name: "Reports", path: "/report-page", icon: FaFileAlt }]
      : []),
  ];

  // Click outside handler for dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest(".user-dropdown")) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed w-full z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-[var(--color-bg-primary)] shadow-lg dark:bg-[var(--color-bg-secondary)]"
            : "bg-[var(--color-brand-primary)]"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="flex items-center space-x-3 cursor-pointer"
              onClick={() => handleNavigation("/")}
            >
              <img
                src="/qadconnect.png"
                alt="Logo"
                className="h-10 w-10 rounded-lg shadow-md"
              />
              <span
                className={`text-2xl font-bold ${
                  isScrolled
                    ? "text-[var(--color-text-primary)] dark:text-[var(--color-text-light)]"
                    : "text-[var(--color-text-light)]"
                }`}
              >
                Q_AdConnect
              </span>
            </motion.div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-2">
              {menuItems.map((item) => (
                <motion.button
                  key={item.path}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleNavigation(item.path)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isScrolled
                      ? "text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)] dark:text-[var(--color-text-light)] dark:hover:bg-[var(--color-bg-tertiary)]"
                      : "text-[var(--color-text-light)] hover:bg-white/10"
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </motion.button>
              ))}
            </nav>

            {/* Auth Buttons - Desktop */}
            <div className="hidden md:flex items-center space-x-4">
              {isAuthenticated ? (
                <>
                  <NotificationCenter isScrolled={isScrolled} />
                  <div className="relative user-dropdown">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setDropdownOpen(!dropdownOpen)}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                        isScrolled
                          ? "bg-[var(--color-bg-secondary)] text-[var(--color-text-primary)] hover:bg-[var(--color-bg-tertiary)] dark:bg-[var(--color-bg-tertiary)] dark:text-[var(--color-text-light)]"
                          : "bg-white/10 text-[var(--color-text-light)] hover:bg-white/20"
                      }`}
                    >
                      <FaUser className="h-4 w-4" />
                      <span className="font-medium">{user?.name}</span>
                    </motion.button>

                  <AnimatePresence>
                    {dropdownOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute right-0 mt-2 w-64 bg-[var(--color-bg-primary)] dark:bg-[var(--color-bg-secondary)] rounded-xl shadow-xl border border-[var(--color-border-light)] dark:border-[var(--color-border-medium)] overflow-hidden"
                      >
                        <div className="p-4 border-b border-[var(--color-border-light)] dark:border-[var(--color-border-medium)]">
                          <p className="font-semibold text-[var(--color-text-primary)] dark:text-[var(--color-text-light)]">
                            {user?.name}
                          </p>
                          <p className="text-sm text-[var(--color-text-muted)]">
                            {user?.email}
                          </p>
                        </div>
                        <div className="py-2">
                          <button
                            onClick={() => handleNavigation("/profile")}
                            className="w-full flex items-center space-x-3 px-4 py-3 text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)] dark:text-[var(--color-text-light)] dark:hover:bg-[var(--color-bg-tertiary)] transition-colors"
                          >
                            <FaUser className="h-4 w-4" />
                            <span>Profile</span>
                          </button>
                          <button
                            onClick={() => handleNavigation("/user-booking")}
                            className="w-full flex items-center space-x-3 px-4 py-3 text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)] dark:text-[var(--color-text-light)] dark:hover:bg-[var(--color-bg-tertiary)] transition-colors"
                          >
                            <FaFileAlt className="h-4 w-4" />
                            <span>Booking & Live Billboards</span>
                          </button>
                          <button
                            onClick={handleLogout}
                            className="w-full flex items-center space-x-3 px-4 py-3 text-[var(--color-error)] hover:bg-[var(--color-bg-tertiary)] transition-colors"
                          >
                            <FaSignOutAlt className="h-4 w-4" />
                            <span>Logout</span>
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  </div>
                </>
              ) : (
                <div className="flex items-center space-x-3">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleNavigation("/auth/signin")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                      isScrolled
                        ? "bg-[var(--color-bg-secondary)] text-[var(--color-text-primary)] hover:bg-[var(--color-bg-tertiary)] dark:bg-[var(--color-bg-tertiary)] dark:text-[var(--color-text-light)]"
                        : "bg-white/10 text-[var(--color-text-light)] hover:bg-white/20"
                    }`}
                  >
                    Login
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleNavigation("/auth/signup")}
                    className="px-4 py-2 rounded-lg text-sm font-medium bg-[var(--color-brand-accent)] text-[var(--color-text-light)] hover:bg-[var(--color-brand-accent)] transition-all duration-200"
                  >
                    Sign Up
                  </motion.button>
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className={`md:hidden p-2 rounded-lg ${
                isScrolled
                  ? "text-[var(--color-text-primary)] dark:text-[var(--color-text-light)]"
                  : "text-[var(--color-text-light)]"
              }`}
            >
              {menuOpen ? (
                <FaTimes className="h-6 w-6" />
              ) : (
                <FaBars className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-x-0 top-16 z-40 md:hidden bg-[var(--color-bg-primary)] dark:bg-[var(--color-bg-secondary)] border-t border-[var(--color-border-light)] dark:border-[var(--color-border-medium)] shadow-lg"
          >
            <div className="p-4 space-y-4">
              {menuItems.map((item) => (
                <button
                  key={item.path}
                  onClick={() => handleNavigation(item.path)}
                  className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)] dark:text-[var(--color-text-light)] dark:hover:bg-[var(--color-bg-tertiary)] transition-colors"
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </button>
              ))}
              {isAuthenticated ? (
                <>
                  <button
                    onClick={() => handleNavigation("/user-booking")}
                    className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)] dark:text-[var(--color-text-light)] dark:hover:bg-[var(--color-bg-tertiary)] transition-colors"
                  >
                    <FaFileAlt className="h-5 w-5" />
                    <span>Booking & Live Billboards</span>
                  </button>
                  <button
                    onClick={() => handleNavigation("/profile")}
                    className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)] dark:text-[var(--color-text-light)] dark:hover:bg-[var(--color-bg-tertiary)] transition-colors"
                  >
                    <FaUser className="h-5 w-5" />
                    <span>Profile</span>
                  </button>
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-[var(--color-error)] hover:bg-[var(--color-bg-tertiary)] transition-colors"
                  >
                    <FaSignOutAlt className="h-5 w-5" />
                    <span>Logout</span>
                  </button>
                </>
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={() => handleNavigation("/auth/signin")}
                    className="w-full flex items-center justify-center space-x-2 px-4 py-3 rounded-lg text-[var(--color-text-primary)] hover:bg-[var(--color-bg-secondary)] dark:text-[var(--color-text-light)] dark:hover:bg-[var(--color-bg-tertiary)] transition-colors"
                  >
                    <FaSignInAlt className="h-5 w-5" />
                    <span>Login</span>
                  </button>
                  <button
                    onClick={() => handleNavigation("/auth/signup")}
                    className="w-full flex items-center justify-center space-x-2 px-4 py-3 rounded-lg bg-[var(--color-brand-accent)] text-[var(--color-text-light)] hover:bg-[var(--color-brand-accent)] transition-colors"
                  >
                    <FaUser className="h-5 w-5" />
                    <span>Sign Up</span>
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default UserHeader;
