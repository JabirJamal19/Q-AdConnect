import { motion } from "framer-motion";

const Hero = () => {
  return (
    <div className="bg-[var(--color-bg-secondary)] min-h-[80vh] flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-5xl lg:text-6xl font-bold text-[var(--color-text-primary)] leading-tight mb-6">
              Transform Your
              <span className="text-[var(--color-brand-primary)]">
                {" "}
                Advertising{" "}
              </span>
              Impact
            </h1>

            <p className="text-[var(--color-text-secondary)] text-xl mb-8">
              Connect with your audience through premium billboard locations
              across the city. Smart, digital, and effective advertising
              solutions.
            </p>

            <div className="flex space-x-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-[var(--color-brand-primary)] text-[var(--color-text-light)] px-8 py-3 rounded-lg"
              >
                Get Started
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border-2 border-[var(--color-brand-primary)] text-[var(--color-brand-primary)] px-8 py-3 rounded-lg"
              >
                Learn More
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-w-16 aspect-h-9 rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://media.licdn.com/dms/image/v2/D5612AQEHJonSZjqUXg/article-cover_image-shrink_720_1280/article-cover_image-shrink_720_1280/0/1657569420782?e=2147483647&v=beta&t=JO3IUkR9jRLKbReWbOcZWQixDPEeN3TGHdMWXACbU-s"
                alt="Digital Billboard"
                className="object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
