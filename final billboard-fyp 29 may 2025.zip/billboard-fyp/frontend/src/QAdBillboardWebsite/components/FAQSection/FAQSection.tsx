"use client";
import { useState } from "react";
import { Plus, Minus } from "lucide-react";
import { Link } from "react-router-dom";

const faqs = [
  {
    question: "How does digital billboard advertising work?",
    answer:
      "Digital billboard advertising allows you to display dynamic content on high-resolution LED screens. You can schedule your ads, update content remotely, and even run multiple campaigns simultaneously. Our platform makes it easy to manage your digital billboard campaigns from anywhere.",
  },
  {
    question: "What types of billboards do you offer?",
    answer:
      "We offer various types of billboards including premium digital LED displays, traditional static billboards, and strategic location-based advertising spaces. All our billboards are situated in high-traffic areas to maximize visibility and impact.",
  },
  {
    question: "How do I track my billboard campaign's performance?",
    answer:
      "Our platform provides comprehensive analytics including viewer metrics, engagement rates, and ROI tracking. You can access real-time data about your campaign's performance and make data-driven decisions to optimize your advertising strategy.",
  },
  {
    question: "What are your pricing models?",
    answer:
      "We offer flexible pricing options based on factors like location, duration, and type of billboard. You can choose from hourly slots, daily rates, or long-term contracts. Contact our team for a customized quote that fits your advertising budget.",
  },
  {
    question: "Can I update my billboard content remotely?",
    answer:
      "Yes! Our digital billboards support real-time content updates through our user-friendly platform. You can schedule changes, upload new designs, and manage multiple billboards from a single dashboard.",
  },
  {
    question: "What locations are available for billboard advertising?",
    answer:
      "We have premium billboard locations across major cities and high-traffic areas. Our network includes strategic spots near shopping centers, highways, business districts, and entertainment venues.",
  },
  {
    question: "How quickly can I start my billboard campaign?",
    answer:
      "Once your artwork is approved and the booking is confirmed, we can have your campaign live within 24-48 hours for digital billboards. The timeline may vary for traditional billboards.",
  },
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section className="bg-white py-12">
      <div className="max-w-6xl mx-auto rounded-lg shadow-lg p-0 lg:p-8 bg-gradient-to-r from-blue-50 to-white">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr,2fr] gap-8 lg:gap-12 bg-white p-8 rounded-xl">
          {/* Left Column */}
          <div className="flex flex-col justify-between h-full">
            <div>
              <span className="inline-block bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
                FAQs
              </span>

              <h2 className="text-4xl font-bold text-gray-900 mt-6 mb-4 leading-tight">
                Common Questions
                <br />
                <span className="text-blue-600">About Our Billboards</span>
              </h2>

              <p className="text-gray-600 mt-4">
                Everything you need to know about our digital billboard
                advertising platform
              </p>
            </div>

            <div className="mt-8 lg:mt-auto bg-gradient-to-r from-blue-50 to-white p-6 rounded-xl">
              <p className="font-bold text-xl text-gray-900">
                Still Have Questions?
              </p>
              <p className="text-gray-600 text-base mt-2">
                Our team is here to help!
              </p>
              <button className="mt-4 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white text-sm font-medium rounded-full hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
                <Link to="/report-page"> Report Issue 📞</Link>
              </button>
            </div>
          </div>

          {/* Right Column (FAQs) */}
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="border-b border-gray-100 last:border-0"
              >
                <button
                  className="w-full flex justify-between items-center py-4 text-left font-medium text-gray-900 hover:text-blue-600 transition-colors duration-200"
                  onClick={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                >
                  <span className="pr-4 text-lg">{faq.question}</span>
                  {openIndex === index ? (
                    <Minus size={20} className="text-blue-600 flex-shrink-0" />
                  ) : (
                    <Plus size={20} className="text-blue-600 flex-shrink-0" />
                  )}
                </button>

                {openIndex === index && (
                  <div className="pb-4 text-gray-600 text-base leading-relaxed animate-fadeIn">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
