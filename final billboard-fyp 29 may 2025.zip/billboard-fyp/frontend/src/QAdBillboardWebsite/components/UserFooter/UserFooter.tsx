import { motion } from "framer-motion";
import {
  FaFacebookF,
  FaTwitter,
  FaInstagram,
  FaEnvelope,
} from "react-icons/fa";

const UserFooter: React.FC = () => {
  return (
    <footer className="bg-gradient-to-br from-[#1E3A8A] to-[#3B82F6] text-white pt-16 pb-10 px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10 text-center md:text-left">
        {/* Brand & Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-center md:items-start"
        >
          <motion.img
            src="/qadconnect.png" // Replace with your actual logo
            alt="Q_AdConnect Logo"
            className="w-24 h-24 object-contain rounded-lg shadow-lg border-2 border-white"
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ duration: 0.4 }}
          />
          <h1 className="text-2xl font-bold mt-3">Q_AdConnect</h1>
          <p className="text-gray-300 text-sm mt-2">
            Revolutionizing Digital Billboard Advertising.
          </p>
        </motion.div>

        {/* Navigation Links */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-col space-y-3"
        >
          <h2 className="text-lg font-semibold text-gray-100 mb-2">
            Quick Links
          </h2>
          <a href="/" className="hover:text-blue-300 transition duration-300">
            Home
          </a>
          <a
            href="/billboard-list"
            className="hover:text-blue-300 transition duration-300"
          >
            Billboards
          </a>
          <a
            href="/report-page"
            className="hover:text-blue-300 transition duration-300"
          >
            Report
          </a>
          <a
            href="/profile"
            className="hover:text-blue-300 transition duration-300"
          >
            Dashboard
          </a>
        </motion.div>

        {/* Contact & Social Media */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col items-center md:items-start"
        >
          <h2 className="text-lg font-semibold text-gray-100 mb-3">
            Get in Touch
          </h2>
          <motion.a
            href="mailto:QAdConnect25@gmail.com"
            className="flex items-center gap-2 text-gray-300 hover:text-blue-300 transition duration-300"
            whileHover={{ scale: 1.1 }}
          >
            <FaEnvelope className="text-lg" /> QAdConnect25@gmail.com
          </motion.a>

          {/* Social Media Icons */}
          <div className="flex space-x-6 mt-4">
            {[
              { icon: FaFacebookF, url: "#facebook", color: "#1877F2" },
              { icon: FaTwitter, url: "#twitter", color: "#1DA1F2" },
              { icon: FaInstagram, url: "#instagram", color: "#E4405F" },
            ].map(({ icon: Icon, url, color }, index) => (
              <motion.a
                key={index}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{
                  scale: 1.2,
                  color: color,
                  textShadow: `0px 0px 10px ${color}`,
                }}
                transition={{ duration: 0.3 }}
                className="text-xl"
              >
                <Icon />
              </motion.a>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Bottom Copyright */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.6 }}
        className="mt-10 border-t border-white/20 pt-6 text-center text-sm text-gray-300"
      >
        &copy; {new Date().getFullYear()} Q_AdConnect. All Rights Reserved.
      </motion.div>
    </footer>
  );
};

export default UserFooter;
