import React from 'react';
import { motion } from 'framer-motion';
import CountUp from 'react-countup';

const statistics = [
  {
    value: 500,
    label: "Active Billboards",
    suffix: "+",
  },
  {
    value: 1000,
    label: "Successful Campaigns",
    suffix: "+",
  },
  {
    value: 98,
    label: "Client Satisfaction",
    suffix: "%",
  },
  {
    value: 50,
    label: "Cities Covered",
    suffix: "+",
  }
];

const StatisticsSection: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {statistics.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="text-center"
            >
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                <CountUp
                  end={stat.value}
                  duration={2.5}
                  suffix={stat.suffix}
                  enableScrollSpy
                  scrollSpyOnce
                />
              </div>
              <p className="text-blue-100 text-lg">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatisticsSection;