import React from "react";
import UserHeroSection from "./components/UserHeroSection/UserHeroSection";
import IntroductionSection from "./components/IntroductionSection/IntroductionSection";
import FAQSection from "./components/FAQSection/FAQSection";
import CarouselImages from "./components/carouselImages/carouselImages";
import StatisticsSection from "./components/StatisticsSection/StatisticsSection";
import TestimonialsSection from "./components/TestimonialsSection/TestimonialsSection";
import Hero from "./components/Hero/Hero";
import FeaturedBillboards from "./components/FeaturedBillboards/FeaturedBillboards";

const Homepage: React.FC = () => {
  return (
    <div className="w-full min-h-screen">
      <UserHeroSection />
      <IntroductionSection />
      <CarouselImages />
      <FeaturedBillboards />
      <StatisticsSection />
      <Hero />
      <TestimonialsSection />
      <FAQSection />
    </div>
  );
};

export default Homepage;
