// frontend/components/customer/UserProfileFixed.tsx
import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  FaUser,
  FaEdit,
  FaTimes,
  FaSync,
  FaCloudUploadAlt,
  FaCamera,
  FaEnvelope,
  FaPhone,
  FaMapMarkerAlt,
  FaCity,
  FaInfoCircle,
  FaListAlt, // Icon for bookings
} from "react-icons/fa";
import { useAuthStore } from "../../../stores/authStore";
import axiosInstance from "../../../axiosInstance";
import { toast } from "react-hot-toast";
import { motion, AnimatePresence } from "framer-motion";

// Define the structure for form data (consistent with backend update)
interface ProfileFormData {
  name: string;
  bio: string;
  phone: string;
  address: string;
  city: string;
}

// Define the User type based on your Mongoose schema (excluding sensitive fields like password, otp)
interface UserProfileData {
  _id: string;
  name: string;
  email: string;
  role: string;
  profileUrl?: string;
  bio?: string;
  phone?: string;
  address?: string;
  city?: string;
  agencyName?: string; // Added based on schema
  ntnNumber?: string; // Added based on schema
  // Add other relevant fields you might want to display
  createdAt: string; // Or Date
}

const UserProfile: React.FC = () => {
  const { token, user, setAuth } = useAuthStore(); // Use the user state which should match UserProfileData structure
  const navigate = useNavigate();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [profileForm, setProfileForm] = useState<ProfileFormData>({
    name: "", // Initialize empty, set when modal opens
    bio: "",
    phone: "",
    address: "",
    city: "",
  });
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(
    null
  );
  const [isSubmittingProfile, setIsSubmittingProfile] = useState(false);
  const [isSubmittingPassword, setIsSubmittingPassword] = useState(false);

  // Ref for the hidden file input
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Function to get full image URL
  const getFullImageUrl = (url?: string): string | null => {
    if (!url) return null;
    // Check if it's already an absolute URL (e.g., from cloud storage)
    if (url.startsWith("http://") || url.startsWith("https://")) {
      return url;
    }
    // Otherwise, assume it's a relative path from the backend server
    // Use the API URL from axiosInstance's baseURL
    const baseUrl = import.meta.env.VITE_API_URL || "http://localhost:4000";
    // If the URL starts with a slash, remove it to avoid double slashes
    const cleanUrl = url.startsWith("/") ? url.substring(1) : url;
    const fullUrl = `${baseUrl}/${cleanUrl}`;
    console.log("Image URL:", {
      original: url,
      cleaned: cleanUrl,
      full: fullUrl,
    });
    return fullUrl;
  };

  // Populate form and open modal
  const openEditModal = () => {
    if (!user) return;
    setProfileForm({
      name: user.name || "",
      bio: user.bio || "",
      phone: user.phone || "",
      address: user.address || "",
      city: user.city || "",
    });
    // Reset image state when opening modal, rely on current user profileUrl for initial display
    setProfileImage(null);
    setProfileImagePreview(null);
    setIsEditModalOpen(true);
  };

  // --- Profile Image Functions ---
  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) {
        // Max 5MB
        toast.error("Image size should be less than 5MB");
        return;
      }
      if (!file.type.match(/image\/(jpeg|jpg|png|gif|webp)/)) {
        toast.error("Only JPG, PNG, GIF, WEBP images are allowed");
        return;
      }
      setProfileImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Trigger hidden file input click
  const triggerFileSelect = () => fileInputRef.current?.click();

  // Open password modal
  const openPasswordModal = () => {
    setPasswordForm({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    });
    setIsPasswordModalOpen(true);
  };

  // Handle password update
  const handlePasswordUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !user) return;

    // Validate passwords
    if (!passwordForm.currentPassword) {
      toast.error("Current password is required");
      return;
    }
    if (!passwordForm.newPassword) {
      toast.error("New password is required");
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("New passwords do not match");
      return;
    }
    if (passwordForm.newPassword.length < 6) {
      toast.error("New password must be at least 6 characters");
      return;
    }

    setIsSubmittingPassword(true);

    try {
      // Store the user's email and role for login later
      const userEmail = user.email;
      const userRole = user.role;

      const response = await axiosInstance.post(
        "/api/auth/update-password",
        {
          password: passwordForm.currentPassword,
          newpassword: passwordForm.newPassword,
          confirmpassword: passwordForm.confirmPassword,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data.status === 1) {
        toast.success(
          "Password updated successfully! You will be redirected to login with your new password.",
          { duration: 5000 }
        );
        setIsPasswordModalOpen(false);

        // Clear password form
        setPasswordForm({
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        });

        // Log out the user properly using the auth store
        const { logout } = useAuthStore.getState();
        logout(); // This will clear the auth state and remove items from localStorage

        // Also clear any other potential stored data
        sessionStorage.clear(); // Clear session storage as well

        // Clear any axios default headers
        delete axiosInstance.defaults.headers.common["Authorization"];

        // Store login info in session storage temporarily
        sessionStorage.setItem(
          "tempLoginInfo",
          JSON.stringify({
            email: userEmail,
            role: userRole,
          })
        );

        // Redirect to login page after a delay to allow user to read the message
        setTimeout(() => {
          navigate("/auth/signin");
        }, 3500);
      } else {
        throw new Error(response.data.message || "Failed to update password");
      }
    } catch (error: any) {
      console.error("Password update error:", error);
      const message =
        error.response?.data?.message ||
        error.message ||
        "Failed to update password";
      toast.error(`Update failed: ${message}`);
    } finally {
      setIsSubmittingPassword(false);
    }
  };

  // --- Profile Update ---
  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !user) return;
    if (!profileForm.name.trim()) {
      toast.error("Name cannot be empty.");
      return;
    }
    setIsSubmittingProfile(true);
    try {
      const formData = new FormData();
      formData.append("name", profileForm.name);
      // Always append all fields, even if empty, to ensure they're updated in the database
      formData.append("bio", profileForm.bio || "");
      formData.append("phone", profileForm.phone || "");
      formData.append("address", profileForm.address || "");
      formData.append("city", profileForm.city || "");
      if (profileImage) {
        formData.append("profileImage", profileImage); // Backend expects 'profileImage'
      }

      console.log("Submitting profile update with form data:", {
        name: profileForm.name,
        bio: profileForm.bio,
        phone: profileForm.phone,
        address: profileForm.address,
        city: profileForm.city,
        hasImage: !!profileImage,
      });

      const response = await axiosInstance.put<{
        status: number;
        user: UserProfileData;
        message: string;
      }>("/api/user/update-profile", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      if (response.data.status === 1 && response.data.user) {
        // Log the response data
        console.log("Profile update response:", response.data);

        // Update zustand store with the full user object from response
        setAuth(response.data.user, token); // Pass the whole user object

        // Update local state to reflect changes immediately
        toast.success("Profile updated successfully!");
        setIsEditModalOpen(false);

        // Clean up image state after successful upload
        setProfileImage(null);
        setProfileImagePreview(null);

        // Force a refresh of the user data from the server
        await refreshUserData();

        // Also check localStorage to ensure it's updated
        const updatedUser = JSON.parse(localStorage.getItem("user") || "{}");
        console.log("Updated user from localStorage:", updatedUser);
      } else {
        throw new Error(response.data.message || "Failed to update profile");
      }
    } catch (error: any) {
      console.error("Update profile error:", error);
      const message =
        error.response?.data?.message ||
        error.message ||
        "Failed to update profile";
      toast.error(`Update failed: ${message}`);
    } finally {
      setIsSubmittingProfile(false);
    }
  };

  // Fallback Avatar
  const renderFallbackAvatar = (name: string = "User") => (
    <div className="w-full h-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-4xl lg:text-5xl font-semibold uppercase">
      {name?.charAt(0) || "?"}
    </div>
  );

  // Function to refresh user data from the server
  const refreshUserData = async () => {
    if (!token) return;

    try {
      console.log("Refreshing user data from server...");
      const response = await axiosInstance.get("/api/user/me", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.data.status === 1 && response.data.user) {
        console.log("User data refreshed successfully:", response.data.user);
        // Update the auth store with fresh user data
        setAuth(response.data.user, token);
      }
    } catch (error) {
      console.error("Failed to refresh user data:", error);
    }
  };

  // Refresh user data when component mounts
  useEffect(() => {
    if (token && user) {
      refreshUserData();
    }
  }, [token]);

  // --- Render Logic ---
  if (!user) {
    return (
      <div className="min-h-screen bg-gray-100 pt-28 pb-20 px-4 flex items-center justify-center">
        <div className="text-center bg-white p-10 rounded-lg shadow-xl">
          <FaUser className="mx-auto w-16 h-16 text-indigo-300 mb-6" />
          <p className="text-gray-600 mb-6 text-lg">
            Please sign in to view your profile.
          </p>
          <button
            onClick={() => navigate("/auth/signin")}
            className="px-8 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-md hover:shadow-lg"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  // Main Profile View
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 via-gray-100 to-blue-50 pt-20 sm:pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* --- Profile Card --- */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="bg-white rounded-xl shadow-xl overflow-hidden mb-8"
        >
          {/* Animated Banner Area */}
          <div className="h-40 md:h-48 relative overflow-hidden bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400">
            {/* Animated Background Elements */}
            <motion.div
              className="absolute inset-0 w-full h-full"
              style={{
                background:
                  "linear-gradient(120deg, rgba(99, 255, 251, 0.3), rgba(59, 130, 246, 0.3), rgba(147, 197, 253, 0.3))",
                backgroundSize: "400% 400%",
              }}
              animate={{
                backgroundPosition: ["0% 0%", "100% 100%"],
              }}
              transition={{
                duration: 15,
                repeat: Infinity,
                repeatType: "reverse",
                ease: "easeInOut",
              }}
            />

            {/* Floating Circles */}
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute rounded-full bg-white bg-opacity-20"
                style={{
                  width: Math.random() * 60 + 20,
                  height: Math.random() * 60 + 20,
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={{
                  x: [0, Math.random() * 40 - 20],
                  y: [0, Math.random() * 40 - 20],
                  opacity: [0.4, 0.7, 0.4],
                }}
                transition={{
                  duration: 3 + Math.random() * 5,
                  repeat: Infinity,
                  repeatType: "reverse",
                  ease: "easeInOut",
                }}
              />
            ))}

            {/* Animated Wave */}
            <svg
              className="absolute bottom-0 left-0 w-full"
              viewBox="0 0 1440 100"
              preserveAspectRatio="none"
            >
              <motion.path
                d="M0,50 C150,20 300,80 450,50 C600,20 750,80 900,50 C1050,20 1200,80 1440,50 L1440,100 L0,100 Z"
                fill="white"
                animate={{
                  d: [
                    "M0,50 C150,20 300,80 450,50 C600,20 750,80 900,50 C1050,20 1200,80 1440,50 L1440,100 L0,100 Z",
                    "M0,50 C150,80 300,20 450,50 C600,80 750,20 900,50 C1050,80 1200,20 1440,50 L1440,100 L0,100 Z",
                  ],
                }}
                transition={{
                  duration: 10,
                  repeat: Infinity,
                  repeatType: "reverse",
                  ease: "easeInOut",
                }}
              />
            </svg>

            {/* Optional: User's name as a subtle watermark */}
            <div className="absolute bottom-12 right-8 text-white text-opacity-20 text-4xl font-bold select-none pointer-events-none">
              {user.name?.split(" ")[0]}
            </div>
          </div>

          {/* Profile Header Section */}
          <div className="px-6 md:px-8 pb-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-end -mt-16 sm:-mt-20 space-y-4 sm:space-y-0 sm:space-x-6">
              {/* Profile Picture */}
              <div className="relative group flex-shrink-0">
                <div className="w-32 h-32 md:w-36 md:h-36 rounded-full overflow-hidden border-4 border-white shadow-lg bg-gray-200">
                  {user.profileUrl ? (
                    <img
                      src={getFullImageUrl(user.profileUrl) || ""}
                      alt={user.name || "Profile"}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        // In case the loaded image fails, replace with fallback
                        const target = e.currentTarget as HTMLImageElement;
                        const parent = target.parentElement;
                        if (parent) {
                          // Replace the img with the fallback avatar
                          parent.innerHTML = "";
                          // Create a simple fallback element
                          const fallbackDiv = document.createElement("div");
                          fallbackDiv.className =
                            "w-full h-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-4xl font-semibold uppercase";
                          fallbackDiv.textContent = user.name?.charAt(0) || "?";
                          parent.appendChild(fallbackDiv);
                        }
                      }}
                    />
                  ) : (
                    renderFallbackAvatar(user.name)
                  )}
                </div>
              </div>

              {/* Name, Role, Edit Button */}
              <div className="flex-grow text-center sm:text-left pt-4 sm:pt-0">
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
                  {user.name}
                </h1>
                <p className="text-sm text-indigo-600 font-medium capitalize">
                  {user.role}
                </p>
                {/* Display Agency Name if role is agency */}
                {user.role === "agency" && user.agencyName && (
                  <p className="text-sm text-gray-500 mt-1">
                    {user.agencyName}
                  </p>
                )}
              </div>

              {/* Edit Profile Button */}
              <button
                onClick={openEditModal}
                className="flex-shrink-0 mt-4 sm:mt-0 flex items-center px-5 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium shadow-md hover:shadow-lg"
              >
                <FaEdit className="mr-2" />
                Edit Profile
              </button>
            </div>

            {/* Bio Section (Moved here for better flow) */}
            {user.bio && (
              <div className="mt-6 border-t pt-4">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">
                  About Me
                </h3>
                <p className="text-gray-700 text-sm italic">"{user.bio}"</p>
              </div>
            )}
          </div>
        </motion.div>

        {/* --- Main Content Grid --- */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column (Personal Info) */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-xl p-6 md:p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-6 border-b pb-3">
              Personal Information
            </h2>
            <div className="space-y-5">
              <div className="flex items-start">
                <FaEnvelope className="w-5 h-5 text-indigo-500 mt-1 mr-4 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-500">Email</p>
                  <p className="text-sm font-medium text-gray-800">
                    {user.email}
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <FaPhone className="w-5 h-5 text-indigo-500 mt-1 mr-4 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-500">Phone</p>
                  <p className="text-sm font-medium text-gray-800">
                    {user.phone || (
                      <span className="text-gray-400 italic">Not provided</span>
                    )}
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <FaMapMarkerAlt className="w-5 h-5 text-indigo-500 mt-1 mr-4 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-500">Address</p>
                  <p className="text-sm font-medium text-gray-800">
                    {user.address || (
                      <span className="text-gray-400 italic">Not provided</span>
                    )}
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <FaCity className="w-5 h-5 text-indigo-500 mt-1 mr-4 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-500">City</p>
                  <p className="text-sm font-medium text-gray-800">
                    {user.city || (
                      <span className="text-gray-400 italic">Not provided</span>
                    )}
                  </p>
                </div>
              </div>
              {/* Show Agency specific details if applicable */}
              {user.role === "agency" && user.ntnNumber && (
                <div className="flex items-start">
                  <FaInfoCircle className="w-5 h-5 text-indigo-500 mt-1 mr-4 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-gray-500">NTN Number</p>
                    <p className="text-sm font-medium text-gray-800">
                      {user.ntnNumber}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column (Account Settings & Actions) */}
          <div className="lg:col-span-1 space-y-8">
            {/* Account Settings Card */}
            <div className="bg-white rounded-xl shadow-xl p-6 md:p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6 border-b pb-3">
                Account Settings
              </h2>
              <div className="space-y-4">
                {/* Change Password */}
                <div className="flex justify-between items-center p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors">
                  <div>
                    <h3 className="text-sm font-medium text-gray-800">
                      Change Password
                    </h3>
                    <p className="text-xs text-gray-500 mt-0.5">
                      Update your password
                    </p>
                  </div>
                  <button
                    onClick={openPasswordModal}
                    className="px-3 py-1.5 text-xs bg-indigo-100 text-indigo-700 font-semibold rounded-md hover:bg-indigo-200 transition-colors"
                  >
                    Change
                  </button>
                </div>
              </div>
            </div>

            {/* My Bookings Card */}
            <div className="bg-white rounded-xl shadow-xl p-6 md:p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6 border-b pb-3">
                My Activity
              </h2>
              <button
                onClick={() => navigate("/user-booking")} // Route to user booking page
                className="w-full flex items-center justify-center px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium shadow-md hover:shadow-lg"
              >
                <FaListAlt className="mr-2" />
                View My Bookings
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* --- Edit Profile Modal --- */}
      <AnimatePresence>
        {isEditModalOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4 backdrop-blur-sm"
            onClick={() => setIsEditModalOpen(false)} // Close on backdrop click
          >
            <div
              className="bg-white rounded-xl p-6 md:p-8 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside
            >
              <div className="flex justify-between items-center mb-6 border-b pb-3">
                <h2 className="text-xl font-bold text-gray-800">
                  Edit Profile
                </h2>
                <button
                  onClick={() => setIsEditModalOpen(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                  aria-label="Close modal"
                >
                  <FaTimes size={20} />
                </button>
              </div>

              <form onSubmit={handleProfileUpdate} className="space-y-5">
                {/* Profile Image Upload Section */}
                <div className="flex items-center space-x-5">
                  <div className="relative flex-shrink-0">
                    <div className="w-24 h-24 rounded-full overflow-hidden bg-gray-100 border-2 border-gray-200 shadow">
                      {profileImagePreview ? (
                        <img
                          src={profileImagePreview}
                          alt="Preview"
                          className="w-full h-full object-cover"
                        />
                      ) : user.profileUrl &&
                        getFullImageUrl(user.profileUrl) ? (
                        <img
                          src={getFullImageUrl(user.profileUrl) || ""}
                          alt="Current"
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.currentTarget as HTMLImageElement;
                            const parent = target.parentElement;
                            if (parent) {
                              parent.innerHTML = "";
                              const fallbackDiv = document.createElement("div");
                              fallbackDiv.className =
                                "w-full h-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-4xl font-semibold uppercase";
                              fallbackDiv.textContent =
                                user.name?.charAt(0) || "?";
                              parent.appendChild(fallbackDiv);
                            }
                          }}
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-4xl font-semibold uppercase">
                          {user.name?.charAt(0) || "?"}
                        </div>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={triggerFileSelect}
                      className="absolute -bottom-1 -right-1 bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-full shadow transition"
                      title="Change profile picture"
                    >
                      <FaCamera size={14} />
                    </button>
                  </div>

                  <div className="flex-grow">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Profile Picture
                    </label>
                    <button
                      type="button"
                      onClick={triggerFileSelect}
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition"
                    >
                      <FaCloudUploadAlt className="mr-2 -ml-1 h-5 w-5 text-gray-400" />
                      Upload Image
                    </button>
                    <input
                      ref={fileInputRef}
                      id="profile-image-upload"
                      type="file"
                      accept="image/jpeg,image/png,image/gif,image/webp"
                      onChange={handleProfileImageChange}
                      className="hidden" // Keep hidden, triggered by button
                    />
                    <p className="mt-1 text-xs text-gray-500">
                      JPG, PNG, GIF, WEBP (Max 5MB).
                    </p>
                  </div>
                </div>

                {/* Form Fields */}
                {/* Name */}
                <div>
                  <label
                    htmlFor="profile-name"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="profile-name"
                    type="text"
                    value={profileForm.name}
                    onChange={(e) =>
                      setProfileForm({ ...profileForm, name: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-sm"
                    placeholder="Your full name"
                    required
                  />
                </div>

                {/* Bio */}
                <div>
                  <label
                    htmlFor="profile-bio"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Bio
                  </label>
                  <textarea
                    id="profile-bio"
                    value={profileForm.bio}
                    onChange={(e) =>
                      setProfileForm({ ...profileForm, bio: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-sm min-h-[80px]"
                    placeholder="A short bio about yourself"
                    rows={3}
                  />
                </div>

                {/* Phone */}
                <div>
                  <label
                    htmlFor="profile-phone"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Phone
                  </label>
                  <input
                    id="profile-phone"
                    type="tel"
                    value={profileForm.phone}
                    onChange={(e) =>
                      setProfileForm({ ...profileForm, phone: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-sm"
                    placeholder="Your phone number"
                  />
                </div>

                {/* Address */}
                <div>
                  <label
                    htmlFor="profile-address"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Address
                  </label>
                  <input
                    id="profile-address"
                    type="text"
                    value={profileForm.address}
                    onChange={(e) =>
                      setProfileForm({
                        ...profileForm,
                        address: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-sm"
                    placeholder="Your street address"
                  />
                </div>

                {/* City */}
                <div>
                  <label
                    htmlFor="profile-city"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    City
                  </label>
                  <input
                    id="profile-city"
                    type="text"
                    value={profileForm.city}
                    onChange={(e) =>
                      setProfileForm({ ...profileForm, city: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-sm"
                    placeholder="Your city"
                  />
                </div>

                {/* Modal Actions */}
                <div className="flex justify-end space-x-3 pt-5 border-t mt-6">
                  <button
                    type="button"
                    onClick={() => setIsEditModalOpen(false)}
                    className="px-5 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm font-medium transition"
                    disabled={isSubmittingProfile}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 text-sm font-medium flex items-center justify-center min-w-[90px] transition shadow-md hover:shadow-lg disabled:opacity-60 disabled:cursor-not-allowed"
                    disabled={isSubmittingProfile}
                  >
                    {isSubmittingProfile ? (
                      <FaSync className="animate-spin" size={18} />
                    ) : (
                      "Save Changes"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* --- Change Password Modal --- */}
      <AnimatePresence>
        {isPasswordModalOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4 backdrop-blur-sm"
            onClick={() => setIsPasswordModalOpen(false)} // Close on backdrop click
          >
            <div
              className="bg-white rounded-xl p-6 md:p-8 w-full max-w-md shadow-2xl"
              onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside
            >
              <div className="flex justify-between items-center mb-6 border-b pb-3">
                <h2 className="text-xl font-bold text-gray-800">
                  Change Password
                </h2>
                <button
                  onClick={() => setIsPasswordModalOpen(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                  aria-label="Close modal"
                >
                  <FaTimes size={20} />
                </button>
              </div>

              <form onSubmit={handlePasswordUpdate} className="space-y-5">
                {/* Current Password */}
                <div>
                  <label
                    htmlFor="current-password"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Current Password <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="current-password"
                    type="password"
                    value={passwordForm.currentPassword}
                    onChange={(e) =>
                      setPasswordForm({
                        ...passwordForm,
                        currentPassword: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-sm"
                    placeholder="Enter your current password"
                    required
                  />
                </div>

                {/* New Password */}
                <div>
                  <label
                    htmlFor="new-password"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    New Password <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="new-password"
                    type="password"
                    value={passwordForm.newPassword}
                    onChange={(e) =>
                      setPasswordForm({
                        ...passwordForm,
                        newPassword: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-sm"
                    placeholder="Enter your new password"
                    required
                    minLength={6}
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Password must be at least 6 characters long.
                  </p>
                </div>

                {/* Confirm New Password */}
                <div>
                  <label
                    htmlFor="confirm-password"
                    className="block text-sm font-medium text-gray-700 mb-1"
                  >
                    Confirm New Password <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="confirm-password"
                    type="password"
                    value={passwordForm.confirmPassword}
                    onChange={(e) =>
                      setPasswordForm({
                        ...passwordForm,
                        confirmPassword: e.target.value,
                      })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-sm"
                    placeholder="Confirm your new password"
                    required
                  />
                </div>

                {/* Modal Actions */}
                <div className="flex justify-end space-x-3 pt-5 border-t mt-6">
                  <button
                    type="button"
                    onClick={() => setIsPasswordModalOpen(false)}
                    className="px-5 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm font-medium transition"
                    disabled={isSubmittingPassword}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 text-sm font-medium flex items-center justify-center min-w-[90px] transition shadow-md hover:shadow-lg disabled:opacity-60 disabled:cursor-not-allowed"
                    disabled={isSubmittingPassword}
                  >
                    {isSubmittingPassword ? (
                      <FaSync className="animate-spin" size={18} />
                    ) : (
                      "Update Password"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default UserProfile;
