// frontend/components/customer/BillboardDetail.tsx
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "../../../axiosInstance";
import { useAuthStore } from "../../../stores/authStore";
import {
  FaMapMarkerAlt,
  FaRuler,
  FaDollarSign,
  FaPhoneAlt,
  FaImage,
  FaTimesCircle,
  FaCheckCircle,
  FaSpinner, // Added Spinner
} from "react-icons/fa";
import { motion } from "framer-motion";
import { toast } from "react-hot-toast";
import { AnimatePresence } from "framer-motion";

// Interface for the Billboard data structure
interface Billboard {
  _id: string;
  title: string;
  description?: string;
  location: string;
  city?: string;
  area?: string;
  size: string;
  price: number; // Changed to number
  contact?: string;
  status: "active" | "inactive"; // Backend sends status
  imageUrl?: string;
  images?: string[]; // Array for gallery
  resolution?: string;
}

// Interface for the API response
interface ApiResponse {
  status: number;
  data: Billboard;
  message?: string;
}

const BillboardDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();
  const [billboard, setBillboard] = useState<Billboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null); // For error messages
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  useEffect(() => {
    const fetchBillboardDetails = async () => {
      if (!id) {
        toast.error("Billboard ID is missing.");
        navigate("/billboard-list"); // Use the correct list page route
        return;
      }
      setLoading(true);
      setError(null); // Clear previous error
      try {
        // --- *** Use the PUBLIC detail endpoint *** ---
        const response = await axios.get<ApiResponse>(
          `/api/billboard/public/detail/${id}` // Corrected endpoint
        );
        // --- *** END CORRECTION *** ---

        if (response.data?.status === 1 && response.data.data) {
          setBillboard(response.data.data);
          setSelectedImageIndex(0); // Reset image index
        } else {
          throw new Error(
            response.data?.message || "Billboard data not found in response."
          );
        }
      } catch (err: any) {
        console.error("Error fetching billboard details:", err);
        let message = "Failed to load billboard details.";
        if (err.code === "ERR_NETWORK") {
          message = "Unable to connect to the server.";
        } else if (err.response) {
          message =
            err.response.data?.message ||
            `Server Error: ${err.response.status}`;
          // If 404, set specific error and don't show generic toast
          if (err.response.status === 404) {
            setError("Billboard not found.");
            // No toast here, the component will render the not found state
            setLoading(false);
            return; // Exit early
          }
        } else if (err.message) {
          message = err.message;
        }
        setError(message); // Set error state for rendering
        toast.error(message); // Show general toast for other errors
      } finally {
        setLoading(false);
      }
    };

    fetchBillboardDetails();
  }, [id, navigate]);

  const handleBookNowClick = () => {
    // Check if billboard is active before allowing booking
    if (billboard?.status !== "active") {
      toast.error("This billboard is currently not available for booking.");
      return;
    }

    if (!isAuthenticated) {
      toast("Please sign in to book this billboard.", { icon: "🔑" }); // Use informative toast
      // Redirect to login, passing the intended destination
      navigate("/auth/signin", {
        state: { from: `/billboards/${id}/book` }, // Pass the booking page URL
      });
      return;
    }

    // If authenticated, proceed to booking page
    navigate(`/billboards/${id}/book`); // Correct booking route
  };

  // Determine images to display (handle single imageUrl and images array)
  const displayImages = billboard?.images?.length
    ? billboard.images
    : billboard?.imageUrl
      ? [billboard.imageUrl]
      : [];

  // Handle potential index out of bounds if billboard data changes
  const currentImageIndex = Math.min(
    selectedImageIndex,
    displayImages.length - 1
  );
  const currentImageUrl =
    displayImages[currentImageIndex >= 0 ? currentImageIndex : 0] ||
    "/placeholder-image.png"; // Default placeholder

  // --- Render States ---

  if (loading) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-100">
        <div className="flex flex-col items-center">
          <FaSpinner className="animate-spin text-4xl text-blue-600 mb-3" />
          <p className="text-gray-600">Loading Billboard Details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    // Render specific error message if fetch failed
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-100 px-4">
        <div className="text-center p-8 bg-white rounded-lg shadow-md max-w-md w-full">
          <FaTimesCircle className="mx-auto text-5xl text-red-500 mb-4" />
          <h2 className="text-2xl font-semibold text-gray-800 mb-3">
            {error === "Billboard not found."
              ? "Billboard Not Found"
              : "Error Loading Billboard"}
          </h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={() => navigate("/billboard-list")} // Correct list page route
            className="px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-opacity"
          >
            Back to Billboards
          </button>
        </div>
      </div>
    );
  }

  // Should not happen if error handling is correct, but as a fallback
  if (!billboard) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        Billboard data unavailable.
      </div>
    );
  }

  // --- Main Content Render ---

  const formattedPrice = new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(billboard.price || 0); // Handle potential undefined price briefly

  const isAvailable = billboard.status === "active";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen mt-16 bg-gray-50 py-12 px-4 sm:px-6 lg:px-8" // Use simpler background
    >
      <div className="max-w-6xl mx-auto">
        {" "}
        {/* Slightly wider max-width */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-0">
            {" "}
            {/* Changed grid ratio */}
            {/* Image Section (Takes 3 columns on large screens) */}
            <div className="lg:col-span-3 relative bg-gray-100">
              {displayImages.length > 0 ? (
                <>
                  {/* Main Image Display */}
                  <div className="relative aspect-w-16 aspect-h-9 lg:aspect-none lg:h-[600px]">
                    {" "}
                    {/* Fixed height on lg */}
                    <AnimatePresence mode="wait">
                      <motion.img
                        key={currentImageUrl} // Key change triggers animation
                        src={currentImageUrl}
                        alt={`${billboard.title} - View ${currentImageIndex + 1}`}
                        className="w-full h-full object-contain lg:object-cover absolute inset-0" // Use contain for better visibility
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        onError={(e) => {
                          e.currentTarget.src = "/placeholder-image.png";
                        }} // Fallback placeholder
                      />
                    </AnimatePresence>
                  </div>

                  {/* Availability Badge */}
                  <div className="absolute top-4 right-4 z-10">
                    <span
                      className={`px-3 py-1.5 rounded-full text-xs sm:text-sm font-semibold shadow-md flex items-center gap-1.5 ${
                        isAvailable
                          ? "bg-green-500 text-white"
                          : "bg-red-500 text-white"
                      }`}
                    >
                      {isAvailable ? <FaCheckCircle /> : <FaTimesCircle />}
                      {isAvailable ? "Available" : "Unavailable"}
                    </span>
                  </div>

                  {/* Thumbnails (Only if more than one image) */}
                  {displayImages.length > 1 && (
                    <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 via-black/40 to-transparent z-10">
                      <div className="flex gap-2 justify-center overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-transparent">
                        {displayImages.map((image, index) => (
                          <button
                            key={index}
                            onClick={() => setSelectedImageIndex(index)}
                            className={`relative w-16 h-16 sm:w-20 sm:h-20 rounded-md overflow-hidden flex-shrink-0 transition-all duration-200 border-2 ${
                              currentImageIndex === index
                                ? "border-blue-500 scale-105 ring-2 ring-blue-300 ring-offset-1 ring-offset-black/30" // Enhanced selected style
                                : "border-transparent hover:border-gray-400 opacity-70 hover:opacity-100"
                            }`}
                            aria-label={`View image ${index + 1}`}
                            aria-current={currentImageIndex === index}
                          >
                            <img
                              src={image}
                              alt={`Thumbnail ${index + 1}`}
                              className="w-full h-full object-cover"
                              loading="lazy"
                              onError={(e) => {
                                e.currentTarget.src = "/placeholder-image.png";
                              }}
                            />
                            {/* Optional overlay for selected */}
                            {/* {currentImageIndex === index && (
                              <div className="absolute inset-0 bg-blue-500 opacity-30"></div>
                            )} */}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                // Placeholder when no images
                <div className="aspect-w-16 aspect-h-9 lg:aspect-none lg:h-[600px] flex items-center justify-center bg-gray-200">
                  <FaImage className="text-6xl text-gray-400" />
                </div>
              )}
            </div>
            {/* Content Section (Takes 2 columns on large screens) */}
            <div className="lg:col-span-2 p-6 sm:p-8 lg:p-10 flex flex-col bg-white">
              <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-5 leading-tight">
                {billboard.title}
              </h1>

              {/* Details Section */}
              <div className="space-y-5 mb-6 text-gray-700">
                <div className="flex items-start gap-3">
                  <FaMapMarkerAlt
                    className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0"
                    aria-hidden="true"
                  />
                  <span className="text-base">
                    {billboard.location}
                    {billboard.city && `, ${billboard.city}`}
                    {billboard.area && `, ${billboard.area}`}
                  </span>
                </div>
                <div className="flex items-start gap-3">
                  <FaRuler
                    className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0"
                    aria-hidden="true"
                  />
                  <span className="text-base">
                    Size:{" "}
                    <span className="font-medium text-gray-800">
                      {billboard.size}
                    </span>
                    {billboard.resolution &&
                      ` • Resolution: ${billboard.resolution}`}
                  </span>
                </div>
                <div className="flex items-start gap-3">
                  <FaDollarSign
                    className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0"
                    aria-hidden="true"
                  />
                  <div>
                    <span className="text-xl font-bold text-blue-700">
                      {formattedPrice}
                    </span>
                    <span className="text-sm text-gray-500"> / day</span>
                  </div>
                </div>
                {billboard.contact && (
                  <div className="flex items-start gap-3">
                    <FaPhoneAlt
                      className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0"
                      aria-hidden="true"
                    />
                    <span className="text-base">{billboard.contact}</span>
                  </div>
                )}
              </div>

              {/* Description (Conditional) */}
              {billboard.description && (
                <div className="border-t border-gray-200 pt-6 mt-auto flex-grow">
                  {" "}
                  {/* Use mt-auto to push description down */}
                  <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">
                    Description
                  </h3>
                  <p className="text-gray-600 text-base whitespace-pre-wrap leading-relaxed">
                    {billboard.description}
                  </p>
                </div>
              )}

              {/* Action Button */}
              <div className="mt-8 pt-6 border-t border-gray-200">
                {isAvailable ? (
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={handleBookNowClick}
                    className="w-full px-8 py-4 bg-blue-600 text-white rounded-lg text-lg font-semibold shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200"
                  >
                    Book Now!
                  </motion.button>
                ) : (
                  <div className="w-full px-8 py-4 bg-gray-300 text-gray-600 rounded-lg text-lg font-semibold text-center cursor-not-allowed">
                    Currently Unavailable
                  </div>
                )}
              </div>
            </div>{" "}
            {/* End Content Section */}
          </div>{" "}
          {/* End Grid */}
        </div>{" "}
        {/* End Card */}
      </div>{" "}
      {/* End Container */}
    </motion.div>
  );
};

export default BillboardDetail;
