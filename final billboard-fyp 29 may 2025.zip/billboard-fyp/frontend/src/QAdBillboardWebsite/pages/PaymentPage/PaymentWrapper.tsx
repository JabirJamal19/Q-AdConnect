// PaymentWrapper.tsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import PaymentPage from "./PaymentPage";
import { toast } from "react-hot-toast";
import axios from "../../../axiosInstance";

const PaymentWrapper: React.FC = () => {
  const { bookingId } = useParams<{ bookingId: string }>();
  const navigate = useNavigate();
  const [isResubmission, setIsResubmission] = useState(false);
  const [mockBookingData, setMockBookingData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!bookingId) {
      toast.error("No booking ID provided");
      navigate("/billboard-list");
      return;
    }

    // First, try to get the token
    const token = localStorage.getItem("token");
    if (!token) {
      toast.error("You must be logged in to access this page");
      navigate("/auth/signin");
      return;
    }

    // Check if this is a resubmission
    const urlParams = new URLSearchParams(window.location.search);
    const resubmitParam = urlParams.get('resubmit');
    const clientSecret = localStorage.getItem("clientSecret");
    const isFromResubmitButton = resubmitParam === 'true' || !clientSecret;

    if (isFromResubmitButton) {
      // This is a resubmission - create mock booking data
      setIsResubmission(true);

      // Create mock booking data with the essential information
      const mockData = {
        _id: bookingId,
        bookingId: bookingId,
        status: "payment_rejected_resubmit",
        rejectionReason: "Your payment proof was rejected. Please resubmit with a clearer image.",
        feedbackMessage: "Please ensure the transaction details are clearly visible in the image.",
        totalAmount: "As per original booking",
        billboardId: {
          title: "Your Billboard",
          price: 0
        },
        duration: "As per original booking",
        startDate: new Date(),
        endDate: new Date()
      };

      setMockBookingData(mockData);
      setLoading(false);
    } else {
      // This is a normal payment flow - let PaymentPage handle it
      setIsResubmission(false);
      setLoading(false);
    }
  }, [bookingId, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        <span className="ml-3 text-gray-600">Loading Payment Details...</span>
      </div>
    );
  }

  return (
    <PaymentPage
      isResubmissionProp={isResubmission}
      mockBookingData={isResubmission ? mockBookingData : null}
      bypassValidation={isResubmission}
    />
  );
};

export default PaymentWrapper;
