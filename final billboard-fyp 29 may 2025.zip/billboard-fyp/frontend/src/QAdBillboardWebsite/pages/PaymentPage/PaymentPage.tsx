// frontend/components/customer/PaymentPage.tsx
import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  FiLock,
  FiAlertCircle,
  FiCheckCircle,
  FiLoader,
  FiUpload,
  FiInfo,
} from "react-icons/fi";
import { toast } from "react-hot-toast";
import { useBookingStore } from "../../../stores/bookingStore";
import axios from "../../../axiosInstance";

// Payment method types
type PaymentMethod = "jazzcash" | "easypais" | "nayapay" | null;

const PaymentPage: React.FC = () => {
  const { bookingId } = useParams<{ bookingId: string }>(); // Get bookingId from URL params
  const { bookingDetails, clearBookingContext } = useBookingStore(); // Get details and clear function from store
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // State for payment flow
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [formError, setFormError] = useState<string | null>(null);

  // State for payment method selection
  const [selectedPaymentMethod, setSelectedPaymentMethod] =
    useState<PaymentMethod>(null);

  // State for payment form
  const [customerName, setCustomerName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [transactionProof, setTransactionProof] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // State for direct booking fetch
  const [directBookingData, setDirectBookingData] = useState<any>(null);

  useEffect(() => {
    setInitialLoading(true);

    // Handle Stripe errors gracefully
    window.addEventListener(
      "error",
      (e) => {
        // Check if the error is related to Stripe
        if (
          e.message &&
          (e.message.includes("stripe") || e.message.includes("r.stripe.com"))
        ) {
          console.warn("Stripe-related error caught:", e.message);
          // Prevent the error from showing in console
          e.preventDefault();
          return true;
        }
        return false;
      },
      true
    );

    // Validation checks
    if (!bookingId) {
      toast.error("No booking ID provided");
      navigate("/billboard-list");
      return;
    }

    // If we don't have booking details in the store, fetch them directly
    if (!bookingDetails) {
      const fetchBookingDetails = async () => {
        try {
          const token = localStorage.getItem("token");
          if (!token) {
            toast.error("You must be logged in to access this page");
            navigate("/auth/signin");
            return;
          }

          const response = await axios.get(
            `/api/booking/my-bookings?status=content_approved,payment_rejected,payment_rejected_resubmit,paid,pending`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          console.log("Fetched bookings:", response.data);

          if (response.data.status === 1) {
            // Find the booking with the matching ID
            const booking = response.data.data.find(
              (b: any) => b._id === bookingId
            );

            if (booking) {
              setDirectBookingData({
                bookingId: booking._id,
                billboardTitle: booking.billboardId.title,
                duration: booking.duration,
                startDate: booking.startDate,
                endDate: booking.endDate,
                ratePerDay: booking.billboardId.price,
                total: booking.totalAmount,
                status: booking.status,
              });
              setInitialLoading(false);
            } else {
              toast.error("Booking not found or not eligible for payment");
              navigate("/user-booking");
            }
          } else {
            throw new Error("Failed to fetch booking details");
          }
        } catch (error) {
          console.error("Error fetching booking:", error);
          toast.error("Failed to load booking details");
          navigate("/user-booking");
        }
      };

      fetchBookingDetails();
      return;
    }

    // If we have booking details in the store, validate them
    if (bookingDetails.bookingId !== bookingId) {
      console.error("Booking ID mismatch:", {
        urlId: bookingId,
        storeId: bookingDetails.bookingId,
      });

      // Instead of redirecting, try to fetch the booking directly
      const fetchBookingDetails = async () => {
        try {
          const token = localStorage.getItem("token");
          if (!token) {
            toast.error("You must be logged in to access this page");
            navigate("/auth/signin");
            return;
          }

          const response = await axios.get(
            `/api/booking/my-bookings?status=content_approved,payment_rejected,payment_rejected_resubmit,paid,pending`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          console.log("Fetched bookings (mismatch case):", response.data);

          if (response.data.status === 1) {
            // Find the booking with the matching ID
            const booking = response.data.data.find(
              (b: any) => b._id === bookingId
            );

            if (booking) {
              setDirectBookingData({
                bookingId: booking._id,
                billboardTitle: booking.billboardId.title,
                duration: booking.duration,
                startDate: booking.startDate,
                endDate: booking.endDate,
                ratePerDay: booking.billboardId.price,
                total: booking.totalAmount,
                status: booking.status,
              });
              setInitialLoading(false);
            } else {
              toast.error("Booking not found or not eligible for payment");
              navigate("/user-booking");
            }
          } else {
            throw new Error("Failed to fetch booking details");
          }
        } catch (error) {
          console.error("Error fetching booking:", error);
          toast.error("Failed to load booking details");
          navigate("/user-booking");
        }
      };

      fetchBookingDetails();
      return;
    }

    // We don't need client secret for manual payment
    setInitialLoading(false);
  }, [bookingId, bookingDetails, navigate, clearBookingContext]);

  // Handle file upload for transaction proof
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ["image/jpeg", "image/png", "image/jpg"];
    if (!validTypes.includes(file.type)) {
      setFormError("Please upload a valid image file (JPEG, PNG)");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setFormError("File size should be less than 5MB");
      return;
    }

    setTransactionProof(file);
    setFormError(null);

    // Create preview URL
    const fileUrl = URL.createObjectURL(file);
    setPreviewUrl(fileUrl);
  };

  // Handle payment method selection
  const handlePaymentMethodSelect = (method: PaymentMethod) => {
    setSelectedPaymentMethod(method);
    setFormError(null);
  };

  // --- Helper Functions ---
  const formatCurrency = (amount: number | undefined) => {
    const validAmount =
      typeof amount === "number" && !isNaN(amount) ? amount : 0;
    return new Intl.NumberFormat("en-PK", {
      style: "currency",
      currency: "PKR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(validAmount);
  };

  // --- Event Handlers ---

  // Handle manual payment submission
  const handleManualPayment = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form
    if (!selectedPaymentMethod) {
      setFormError("Please select a payment method");
      return;
    }

    if (!customerName.trim()) {
      setFormError("Please enter your name");
      return;
    }

    if (!phoneNumber.trim()) {
      setFormError("Please enter your phone number");
      return;
    }

    if (!transactionProof) {
      setFormError("Please upload transaction proof");
      return;
    }

    if (isProcessing || paymentSuccess) {
      return;
    }

    setIsProcessing(true);
    setFormError(null);

    try {
      toast.loading("Processing your payment...");

      // Create form data for file upload
      const formData = new FormData();
      formData.append("customerName", customerName);
      formData.append("phoneNumber", phoneNumber);
      formData.append("paymentMethod", selectedPaymentMethod);

      // Append transaction proof - the server will handle the filename
      formData.append("transactionProof", transactionProof);

      // Call backend to update booking status and upload payment proof
      // Use different endpoints based on booking status (resubmission vs initial payment)
      const isResubmission =
        directBookingData?.status === "payment_rejected" ||
        directBookingData?.status === "payment_rejected_resubmit";

      const endpoint = isResubmission
        ? `/api/booking/resubmit-payment/${bookingId}`
        : `/api/booking/test-payment/${bookingId}`;

      const response = await axios.post(endpoint, formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "multipart/form-data",
        },
      });

      toast.dismiss();

      if (response.data.status === 1) {
        console.log("Manual payment successful:", response.data);
        setPaymentSuccess(true);
        toast.success(
          "Payment information submitted successfully! Redirecting..."
        );

        // Clean up
        localStorage.removeItem("clientSecret");
        clearBookingContext();

        // Redirect after a short delay
        setTimeout(() => {
          navigate("/user-booking");
        }, 1500);
      } else {
        throw new Error(response.data.message || "Failed to process payment");
      }
    } catch (error: any) {
      toast.dismiss();
      console.error("Payment submission error:", error);

      // More detailed error logging
      if (error.response) {
        console.error("Error response data:", error.response.data);
        console.error("Error response status:", error.response.status);
        console.error("Error response headers:", error.response.headers);

        // Show more specific error message
        toast.error(
          error.response.data?.message || "Failed to submit payment information"
        );

        // Set form error with more details if available
        setFormError(
          `Failed to submit payment: ${error.response.data?.message || error.response.statusText || "Server error"}`
        );
      } else if (error.request) {
        // The request was made but no response was received
        console.error("Error request:", error.request);
        toast.error("No response from server. Please check your connection.");
        setFormError(
          "Network error. Please check your connection and try again."
        );
      } else {
        // Something happened in setting up the request
        toast.error(error.message || "Failed to submit payment information");
        setFormError("Failed to submit payment. Please try again.");
      }
    } finally {
      setIsProcessing(false);
    }
  };

  // --- Render Logic ---

  if (initialLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-50">
        <FiLoader className="animate-spin text-3xl text-blue-500" />
        <span className="ml-3 text-gray-600">Loading Payment Details...</span>
      </div>
    );
  }

  // If loading finished but details are still missing (should have redirected but as safety)
  if (!bookingDetails && !directBookingData) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-100 px-4">
        <div className="text-center p-8 bg-white rounded-lg shadow-md max-w-md w-full">
          <FiAlertCircle className="mx-auto text-5xl text-orange-500 mb-4" />
          <h2 className="text-xl font-semibold text-gray-800 mb-3">
            Payment Session Error
          </h2>
          <p className="text-gray-600 mb-6">
            Could not load necessary booking details.
          </p>
          <button
            onClick={() => navigate("/user-booking")}
            className="mt-4 px-5 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            Back to My Bookings
          </button>
        </div>
      </div>
    );
  }

  // Format details safely - use either bookingDetails from store or directBookingData from API
  const bookingData = directBookingData || bookingDetails;

  const summary = {
    billboard: bookingData.billboardTitle || "N/A",
    duration: bookingData.duration ? `${bookingData.duration} days` : "-",
    startDate: bookingData.startDate
      ? new Date(bookingData.startDate).toLocaleDateString()
      : "-",
    endDate: bookingData.endDate
      ? new Date(bookingData.endDate).toLocaleDateString()
      : "-",
    ratePerDay: bookingData.ratePerDay || 0,
    total: bookingData.total || 0,
  };

  // Payment account information to display to customers
  const paymentAccounts = {
    jazzcash: {
      title: "JazzCash",
      accountNumber: "03001234567",
      accountName: "QAd Billboard Agency",
      instructions:
        "Send payment to the JazzCash account and upload screenshot of confirmation.",
    },
    easypais: {
      title: "EasyPaisa",
      accountNumber: "03009876543",
      accountName: "QAd Billboard Agency",
      instructions:
        "Transfer the exact amount to the EasyPaisa account and upload proof of payment.",
    },
    nayapay: {
      title: "NayaPay",
      accountNumber: "NP123456789",
      accountName: "QAd Billboard Agency",
      instructions:
        "Use the NayaPay app to send payment and upload the transaction receipt.",
    },
  };

  return (
    <div className="bg-gray-50 min-h-screen py-12 flex justify-center items-center px-4">
      <div className="container mx-auto max-w-4xl w-full">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4 }}
          className={`bg-white p-6 sm:p-8 rounded-lg shadow-xl transition-all duration-300 ${paymentSuccess ? "border-4 border-green-400" : ""}`}
        >
          {paymentSuccess ? (
            <div className="text-center py-8">
              <FiCheckCircle className="mx-auto text-6xl text-green-500 mb-4 animate-pulse" />
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-3">
                Payment Information Submitted!
              </h1>
              <p className="text-gray-600">
                Your booking is being processed. You will be redirected shortly.
              </p>
              <div className="mt-6 text-sm">
                <p>
                  <strong>Booking ID:</strong> {bookingId}
                </p>
                <p>
                  <strong>Amount Paid:</strong> {formatCurrency(summary.total)}
                </p>
              </div>
            </div>
          ) : (
            <>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2 text-center">
                {directBookingData?.status === "payment_rejected" ||
                directBookingData?.status === "payment_rejected_resubmit"
                  ? "Resubmit Your Payment"
                  : "Complete Your Payment"}
              </h1>
              {(directBookingData?.status === "payment_rejected" ||
                directBookingData?.status === "payment_rejected_resubmit") && (
                <div className="bg-yellow-50 border border-yellow-300 rounded-md p-3 mb-6 text-center">
                  <p className="text-yellow-800 text-sm">
                    Your previous payment was rejected. Please resubmit with
                    valid payment proof.
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
                {/* Payment Form */}
                <div className="order-2 md:order-1">
                  <form onSubmit={handleManualPayment} className="space-y-5">
                    {/* Payment Method Selection */}
                    <div className="mb-6">
                      <h2 className="text-lg font-semibold mb-3 text-gray-700">
                        Select Payment Method
                      </h2>
                      <div className="grid grid-cols-3 gap-3">
                        {/* JazzCash */}
                        <div
                          onClick={() => handlePaymentMethodSelect("jazzcash")}
                          className={`cursor-pointer border rounded-lg p-3 flex flex-col items-center justify-center transition-all ${
                            selectedPaymentMethod === "jazzcash"
                              ? "border-blue-500 bg-blue-50"
                              : "border-gray-200 hover:border-blue-300"
                          }`}
                        >
                          <img
                            src="/images/paymentLogos/Jazzcash-logo.png"
                            alt="JazzCash"
                            className="h-10 object-contain mb-2"
                          />
                          <span className="text-xs font-medium">JazzCash</span>
                        </div>

                        {/* EasyPaisa */}
                        <div
                          onClick={() => handlePaymentMethodSelect("easypais")}
                          className={`cursor-pointer border rounded-lg p-3 flex flex-col items-center justify-center transition-all ${
                            selectedPaymentMethod === "easypais"
                              ? "border-blue-500 bg-blue-50"
                              : "border-gray-200 hover:border-blue-300"
                          }`}
                        >
                          <img
                            src="/images/paymentLogos/easypais-logo.png"
                            alt="EasyPaisa"
                            className="h-10 object-contain mb-2"
                          />
                          <span className="text-xs font-medium">EasyPaisa</span>
                        </div>

                        {/* NayaPay */}
                        <div
                          onClick={() => handlePaymentMethodSelect("nayapay")}
                          className={`cursor-pointer border rounded-lg p-3 flex flex-col items-center justify-center transition-all ${
                            selectedPaymentMethod === "nayapay"
                              ? "border-blue-500 bg-blue-50"
                              : "border-gray-200 hover:border-blue-300"
                          }`}
                        >
                          <img
                            src="/images/paymentLogos/nayapay-logo.jpeg"
                            alt="NayaPay"
                            className="h-10 object-contain mb-2"
                          />
                          <span className="text-xs font-medium">NayaPay</span>
                        </div>
                      </div>
                    </div>

                    {/* Payment Account Information */}
                    {selectedPaymentMethod && (
                      <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-4">
                        <h3 className="font-medium text-gray-800 mb-2 flex items-center">
                          <FiInfo className="mr-2 text-yellow-500" />
                          Payment Instructions
                        </h3>
                        <div className="text-sm space-y-2">
                          <p>
                            <strong>Account Name:</strong>{" "}
                            {paymentAccounts[selectedPaymentMethod].accountName}
                          </p>
                          <p>
                            <strong>Account Number:</strong>{" "}
                            {
                              paymentAccounts[selectedPaymentMethod]
                                .accountNumber
                            }
                          </p>
                          <p className="text-gray-600 italic">
                            {
                              paymentAccounts[selectedPaymentMethod]
                                .instructions
                            }
                          </p>
                          <p className="font-semibold">
                            Amount: {formatCurrency(summary.total)}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Customer Name */}
                    <div>
                      <label
                        htmlFor="customer-name"
                        className="block text-sm font-medium text-gray-700 mb-1"
                      >
                        Your Name
                      </label>
                      <input
                        id="customer-name"
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 transition"
                        placeholder="Enter your full name"
                        required
                        disabled={isProcessing}
                      />
                    </div>

                    {/* Phone Number */}
                    <div>
                      <label
                        htmlFor="phone-number"
                        className="block text-sm font-medium text-gray-700 mb-1"
                      >
                        Phone Number
                      </label>
                      <input
                        id="phone-number"
                        type="tel"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 transition"
                        placeholder="e.g., 03001234567"
                        required
                        disabled={isProcessing}
                      />
                    </div>

                    {/* Transaction Proof Upload */}
                    <div>
                      <label
                        htmlFor="transaction-proof"
                        className="block text-sm font-medium text-gray-700 mb-1"
                      >
                        Transaction Proof
                      </label>
                      <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                        <div className="space-y-1 text-center">
                          {previewUrl ? (
                            <div className="relative">
                              <img
                                src={previewUrl}
                                alt="Transaction proof preview"
                                className="mx-auto h-32 object-contain"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  setTransactionProof(null);
                                  setPreviewUrl(null);
                                }}
                                className="absolute top-0 right-0 bg-red-500 text-white rounded-full p-1 text-xs"
                              >
                                ✕
                              </button>
                            </div>
                          ) : (
                            <>
                              <FiUpload className="mx-auto h-12 w-12 text-gray-400" />
                              <div className="flex text-sm text-gray-600">
                                <label
                                  htmlFor="file-upload"
                                  className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none"
                                >
                                  <span>Upload a file</span>
                                  <input
                                    id="file-upload"
                                    name="file-upload"
                                    type="file"
                                    className="sr-only"
                                    accept="image/*"
                                    onChange={handleFileChange}
                                    ref={fileInputRef}
                                    disabled={isProcessing}
                                  />
                                </label>
                                <p className="pl-1">or drag and drop</p>
                              </div>
                              <p className="text-xs text-gray-500">
                                PNG, JPG, JPEG up to 5MB
                              </p>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Display Form Errors */}
                    {formError && (
                      <div
                        role="alert"
                        className="text-red-600 text-sm mt-2 flex items-center gap-1"
                      >
                        <FiAlertCircle /> {formError}
                      </div>
                    )}
                  </form>
                </div>

                {/* Order Summary */}
                <div className="order-1 md:order-2 bg-blue-50 p-6 rounded-lg border border-blue-100">
                  <h2 className="text-xl font-semibold mb-5 text-gray-800">
                    Order Summary
                  </h2>
                  <div className="space-y-3 text-sm">
                    <div>
                      <h3 className="font-semibold text-base text-blue-900">
                        {summary.billboard}
                      </h3>
                      <p className="text-gray-600">{summary.duration}</p>
                      <p className="text-gray-600 text-xs">
                        ({summary.startDate} to {summary.endDate})
                      </p>
                    </div>
                    <div className="border-t border-blue-200 pt-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Rate per day</span>
                        <span className="font-medium text-gray-800">
                          {formatCurrency(summary.ratePerDay)}
                        </span>
                      </div>
                      <div className="flex justify-between text-base font-bold mt-2">
                        <span className="text-gray-800">Total Amount Due</span>
                        <span className="text-blue-700">
                          {formatCurrency(summary.total)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="mt-8 pt-6 border-t border-gray-200">
                <button
                  onClick={handleManualPayment}
                  disabled={
                    isProcessing ||
                    !selectedPaymentMethod ||
                    !customerName.trim() ||
                    !phoneNumber.trim() ||
                    !transactionProof
                  }
                  className={`w-full bg-blue-600 text-white py-3 px-6 rounded-lg text-lg font-semibold flex items-center justify-center gap-2 shadow-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                    isProcessing ||
                    !selectedPaymentMethod ||
                    !customerName.trim() ||
                    !phoneNumber.trim() ||
                    !transactionProof
                      ? "opacity-60 cursor-not-allowed"
                      : "hover:bg-blue-700"
                  }`}
                >
                  {isProcessing ? (
                    <>
                      <FiLoader className="animate-spin" />
                      Processing Payment...
                    </>
                  ) : (
                    <>
                      <FiLock />
                      {directBookingData?.status === "payment_rejected" ||
                      directBookingData?.status === "payment_rejected_resubmit"
                        ? "Resubmit Payment Information"
                        : "Submit Payment Information"}
                    </>
                  )}
                </button>
                <p className="text-center text-gray-500 text-xs mt-3">
                  Your payment will be verified by our team within 24 hours.
                </p>
              </div>
            </>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default PaymentPage;
