// Interfaces
export interface Billboard {
  _id: string;
  title: string;
  price: number;
  status: "active" | "inactive";
  location: string;
}

export interface DetailApiResponse {
  status: number;
  data: Billboard;
  message?: string;
}

export interface BookingApiResponse {
  status: number;
  message: string;
  data: {
    booking: any;
    client_secret: string;
  };
  error?: string;
}

export interface BookingFormData {
  startDate: string;
  endDate: string;
  startTime: string;
  endTime: string;
}

export interface BookingDetails {
  duration: number;
  ratePerDay: number;
  totalCost: number;
}
