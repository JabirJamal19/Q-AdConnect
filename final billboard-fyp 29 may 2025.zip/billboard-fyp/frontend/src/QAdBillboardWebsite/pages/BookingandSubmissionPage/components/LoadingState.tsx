import React from "react";
import { FaSpinner } from "react-icons/fa";

const LoadingState: React.FC = () => {
  return (
    <div className="min-h-screen mt-8 flex flex-col items-center justify-center bg-gray-50">
      <FaSpinner className="animate-spin text-4xl text-blue-600" />
      <p className="text-gray-600">Loading Billboard Details...</p>
    </div>
  );
};

export default LoadingState;
