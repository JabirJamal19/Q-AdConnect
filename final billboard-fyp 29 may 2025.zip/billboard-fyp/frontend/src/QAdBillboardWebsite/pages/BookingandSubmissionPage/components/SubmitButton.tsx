import React from "react";
import { motion } from "framer-motion";
import { FaSpinner, FaInfoCircle } from "react-icons/fa";

interface SubmitButtonProps {
  submitting: boolean;
  fetchLoading: boolean;
  duration: number;
  adMediaFilesLength: number;
  fileError: string | null;
}

const SubmitButton: React.FC<SubmitButtonProps> = ({
  submitting,
  fetchLoading,
  duration,
  adMediaFilesLength,
  fileError,
}) => {
  const isDisabled =
    submitting ||
    fetchLoading ||
    duration <= 0 ||
    adMediaFilesLength === 0 ||
    !!fileError;

  return (
    <>
      <motion.button
        type="submit"
        disabled={isDisabled}
        whileHover={!isDisabled ? { scale: 1.02 } : {}}
        whileTap={!isDisabled ? { scale: 0.98 } : {}}
        className={`w-full flex justify-center items-center gap-2 bg-blue-600 text-white
          py-3 rounded-xl text-lg font-semibold shadow-lg
          transition-all duration-200 transform focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
          ${
            isDisabled
              ? "opacity-50 cursor-not-allowed bg-blue-400"
              : "hover:bg-blue-700"
          }`}
        aria-live="polite" // Announce changes for screen readers
      >
        {submitting ? (
          <>
            <FaSpinner className="animate-spin" />
            <span>Processing...</span>
          </>
        ) : (
          "Continue to Payment"
        )}
      </motion.button>

      {/* Footer Text */}
      <p className="mt-2 text-center text-gray-500 text-xs flex items-center justify-center gap-1">
        <FaInfoCircle /> By continuing, you agree to our terms. Payment
        confirms booking.
      </p>
    </>
  );
};

export default SubmitButton;
