import React from "react";
import { motion } from "framer-motion";
import { Billboard } from "../utils/types";

interface BookingHeaderProps {
  billboard: Billboard;
}

const BookingHeader: React.FC<BookingHeaderProps> = ({ billboard }) => {
  return (
    <div className="bg-gradient-to-r from-blue-600 to-blue-500 p-6 sm:p-8">
      <h1 className="text-white text-2xl sm:text-3xl font-bold">
        Book: {billboard.title}
      </h1>
      <p className="text-blue-100 mt-1 sm:mt-2">
        {billboard.location} - Select dates and upload your ad content.
      </p>
    </div>
  );
};

export default BookingHeader;
