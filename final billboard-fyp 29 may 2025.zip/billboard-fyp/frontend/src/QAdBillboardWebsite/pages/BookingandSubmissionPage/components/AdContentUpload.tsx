import React from "react";
import { FaCloudUploadAlt, FaExclamationCircle, FaTrashAlt } from "react-icons/fa";

interface AdContentUploadProps {
  adMediaFiles: File[];
  fileError: string | null;
  handleFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  removeFile: (index: number) => void;
}

const AdContentUpload: React.FC<AdContentUploadProps> = ({
  adMediaFiles,
  fileError,
  handleFileChange,
  removeFile,
}) => {
  return (
    <section aria-labelledby="ad-upload-heading">
      <h2
        id="ad-upload-heading"
        className="text-gray-800 text-xl font-semibold mb-4 flex items-center gap-2"
      >
        <FaCloudUploadAlt className="text-blue-600" /> Upload Ad Content
      </h2>
      <div className="space-y-3">
        <label
          htmlFor="adMediaFiles"
          className="block text-sm font-medium text-gray-700"
        >
          Select Files (Images/Videos, max 5, 100MB each)
        </label>
        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
          <div className="space-y-1 text-center">
            <FaCloudUploadAlt className="mx-auto h-12 w-12 text-gray-400" />
            <div className="flex text-sm text-gray-600">
              <label
                htmlFor="adMediaFiles"
                className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
              >
                <span>Upload files</span>
                <input
                  id="adMediaFiles"
                  name="adMediaFiles"
                  type="file"
                  multiple
                  accept="image/jpeg,image/png,image/gif,video/mp4,video/quicktime,video/x-ms-wmv,video/avi"
                  onChange={handleFileChange}
                  className="sr-only"
                  aria-describedby="file-constraints"
                  required={adMediaFiles.length === 0} // Required if no files selected yet
                  aria-required={adMediaFiles.length === 0}
                />
              </label>
              <p className="pl-1">or drag and drop</p>
            </div>
            <p
              id="file-constraints"
              className="text-xs text-gray-500"
            >
              JPG, PNG, GIF, MP4, MOV, AVI, WMV up to 100MB each.
            </p>
          </div>
        </div>

        {/* File Upload Error Display */}
        {fileError && (
          <p
            role="alert"
            className="text-sm text-red-600 flex items-center gap-1"
          >
            <FaExclamationCircle /> {fileError}
          </p>
        )}

        {/* Display Selected Files */}
        {adMediaFiles.length > 0 && (
          <div className="mt-4 space-y-2">
            <h3 className="text-sm font-medium text-gray-800">
              Selected Files ({adMediaFiles.length}/5):
            </h3>
            <ul className="divide-y divide-gray-200 border border-gray-200 rounded-md">
              {adMediaFiles.map((file, index) => (
                <li
                  key={index}
                  className="px-3 py-2 flex items-center justify-between text-sm"
                >
                  <span className="text-gray-700 truncate flex-1 pr-2">
                    {file.name}
                  </span>
                  <span className="text-gray-500 flex-shrink-0">
                    ({(file.size / 1024 / 1024).toFixed(2)} MB)
                  </span>
                  <button
                    type="button"
                    onClick={() => removeFile(index)}
                    className="ml-3 text-red-600 hover:text-red-800 flex-shrink-0"
                    title={`Remove ${file.name}`}
                    aria-label={`Remove ${file.name}`}
                  >
                    <FaTrashAlt />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </section>
  );
};

export default AdContentUpload;
