import React from "react";
import { FaCalendarAlt, FaInfoCircle } from "react-icons/fa";
import { BookingFormData } from "../utils/types";
import { getTodayString } from "../utils/helpers";

interface DateSelectionProps {
  formData: BookingFormData;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const DateSelection: React.FC<DateSelectionProps> = ({ formData, handleInputChange }) => {
  return (
    <section aria-labelledby="date-selection-heading">
      <h2
        id="date-selection-heading"
        className="text-gray-800 text-xl font-semibold mb-4 flex items-center gap-2"
      >
        <FaCalendarAlt className="text-blue-600" /> Select Booking Dates
      </h2>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {/* Start Date */}
        <div>
          <label
            htmlFor="startDate"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Start Date
          </label>
          <input
            id="startDate"
            type="date"
            name="startDate"
            value={formData.startDate}
            onChange={handleInputChange}
            min={getTodayString()} // Prevent past dates
            className="w-full rounded-lg border border-gray-300 bg-white p-3 text-gray-900 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 shadow-sm"
            required
            aria-required="true"
          />
        </div>
        {/* End Date */}
        <div>
          <label
            htmlFor="endDate"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            End Date
          </label>
          <input
            id="endDate"
            type="date"
            name="endDate"
            value={formData.endDate}
            onChange={handleInputChange}
            min={formData.startDate || getTodayString()} // Min is start date or today
            className={`w-full rounded-lg border ${!formData.startDate ? "border-gray-200 bg-gray-100" : "border-gray-300 bg-white"} p-3 text-gray-900 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 shadow-sm`}
            required
            aria-required="true"
            disabled={!formData.startDate} // Disable until start date is selected
            aria-disabled={!formData.startDate}
          />
          {!formData.startDate && (
            <p className="text-xs text-gray-500 mt-1">
              Select start date first.
            </p>
          )}
        </div>
      </div>

      {/* Time Selection */}
      <div className="mt-6">
        <h3 className="text-gray-700 text-sm font-medium mb-3 flex items-center gap-2">
          <FaInfoCircle className="text-blue-600" /> Digital
          billboards are only available at night (6:00 PM - 11:59 PM)
        </h3>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {/* Start Time */}
          <div>
            <label
              htmlFor="startTime"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Start Time
            </label>
            <input
              id="startTime"
              type="time"
              name="startTime"
              value={formData.startTime}
              onChange={handleInputChange}
              min="18:00"
              max="23:59"
              className="w-full rounded-lg border border-gray-300 bg-white p-3 text-gray-900 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 shadow-sm"
              required
              aria-required="true"
            />
            <p className="text-xs text-gray-500 mt-1">
              Earliest available: 6:00 PM
            </p>
          </div>
          {/* End Time */}
          <div>
            <label
              htmlFor="endTime"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              End Time
            </label>
            <input
              id="endTime"
              type="time"
              name="endTime"
              value={formData.endTime}
              onChange={handleInputChange}
              min={formData.startTime}
              max="23:59"
              className="w-full rounded-lg border border-gray-300 bg-white p-3 text-gray-900 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 shadow-sm"
              required
              aria-required="true"
            />
            <p className="text-xs text-gray-500 mt-1">
              Latest available: 11:59 PM
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DateSelection;
