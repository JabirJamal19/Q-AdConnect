import React from "react";
import { useNavigate } from "react-router-dom";
import { FaExclamationCircle } from "react-icons/fa";

interface ErrorStateProps {
  error: string | null;
}

const ErrorState: React.FC<ErrorStateProps> = ({ error }) => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen mt-8 flex items-center justify-center bg-gray-100 px-4">
      <div className="text-center p-8 bg-white rounded-lg shadow-md max-w-md w-full">
        <FaExclamationCircle className="mx-auto text-5xl text-red-500 mb-4" />
        <h2 className="text-xl font-semibold text-red-700 mb-3">
          Cannot Proceed with Booking
        </h2>
        <p className="text-gray-600 mb-6">
          {error || "Billboard details are unavailable."}
        </p>
        <button
          onClick={() => navigate("/billboard-list")}
          className="mt-4 px-5 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
        >
          Back to Billboards
        </button>
      </div>
    </div>
  );
};

export default ErrorState;
