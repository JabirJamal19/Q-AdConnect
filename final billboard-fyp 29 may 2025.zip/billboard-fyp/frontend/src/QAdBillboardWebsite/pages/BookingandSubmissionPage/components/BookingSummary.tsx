import React from "react";
import { Billboard, BookingDetails, BookingFormData } from "../utils/types";
import { formatCurrency } from "../utils/helpers";

interface BookingSummaryProps {
  billboard: Billboard;
  bookingDetails: BookingDetails;
  formData: BookingFormData;
}

const BookingSummary: React.FC<BookingSummaryProps> = ({
  billboard,
  bookingDetails,
  formData,
}) => {
  return (
    <section aria-labelledby="summary-heading">
      <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
        <h2
          id="summary-heading"
          className="text-gray-800 text-xl font-semibold mb-5"
        >
          Booking Summary
        </h2>
        {/* Billboard Info */}
        <p className="mb-4 text-sm text-gray-600">
          Billboard:{" "}
          <span className="font-medium text-gray-900">
            {billboard.title}
          </span>
        </p>
        {/* Summary Details */}
        <div className="space-y-3">
          {/* Time Slot */}
          <div className="flex items-center justify-between pb-2 border-b border-gray-200">
            <span className="text-gray-600">Time Slot</span>
            <span className="text-gray-800 font-medium">
              {formData.startTime} - {formData.endTime} (Night)
            </span>
          </div>
          {/* Duration */}
          <div className="flex items-center justify-between pb-2 border-b border-gray-200">
            <span className="text-gray-600">Duration</span>
            <span className="text-gray-800 font-medium">
              {bookingDetails.duration > 0
                ? `${bookingDetails.duration} days`
                : "-"}
            </span>
          </div>
          {/* Rate Per Day */}
          <div className="flex items-center justify-between pb-2 border-b border-gray-200">
            <span className="text-gray-600">Rate per day</span>
            <span className="text-gray-800 font-medium">
              {bookingDetails.ratePerDay > 0
                ? formatCurrency(bookingDetails.ratePerDay)
                : "-"}
            </span>
          </div>
          {/* Total Cost */}
          <div className="flex items-center justify-between pt-3">
            <span className="text-gray-800 text-lg font-semibold">
              Estimated Total Cost
            </span>
            <div className="text-right">
              <span className="text-blue-700 text-2xl font-bold">
                {formatCurrency(bookingDetails.totalCost)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BookingSummary;
