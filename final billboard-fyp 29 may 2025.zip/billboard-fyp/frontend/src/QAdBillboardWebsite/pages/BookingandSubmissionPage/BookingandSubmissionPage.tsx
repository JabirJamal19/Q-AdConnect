import React, { useState, useEffect, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useAuthStore } from "../../../stores/authStore";
import axios from "../../../axiosInstance";
import { toast } from "react-hot-toast";
import { useBookingStore } from "../../../stores/bookingStore";

// Import types and helpers
import {
  Billboard,
  DetailApiResponse,
  BookingApiResponse,
  BookingFormData,
  BookingDetails,
} from "./utils/types";
import { getTodayString } from "./utils/helpers";

// Import components
import {
  ErrorState,
  LoadingState,
  BookingHeader,
  DateSelection,
  AdContentUpload,
  BookingSummary,
  SubmitButton,
} from "./components";

const BookingAndSubmissionPage: React.FC = () => {
  const { id: billboardId } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const setBookingContextForPayment = useBookingStore(
    (state) => state.setBookingContextForPayment
  );
  const { token } = useAuthStore();

  // State
  const [fetchLoading, setFetchLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [billboard, setBillboard] = useState<Billboard | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<BookingFormData>({
    startDate: getTodayString(),
    endDate: getTodayString(),
    startTime: "18:00", // Default start time: 6:00 PM
    endTime: "23:59", // Default end time: 11:59 PM
  });
  const [bookingDetails, setBookingDetails] = useState<BookingDetails>({
    duration: 0,
    ratePerDay: 0,
    totalCost: 0,
  });
  const [adMediaFiles, setAdMediaFiles] = useState<File[]>([]);
  const [fileError, setFileError] = useState<string | null>(null);

  // --- Data Fetching ---
  useEffect(() => {
    const fetchBillboardDetails = async (id: string) => {
      setFetchLoading(true);
      setError(null);
      if (!token) {
        // Ensure token exists before making authenticated requests if needed
        setError("Authentication token is missing.");
        toast.error("Please log in again.");
        setFetchLoading(false);
        navigate("/auth/signin");
        return;
      }
      try {
        // *** Use PUBLIC detail endpoint - Booking page is after viewing details ***
        const response = await axios.get<DetailApiResponse>(
          `/api/billboard/public/detail/${id}`
        );

        if (response.data?.status === 1 && response.data.data) {
          if (response.data.data.status !== "active") {
            throw new Error(
              "This billboard is currently unavailable for booking."
            );
          }
          setBillboard(response.data.data);
          const rate = response.data.data.price; // Already a number
          setBookingDetails((prev) => ({ ...prev, ratePerDay: rate || 0 }));
        } else {
          throw new Error(
            response.data?.message || "Billboard details not found."
          );
        }
      } catch (err: any) {
        console.error("Failed to fetch billboard details:", err);
        let message = "Failed to load billboard details.";
        if (err.code === "ERR_NETWORK")
          message = "Network error. Cannot connect to server.";
        else if (err.response)
          message =
            err.response.data?.message ||
            `Server error (${err.response.status})`;
        else if (err.message) message = err.message;

        setError(message);
        toast.error(message);
        setBillboard(null); // Ensure billboard is null on error
        // Optionally navigate back if critical error (e.g., 404)
        if (err.response?.status === 404 || message.includes("unavailable")) {
          setTimeout(() => navigate("/billboard-list"), 2000); // Go back after delay
        }
      } finally {
        setFetchLoading(false);
      }
    };

    if (billboardId) {
      fetchBillboardDetails(billboardId);
    } else {
      toast.error("Billboard ID is missing.");
      navigate("/billboard-list");
      setFetchLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [billboardId, navigate, token]); // Add token dependency

  // --- Calculations (using useMemo for optimization) ---
  useMemo(() => {
    if (formData.startDate && formData.endDate && billboard) {
      const start = new Date(formData.startDate);
      const end = new Date(formData.endDate);

      if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) {
        setBookingDetails((prev) => ({ ...prev, duration: 0, totalCost: 0 }));
        return;
      }

      // Calculate difference in time
      const diffTime = end.getTime() - start.getTime();
      // Calculate difference in days, add 1 for inclusive range
      const duration = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

      const rate = bookingDetails.ratePerDay;
      const totalCost = duration * rate;

      setBookingDetails((prev) => ({
        ...prev,
        duration: duration > 0 ? duration : 0,
        totalCost: totalCost > 0 ? totalCost : 0,
      }));
    } else {
      setBookingDetails((prev) => ({ ...prev, duration: 0, totalCost: 0 }));
    }
  }, [
    formData.startDate,
    formData.endDate,
    billboard,
    bookingDetails.ratePerDay,
  ]);

  // --- Event Handlers ---
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => {
      const newFormData = { ...prev, [name]: value };

      // Date validation
      if (name === "startDate" || name === "endDate") {
        const start = new Date(newFormData.startDate);
        const end = new Date(newFormData.endDate);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (name === "startDate" && start < today) {
          toast.error("Start date cannot be in the past.");
          return { ...prev, startDate: getTodayString() }; // Reset to today if invalid
        }
        if (name === "endDate" && newFormData.startDate && end < start) {
          toast.error("End date cannot be before start date.");
          // Keep the invalid date for now, validation on submit catches it, calculation handles zero cost.
          // Or reset: return { ...prev, endDate: newFormData.startDate };
        }
      }

      // Time validation for night hours (6:00 PM - 11:59 PM)
      if (name === "startTime" || name === "endTime") {
        const timeValue = value;
        const [hours] = timeValue.split(":").map(Number);

        // For digital billboards, only allow night hours (18:00 - 23:59)
        if (hours < 18 && hours >= 0) {
          toast.error(
            "Digital billboards are only available from 6:00 PM to 11:59 PM."
          );
          return {
            ...prev,
            [name]: name === "startTime" ? "18:00" : prev.startTime,
          };
        }

        if (hours > 23) {
          toast.error(
            "Please select a valid time between 6:00 PM and 11:59 PM."
          );
          return { ...prev, [name]: name === "startTime" ? "18:00" : "23:59" };
        }

        // If end time is earlier than start time
        if (name === "endTime" && timeValue < newFormData.startTime) {
          toast.error("End time cannot be earlier than start time.");
          return { ...prev, endTime: prev.endTime };
        }
      }

      return newFormData;
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError(null); // Clear previous file errors
    const files = Array.from(e.target.files || []);
    const MAX_FILES = 5;
    const MAX_SIZE_MB = 100; // Max size per file
    let currentFiles = [...adMediaFiles]; // Copy existing files
    let errorFound = false;

    if (currentFiles.length + files.length > MAX_FILES) {
      setFileError(`You can upload a maximum of ${MAX_FILES} files.`);
      toast.error(`You can upload a maximum of ${MAX_FILES} files.`);
      errorFound = true;
      // Optionally truncate the new files: files = files.slice(0, MAX_FILES - currentFiles.length);
      // For simplicity, we just show error and don't add new ones if limit exceeded.
      e.target.value = ""; // Clear the input
      return; // Stop processing further
    }

    files.forEach((file) => {
      if (file.size > MAX_SIZE_MB * 1024 * 1024) {
        setFileError(
          `File "${file.name}" exceeds the ${MAX_SIZE_MB}MB size limit.`
        );
        toast.error(
          `File "${file.name}" exceeds the ${MAX_SIZE_MB}MB size limit.`
        );
        errorFound = true;
      } else {
        // Add valid file if no error found yet for this batch
        if (!errorFound) {
          currentFiles.push(file);
        }
      }
    });

    if (errorFound) {
      e.target.value = ""; // Clear input if any error occurred
    } else {
      setAdMediaFiles(currentFiles); // Update state with new valid files
    }
  };

  const removeFile = (indexToRemove: number) => {
    setAdMediaFiles((prevFiles) =>
      prevFiles.filter((_, index) => index !== indexToRemove)
    );
    setFileError(null); // Clear error when removing a file
    // Also clear the file input value to allow re-selecting the same file
    const fileInput = document.getElementById(
      "adMediaFiles"
    ) as HTMLInputElement;
    if (fileInput) {
      fileInput.value = "";
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    if (!token) {
      toast.error("Please login to continue");
      navigate("/auth/signin");
      return;
    }

    // Validate required data
    if (
      !billboardId ||
      !formData.startDate ||
      !formData.endDate ||
      !formData.startTime ||
      !formData.endTime ||
      !adMediaFiles.length
    ) {
      toast.error(
        "Please fill in all required fields and upload at least one ad media file"
      );
      setSubmitting(false);
      return;
    }

    // Validate time slots (must be between 6:00 PM and 11:59 PM)
    const [startHours] = formData.startTime.split(":").map(Number);
    const [endHours] = formData.endTime.split(":").map(Number);

    if (startHours < 18 || startHours > 23 || endHours < 18 || endHours > 23) {
      toast.error(
        "Digital billboards are only available from 6:00 PM to 11:59 PM"
      );
      setSubmitting(false);
      return;
    }

    // Validate that end time is after start time
    if (formData.endTime < formData.startTime) {
      toast.error("End time cannot be earlier than start time");
      setSubmitting(false);
      return;
    }

    // Validate dates
    const startDate = new Date(formData.startDate);
    const endDate = new Date(formData.endDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Ensure dates are valid
    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      toast.error("Invalid date format");
      setSubmitting(false);
      return;
    }

    if (startDate < today) {
      toast.error("Start date cannot be in the past");
      setSubmitting(false);
      return;
    }

    if (endDate < startDate) {
      toast.error("End date cannot be before start date");
      setSubmitting(false);
      return;
    }

    try {
      const formDataWithFiles = new FormData();
      adMediaFiles.forEach((file) => {
        formDataWithFiles.append("adMedia", file);
      });

      // Combine date and time for start and end dates
      const startDateTime = new Date(formData.startDate);
      const [startHours, startMinutes] = formData.startTime
        .split(":")
        .map(Number);
      startDateTime.setHours(startHours, startMinutes, 0, 0);

      const endDateTime = new Date(formData.endDate);
      const [endHours, endMinutes] = formData.endTime.split(":").map(Number);
      endDateTime.setHours(endHours, endMinutes, 0, 0);

      // Format dates as ISO strings
      formDataWithFiles.append("billboardId", billboardId);
      formDataWithFiles.append("startDate", startDateTime.toISOString());
      formDataWithFiles.append("endDate", endDateTime.toISOString());
      formDataWithFiles.append("startTime", formData.startTime);
      formDataWithFiles.append("endTime", formData.endTime);
      formDataWithFiles.append(
        "totalAmount",
        bookingDetails.totalCost.toString()
      );
      formDataWithFiles.append("duration", bookingDetails.duration.toString());

      const response = await axios.post<BookingApiResponse>(
        "/api/booking/create",
        formDataWithFiles,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (response.data?.status === 1 && response.data.data?.booking) {
        const { booking, client_secret } = response.data.data;

        // Store payment context for later use
        localStorage.setItem("clientSecret", client_secret);
        setBookingContextForPayment({
          total: booking.totalAmount,
          duration: booking.duration,
          ratePerDay: bookingDetails.ratePerDay,
          startDate: booking.startDate,
          endDate: booking.endDate,
          billboardTitle: billboard?.title || "Billboard",
          bookingId: booking._id,
        });

        // Store time slot information in localStorage for reference
        localStorage.setItem(
          "timeSlot",
          JSON.stringify({
            startTime: formData.startTime,
            endTime: formData.endTime,
          })
        );

        // Show success message and redirect to user bookings page
        toast.success(
          "Your booking has been submitted successfully! You will be notified when your content is approved to proceed with payment.",
          { duration: 6000 }
        );

        // Navigate to user bookings page instead of payment
        navigate("/user-booking");
      } else {
        throw new Error(response.data?.message || "Failed to create booking");
      }
    } catch (error: any) {
      console.error("Booking creation error:", error);
      const errorMessage =
        error.response?.data?.message ||
        "Failed to create booking. Please try again.";
      toast.error(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  // --- Render Logic ---

  // Error state if billboard fetch failed critically
  if (error || !billboard) {
    return <ErrorState error={error} />;
  }

  // Loading state for billboard details
  if (fetchLoading) {
    return <LoadingState />;
  }

  // --- Main Form Render ---
  return (
    <div className="min-h-screen mt-8 bg-gray-50 py-10 transition-colors duration-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-2xl shadow-xl overflow-hidden"
          >
            {/* Header */}
            <BookingHeader billboard={billboard} />

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-8">
              {/* Date Selection */}
              <DateSelection
                formData={formData}
                handleInputChange={handleInputChange}
              />

              {/* Ad Content Upload */}
              <AdContentUpload
                adMediaFiles={adMediaFiles}
                fileError={fileError}
                handleFileChange={handleFileChange}
                removeFile={removeFile}
              />

              {/* Booking Summary */}
              <BookingSummary
                billboard={billboard}
                bookingDetails={bookingDetails}
                formData={formData}
              />

              {/* Submit Button */}
              <SubmitButton
                submitting={submitting}
                fetchLoading={fetchLoading}
                duration={bookingDetails.duration}
                adMediaFilesLength={adMediaFiles.length}
                fileError={fileError}
              />
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default BookingAndSubmissionPage;
