export interface Booking {
  _id: string;
  billboardId: {
    _id: string;
    title: string;
    location: string;
    price: number;
    imageUrl: string;
  };
  startDate: string;
  endDate: string;
  startTime?: string; // Added for time tracking (6:00 PM - 11:59 PM)
  endTime?: string; // Added for time tracking (6:00 PM - 11:59 PM)
  totalAmount: number;
  status:
    | "pending"
    | "approved"
    | "content_pending"
    | "content_approved"
    | "content_rejected"
    | "content_rejected_resubmit"
    | "live"
    | "rejected"
    | "payment_rejected"
    | "payment_rejected_resubmit"
    | "cancelled"
    | "completed";
  paymentStatus: string;
  rejectionReason?: string;
  feedbackMessage?: string;
  adImageUrls: string[];
}

export interface BookingsApiResponse {
  status: number;
  message: string;
  data: Booking[];
  totalPages: number;
}
