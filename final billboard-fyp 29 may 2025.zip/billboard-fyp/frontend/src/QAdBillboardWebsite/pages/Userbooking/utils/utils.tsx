import React from "react";
import {
  FaCheckCircle,
  FaTimesCircle,
  FaTimes,
  FaHourglassHalf,
  FaWifi,
  FaImage,
  FaExclamationTriangle,
} from "react-icons/fa";
import { Booking } from "./types";

// Format date as short month and day
export const formatDate = (dateString: string | undefined): string => {
  if (!dateString) return "N/A";
  try {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
  } catch (e) {
    return "Invalid Date";
  }
};

// Format date with year, month, and day
export const formatFullDate = (dateString: string | undefined): string => {
  if (!dateString) return "N/A";
  try {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch (e) {
    return "Invalid Date";
  }
};

// Format currency in PKR
export const formatCurrency = (amount: number | undefined): string => {
  if (amount === undefined || isNaN(amount)) return "N/A";
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

// Get full image URL
export const getFullImageUrl = (url?: string): string => {
  if (!url) return "/placeholder-image.png";
  if (url.startsWith("http://") || url.startsWith("https://")) return url;
  const baseUrl = import.meta.env.VITE_API_URL || "http://localhost:4000";
  const cleanBaseUrl = baseUrl.endsWith("/") ? baseUrl.slice(0, -1) : baseUrl;
  const cleanUrl = url.startsWith("/") ? url.substring(1) : url;
  return `${cleanBaseUrl}/${cleanUrl}`;
};

// Check if booking is expired
export const isBookingExpired = (booking: Booking) => {
  if (!booking.endDate) return true; // Treat as expired if no end date

  const now = new Date();
  const endDate = new Date(booking.endDate);

  // If we have endTime, use it for precise expiration check
  if (booking.endTime) {
    const [hours, minutes] = booking.endTime.split(":").map(Number);
    endDate.setHours(hours, minutes, 0, 0);
    return endDate < now;
  } else {
    // Fallback to date-only comparison if no time is available
    const todayMidnight = new Date();
    endDate.setHours(0, 0, 0, 0);
    todayMidnight.setHours(0, 0, 0, 0);
    return endDate < todayMidnight;
  }
};

// Get status chip component based on booking status
export const getStatusChip = (status: Booking["status"]) => {
  let baseStyle =
    "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border";
  let icon: React.ReactNode = null;
  let text = "Unknown";
  let colorClasses = "bg-gray-100 text-gray-700 border-gray-300";

  switch (status) {
    case "pending":
      colorClasses = "bg-yellow-100 text-yellow-800 border-yellow-300";
      icon = <FaHourglassHalf />;
      text = "Pending";
      break;
    case "approved":
      colorClasses = "bg-teal-100 text-teal-800 border-teal-300";
      icon = <FaCheckCircle />;
      text = "Approved";
      break;
    case "content_pending":
      colorClasses = "bg-blue-100 text-blue-800 border-blue-300";
      icon = <FaImage />;
      text = "Awaiting Content";
      break;
    case "content_approved":
      colorClasses = "bg-green-100 text-green-800 border-green-300";
      icon = <FaCheckCircle />;
      text = "Content Approved";
      break;
    case "content_rejected":
      colorClasses = "bg-red-100 text-red-800 border-red-300";
      icon = <FaTimesCircle />;
      text = "Content Rejected";
      break;
    case "content_rejected_resubmit":
      colorClasses = "bg-red-100 text-red-800 border-red-300";
      icon = <FaTimesCircle />;
      text = "Content Rejected";
      break;
    case "paid":
      colorClasses = "bg-blue-100 text-blue-800 border-blue-300";
      icon = <FaHourglassHalf />;
      text = "Payment Pending";
      break;
    case "payment_verified":
      colorClasses = "bg-green-100 text-green-800 border-green-300";
      icon = <FaCheckCircle />;
      text = "Payment Verified";
      break;
    case "payment_rejected":
      colorClasses = "bg-red-100 text-red-800 border-red-300";
      icon = <FaTimesCircle />;
      text = "Payment Rejected";
      break;
    case "payment_rejected_resubmit":
      colorClasses = "bg-red-100 text-red-800 border-red-300";
      icon = <FaTimesCircle />;
      text = "Payment Rejected";
      break;
    case "live":
      baseStyle =
        "inline-flex items-center gap-1.5 pl-2 pr-3 py-1 rounded-full text-xs font-semibold shadow"; // Slightly toned down shadow
      colorClasses =
        "bg-gradient-to-r from-red-500 to-orange-500 text-white border-none";
      icon = <FaWifi className="animate-pulse" />;
      text = "LIVE";
      break;
    case "rejected":
      colorClasses = "bg-red-100 text-red-800 border-red-300";
      icon = <FaTimesCircle />;
      text = "Rejected";
      break;
    case "cancelled":
      colorClasses = "bg-gray-200 text-gray-600 border-gray-300";
      icon = <FaTimes />;
      text = "Cancelled";
      break;
    case "completed":
      colorClasses = "bg-indigo-100 text-indigo-800 border-indigo-300";
      icon = <FaCheckCircle />;
      text = "Completed";
      break;
    default:
      icon = <FaExclamationTriangle />;
      break;
  }
  return (
    <span className={`${baseStyle} ${colorClasses}`}>
      {icon}
      {text}
    </span>
  );
};
