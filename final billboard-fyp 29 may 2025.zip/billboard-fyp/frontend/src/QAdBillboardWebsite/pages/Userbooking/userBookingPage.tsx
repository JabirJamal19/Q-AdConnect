// frontend/pages/customer/UserBookingPage.tsx
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../../../stores/authStore";
import axiosInstance from "../../../axiosInstance";
import toast from "react-hot-toast";
import { AnimatePresence } from "framer-motion";

// Import types and utils
import { Booking, BookingsApiResponse } from "./utils/types";
import { isBookingExpired } from "./utils/utils";

// Import components
import {
  SignInPrompt,
  PageHeader,
  LoadingState,
  ErrorState,
  LiveCampaignsSection,
  UpcomingCampaignsSection,
  RecentlyCompletedSection,
  PaginationControls,
  ResubmitContentModal,
} from "./components";

// --- Component ---
const UserBookingPage = () => {
  const { user, token } = useAuthStore();
  const navigate = useNavigate();

  // --- States ---
  const [allFetchedBookings, setAllFetchedBookings] = useState<Booking[]>([]); // Store all bookings from the current page fetch
  const [loadingBookings, setLoadingBookings] = useState(true);
  const [bookingError, setBookingError] = useState<string | null>(null);
  const [bookingCurrentPage, setBookingCurrentPage] = useState(1);
  const [bookingTotalPages, setBookingTotalPages] = useState(1);
  const bookingsPerPage = 6;

  // Resubmission States
  const [isResubmitModalOpen, setIsResubmitModalOpen] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isSubmittingContent, setIsSubmittingContent] = useState(false);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);

  // --- Memoized Filtered Bookings ---
  const liveBookings = useMemo(() => {
    return allFetchedBookings.filter(
      (b) => b.status === "live" && !isBookingExpired(b)
    );
  }, [allFetchedBookings]);

  const upcomingBookings = useMemo(() => {
    return allFetchedBookings.filter(
      (b) =>
        [
          "approved",
          "content_pending",
          "content_approved",
          "content_rejected",
          "content_rejected_resubmit",
          "pending",
          "paid",                     // Payment verification pending
          "payment_verified",         // Payment verified
          "payment_rejected",         // Payment rejected
          "payment_rejected_resubmit" // Payment rejected with resubmission option
        ] // Include all statuses for "Booked & Preparing" section
          .includes(b.status) && !isBookingExpired(b)
    );
  }, [allFetchedBookings]);

  const expiredBookings = useMemo(() => {
    // Show only recently expired ones fetched on the *first page* for clarity
    if (bookingCurrentPage !== 1) return [];
    return allFetchedBookings
      .filter((b) => {
        if (isBookingExpired(b)) {
          // Ensure correct status for display
          if (
            [
              "live",
              "content_approved",
              "approved",
              "content_pending",
            ].includes(b.status)
          ) {
            return { ...b, status: "completed" }; // Create a temporary object for mapping if needed, or just filter
          }
          return true; // Include rejected/cancelled if expired
        }
        return false;
      })
      .map((b) => ({
        ...b,
        status:
          b.status === "rejected" || b.status === "cancelled"
            ? b.status
            : "completed",
      })); // Standardize expired status for display
  }, [allFetchedBookings, bookingCurrentPage]);

  // --- Fetch Bookings ---
  const fetchBookings = useCallback(
    async (page: number) => {
      if (!token) return;
      setLoadingBookings(true);
      setBookingError(null);
      try {
        const response = await axiosInstance.get<BookingsApiResponse>(
          `/api/booking/my-bookings?page=${page}&limit=${bookingsPerPage}&sort=-createdAt`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        if (response.data.status === 1) {
          const fetchedBookings: Booking[] = response.data.data.map(
            (booking: any) => {
              // Process billboard data
              booking.billboardId =
                booking.billboardId && typeof booking.billboardId === "object"
                  ? booking.billboardId
                  : {
                      _id: "unavailable",
                      title: "Billboard Data Missing",
                      location: "N/A",
                      price: 0,
                      imageUrl: "",
                    };

              // Extract time information if available
              // The backend might store time in different formats, so we need to handle it
              if (booking.startTime && typeof booking.startTime === "string") {
                // If time is already in HH:MM format, use it directly
                if (/^\d{1,2}:\d{2}$/.test(booking.startTime)) {
                  // Format is already correct
                } else {
                  // Try to extract time from ISO string or other format
                  try {
                    const startDateTime = new Date(booking.startTime);
                    booking.startTime = `${String(startDateTime.getHours()).padStart(2, "0")}:${String(startDateTime.getMinutes()).padStart(2, "0")}`;
                  } catch (e) {
                    console.warn(
                      "Could not parse startTime:",
                      booking.startTime
                    );
                  }
                }
              }

              if (booking.endTime && typeof booking.endTime === "string") {
                // If time is already in HH:MM format, use it directly
                if (/^\d{1,2}:\d{2}$/.test(booking.endTime)) {
                  // Format is already correct
                } else {
                  // Try to extract time from ISO string or other format
                  try {
                    const endDateTime = new Date(booking.endTime);
                    booking.endTime = `${String(endDateTime.getHours()).padStart(2, "0")}:${String(endDateTime.getMinutes()).padStart(2, "0")}`;
                  } catch (e) {
                    console.warn("Could not parse endTime:", booking.endTime);
                  }
                }
              }

              // If no specific time is set, use default night hours for digital billboards
              if (!booking.startTime) booking.startTime = "18:00";
              if (!booking.endTime) booking.endTime = "23:59";

              return booking;
            }
          );

          setAllFetchedBookings(fetchedBookings); // Store all fetched bookings
          setBookingTotalPages(response.data.totalPages);
        } else {
          throw new Error(response.data.message || "Failed to fetch bookings");
        }
      } catch (error: any) {
        console.error("Error fetching bookings:", error);
        setBookingError(
          error.response?.data?.message ||
            error.message ||
            "Failed to load bookings"
        );
      } finally {
        setLoadingBookings(false);
      }
    },
    [token, bookingsPerPage]
  );

  // --- Effects ---
  useEffect(() => {
    if (user && token) {
      fetchBookings(bookingCurrentPage);
    }
    return () => {
      previewUrls.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [user, token, bookingCurrentPage, fetchBookings, previewUrls]);

  // --- Content Resubmission (Keep existing logic) ---
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setUploadedFiles(files);
      previewUrls.forEach((url) => URL.revokeObjectURL(url));
      setPreviewUrls(files.map((file) => URL.createObjectURL(file)));
    }
  };

  const removeFile = (index: number) => {
    setUploadedFiles((prev) => prev.filter((_, i) => i !== index));
    setPreviewUrls((prev) => {
      URL.revokeObjectURL(prev[index]);
      return prev.filter((_, i) => i !== index);
    });
  };

  const handleContentResubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBooking) {
      toast.error("No booking selected for content submission");
      return;
    }
    if (!token) {
      toast.error("You must be logged in to submit content");
      return;
    }
    if (uploadedFiles.length === 0) {
      toast.error("Please upload at least one file");
      return;
    }
    setIsSubmittingContent(true);
    try {
      const formData = new FormData();
      uploadedFiles.forEach((file) => formData.append("adMedia", file));

      // Use the appropriate endpoint based on the booking status
      let endpoint = `/api/booking/resubmit-content/${selectedBooking._id}`;

      // For initial content upload (pending or payment_verified)
      if (selectedBooking.status === "payment_verified" || selectedBooking.status === "pending") {
        endpoint = `/api/booking/upload-content/${selectedBooking._id}`;
      }

      const response = await axiosInstance.post(
        endpoint,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );
      if (response.data.status === 1) {
        const successMessage = (selectedBooking.status === "payment_verified" || selectedBooking.status === "pending")
          ? "Content uploaded successfully!"
          : "Content resubmitted successfully!";
        toast.success(successMessage);
        closeResubmitModal();
        fetchBookings(bookingCurrentPage);
      } else {
        throw new Error(response.data.message || "Failed");
      }
    } catch (error: any) {
      console.error("Error submitting content:", error);
      toast.error(
        error.response?.data?.message ||
          error.message ||
          "Failed to submit content. Please try again."
      );
    } finally {
      setIsSubmittingContent(false);
    }
  };

  const closeResubmitModal = () => {
    previewUrls.forEach((url) => URL.revokeObjectURL(url));
    setIsResubmitModalOpen(false);
    setUploadedFiles([]);
    setPreviewUrls([]);
    setSelectedBooking(null);
  };

  // --- Pagination Handler ---
  const handleBookingPageChange = (page: number) => {
    if (page > 0 && page <= bookingTotalPages) {
      setBookingCurrentPage(page);
      document
        .getElementById("page-top-anchor")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  // --- Loading / Not Logged In State ---
  if (!user) {
    return <SignInPrompt />;
  }

  // --- Main Render ---
  return (
    <div
      id="page-top-anchor"
      className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-100 pt-20 sm:pt-24 pb-24 px-4 sm:px-6 lg:px-8 scroll-mt-10"
    >
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <PageHeader />

        {/* Loading / Error State */}
        {loadingBookings && <LoadingState />}
        {bookingError && !loadingBookings && (
          <ErrorState message={bookingError} />
        )}

        {/* --- SECTIONS START --- */}
        {!loadingBookings && !bookingError && (
          <div className="space-y-12 md:space-y-16">
            {/* Live Campaigns Section */}
            <LiveCampaignsSection bookings={liveBookings} />

            {/* Upcoming Campaigns Section */}
            <UpcomingCampaignsSection
              bookings={upcomingBookings}
              onResubmitClick={(booking) => {
                setSelectedBooking(booking);
                setIsResubmitModalOpen(true);
              }}
            />

            {/* Recently Completed Section */}
            <RecentlyCompletedSection bookings={expiredBookings as Booking[]} />

            {/* Pagination */}
            {(liveBookings.length > 0 ||
              upcomingBookings.length > 0 ||
              bookingCurrentPage > 1) &&
              bookingTotalPages > 1 && (
                <PaginationControls
                  currentPage={bookingCurrentPage}
                  totalPages={bookingTotalPages}
                  onPageChange={handleBookingPageChange}
                />
              )}
          </div>
        )}
        {/* --- SECTIONS END --- */}

        {/* Content Resubmission Modal */}
        <AnimatePresence>
          {isResubmitModalOpen && selectedBooking && (
            <ResubmitContentModal
              booking={selectedBooking}
              isOpen={isResubmitModalOpen}
              onClose={closeResubmitModal}
              onSubmit={handleContentResubmit}
              isSubmitting={isSubmittingContent}
              uploadedFiles={uploadedFiles}
              previewUrls={previewUrls}
              onFileChange={handleFileChange}
              onRemoveFile={removeFile}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default UserBookingPage;
