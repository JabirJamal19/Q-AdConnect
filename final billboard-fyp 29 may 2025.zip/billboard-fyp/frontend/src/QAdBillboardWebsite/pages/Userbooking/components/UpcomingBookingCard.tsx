import React from "react";
import {
  FaMapMarkerAlt,
  FaExclamationTriangle,
  FaInfoCircle,
  FaEdit,
  FaCreditCard,
} from "react-icons/fa";
import { Booking } from "../utils/types";
import {
  formatCurrency,
  formatFullDate,
  getFullImageUrl,
  getStatusChip,
} from "../utils/utils";

interface UpcomingBookingCardProps {
  booking: Booking;
  onResubmitClick: () => void;
}

const UpcomingBookingCard: React.FC<UpcomingBookingCardProps> = ({
  booking,
  onResubmitClick,
}) => (
  <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow duration-300 flex flex-col h-full">
    <div className="relative h-40 sm:h-48 flex-shrink-0 bg-gray-100">
      {" "}
      {/* Slightly smaller image height */}
      <img
        src={getFullImageUrl(booking.billboardId?.imageUrl)}
        alt={booking.billboardId?.title || "Billboard"}
        className="w-full h-full object-cover opacity-90"
        onError={(e) => {
          e.currentTarget.src = "/placeholder-image.png";
        }}
      />
      <div className="absolute top-3 right-3 z-10">
        {getStatusChip(booking.status)}
      </div>
    </div>
    <div className="p-5 flex flex-col flex-grow">
      <h3
        className="text-base font-semibold text-gray-800 mb-1 truncate"
        title={booking.billboardId?.title}
      >
        {booking.billboardId?.title || "N/A"}
      </h3>
      <p className="text-xs text-gray-500 mb-3 flex items-center gap-1.5">
        <FaMapMarkerAlt className="flex-shrink-0 w-3 h-3" />{" "}
        <span className="truncate">
          {booking.billboardId?.location || "N/A"}
        </span>
      </p>

      <div className="text-xs space-y-1.5 mb-4 text-gray-600">
        <div className="flex items-center justify-between">
          <span>Starts:</span>{" "}
          <span className="font-medium">
            {formatFullDate(booking.startDate)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span>Ends:</span>{" "}
          <span className="font-medium">{formatFullDate(booking.endDate)}</span>
        </div>
        <div className="flex items-center justify-between">
          <span>Cost:</span>{" "}
          <span className="font-medium text-green-600">
            {formatCurrency(booking.totalAmount)}
          </span>
        </div>
      </div>

      {/* Action Area */}
      <div className="mt-auto pt-3 border-t border-gray-100">
        {booking.status === "content_pending" && (
          <p className="text-xs text-blue-600 font-medium text-center">
            Waiting for ad content upload.
          </p>
          // Optionally add an "Upload Content" button here if not handled elsewhere
        )}
        {(booking.status === "content_rejected" || booking.status === "content_rejected_resubmit") && (
          <>
            <div className="mb-2 p-2 bg-red-50 rounded border border-red-200">
              <p className="text-xs text-red-600 font-medium flex items-center gap-1 mb-1">
                <FaExclamationTriangle /> Content Rejected
              </p>
              {booking.rejectionReason && (
                <p className="text-xs text-red-600 line-clamp-2" title={booking.rejectionReason}>
                  {booking.rejectionReason}
                </p>
              )}
            </div>
            {booking.feedbackMessage && (
              <p className="text-xs text-blue-600 mb-2 font-medium flex items-center gap-1">
                <FaInfoCircle /> <span className="line-clamp-1" title={booking.feedbackMessage}>{booking.feedbackMessage}</span>
              </p>
            )}
            {booking.status === "content_rejected_resubmit" && (
              <button
                onClick={onResubmitClick}
                className="w-full mt-1 text-xs bg-indigo-600 text-white px-3 py-2 rounded-md hover:bg-indigo-700 transition-colors font-semibold flex items-center justify-center gap-1.5"
              >
                <FaEdit /> Resubmit Content
              </button>
            )}
          </>
        )}
        {booking.status === "pending" && (
          <p className="text-xs text-yellow-700 font-medium text-center">
            Booking pending. Waiting for content review.
          </p>
        )}
        {booking.status === "approved" && (
          <p className="text-xs text-teal-700 font-medium text-center">
            Booking approved. Ready for content.
          </p>
        )}
        {booking.status === "content_approved" && (
          <>
            <p className="text-xs text-green-700 font-medium text-center mb-2">
              Content approved. Please proceed with payment.
            </p>
            <button
              onClick={() => window.location.href = `/payment/${booking._id}`}
              className="w-full mt-1 text-xs bg-green-600 text-white px-3 py-2 rounded-md hover:bg-green-700 transition-colors font-semibold flex items-center justify-center gap-1.5"
            >
              <FaCreditCard /> Make Payment
            </button>
          </>
        )}
        {booking.status === "paid" && (
          <p className="text-xs text-blue-600 font-medium text-center">
            Payment Verification Pending. Please wait for agency review.
          </p>
        )}
        {booking.status === "payment_verified" && (
          <p className="text-xs text-green-600 font-medium text-center">
            Payment Verified. Your billboard will be activated soon.
          </p>
        )}
        {booking.status === "rejected" && (
          <div className="mb-2 p-2 bg-red-50 rounded border border-red-200">
            <p className="text-xs text-red-700 font-medium mb-1">
              Booking Rejected
            </p>
            {booking.rejectionReason && (
              <p className="text-[11px] text-red-600 line-clamp-2" title={booking.rejectionReason}>
                {booking.rejectionReason}
              </p>
            )}
          </div>
        )}

        {(booking.status === "payment_rejected" || booking.status === "payment_rejected_resubmit") && (
          <>
            <div className="mb-2 p-2 bg-red-50 rounded border border-red-200">
              <p className="text-xs text-red-700 font-medium mb-1">
                Payment Rejected
              </p>
              {booking.rejectionReason && (
                <p className="text-[11px] text-red-600 line-clamp-2" title={booking.rejectionReason}>
                  {booking.rejectionReason}
                </p>
              )}
            </div>
            {booking.status === "payment_rejected_resubmit" && (
              <button
                onClick={() => window.location.href = `/payment/${booking._id}?resubmit=true`}
                className="w-full mt-1 text-xs bg-green-600 text-white px-3 py-2 rounded-md hover:bg-green-700 transition-colors font-semibold flex items-center justify-center gap-1.5"
              >
                <FaEdit /> Resubmit Payment
              </button>
            )}
          </>
        )}
      </div>
    </div>
  </div>
);

export default UpcomingBookingCard;
