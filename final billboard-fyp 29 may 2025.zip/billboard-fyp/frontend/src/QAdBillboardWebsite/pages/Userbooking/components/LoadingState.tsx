import React from "react";
import { FaSync } from "react-icons/fa";

const LoadingState: React.FC = () => {
  return (
    <div className="flex justify-center items-center py-12">
      <FaSync className="animate-spin text-indigo-600 text-2xl" />
      <span className="ml-2 text-gray-600">Loading your bookings...</span>
    </div>
  );
};

export default LoadingState;
