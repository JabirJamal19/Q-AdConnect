import React from "react";
import { useNavigate } from "react-router-dom";
import { FaCalendarCheck } from "react-icons/fa";

interface EmptyStateProps {
  message: string;
  showButton?: boolean;
}

const EmptyState: React.FC<EmptyStateProps> = ({
  message,
  showButton = false,
}) => {
  const navigate = useNavigate();
  
  return (
    <div className="text-center py-12 px-6 bg-white rounded-xl shadow-sm border border-dashed border-gray-300">
      <FaCalendarCheck className="mx-auto h-12 w-12 text-gray-300" />
      <h3 className="mt-3 text-base font-medium text-gray-600">{message}</h3>
      {showButton && (
        <div className="mt-5">
          <button
            onClick={() => navigate("/billboard-list")}
            className="px-5 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 text-sm"
          >
            Find Billboards
          </button>
        </div>
      )}
    </div>
  );
};

export default EmptyState;
