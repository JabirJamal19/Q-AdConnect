import React from "react";
import { useNavigate } from "react-router-dom";
import { FaCalendarCheck } from "react-icons/fa";

const SignInPrompt: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-100 to-blue-50 pt-28 pb-20 px-4 flex items-center justify-center">
      <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full text-center">
        <FaCalendarCheck className="mx-auto text-4xl text-indigo-500 mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          Sign In Required
        </h2>
        <p className="text-gray-600 mb-6">
          Please sign in to view your bookings and campaigns.
        </p>
        <button
          onClick={() => navigate("/auth/signin")}
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Sign In
        </button>
      </div>
    </div>
  );
};

export default SignInPrompt;
