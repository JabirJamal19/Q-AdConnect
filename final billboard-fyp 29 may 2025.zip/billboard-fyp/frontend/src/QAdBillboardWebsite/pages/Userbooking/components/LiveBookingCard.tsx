import React, { useCallback } from "react";
import { FaMapMarkerAlt } from "react-icons/fa";
import toast from "react-hot-toast";
import { Booking } from "../utils/types";
import CountdownTimer from "./CountdownTimer";
import {
  formatCurrency,
  formatDate,
  getFullImageUrl,
  getStatusChip,
} from "../utils/utils";

interface LiveBookingCardProps {
  booking: Booking;
}

const LiveBookingCard: React.FC<LiveBookingCardProps> = ({ booking }) => {
  const handleExpire = useCallback(() => {
    // When a booking expires, refresh the bookings list
    toast.success("A campaign has expired. Refreshing your bookings...");
    // Refresh bookings after a short delay to allow the user to see the toast
    setTimeout(() => {
      window.location.reload();
    }, 2000);
  }, []);

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200 hover:shadow-xl transition-shadow duration-300 flex flex-col h-full">
      <div className="relative h-48 sm:h-56 flex-shrink-0">
        <img
          src={getFullImageUrl(booking.billboardId?.imageUrl)}
          alt={booking.billboardId?.title || "Billboard"}
          className="w-full h-full object-cover"
          onError={(e) => {
            e.currentTarget.src = "/placeholder-image.png";
          }}
        />
        <div className="absolute top-3 right-3 z-10">
          {getStatusChip(booking.status)}
        </div>
        {/* Optional: Dim overlay to make text more readable if needed */}
        {/* <div className="absolute inset-0 bg-gradient-to-t from-black/10 via-transparent to-transparent"></div> */}
      </div>
      <div className="p-5 flex flex-col flex-grow">
        <h3
          className="text-lg font-semibold text-gray-800 mb-1 truncate"
          title={booking.billboardId?.title}
        >
          {booking.billboardId?.title || "N/A"}
        </h3>
        <p className="text-sm text-gray-500 mb-3 flex items-center gap-1.5">
          <FaMapMarkerAlt className="flex-shrink-0 w-4 h-4" />{" "}
          <span className="truncate">
            {booking.billboardId?.location || "N/A"}
          </span>
        </p>
        <div className="text-xs space-y-1.5 mb-4 text-gray-600 border-t pt-3">
          <div className="flex items-center justify-between">
            <span>Start Date:</span>{" "}
            <span className="font-medium">{formatDate(booking.startDate)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span>End Date:</span>{" "}
            <span className="font-medium">{formatDate(booking.endDate)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Total Cost:</span>{" "}
            <span className="font-medium text-green-600">
              {formatCurrency(booking.totalAmount)}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span>Booking ID:</span>{" "}
            <span className="font-medium text-gray-500">
              {booking._id.slice(-6)}
            </span>
          </div>
        </div>

        {/* Countdown Timer */}
        <div className="mt-auto mb-3">
          <CountdownTimer
            endDate={booking.endDate}
            endTime={booking.endTime}
            onExpire={handleExpire}
          />
        </div>
      </div>
    </div>
  );
};

export default LiveBookingCard;
