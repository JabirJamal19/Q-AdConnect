import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { FaCalendarCheck } from "react-icons/fa";

const PageHeader: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="mb-10"
    >
      <div className="flex flex-col md:flex-row items-center justify-between bg-white rounded-xl shadow-lg p-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
            My Dashboard
          </h1>
          <p className="text-gray-500 mt-1 text-base">
            Overview of your active and upcoming campaigns.
          </p>
        </div>
        <button
          onClick={() => navigate("/billboard-list")}
          className="mt-4 md:mt-0 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2"
        >
          <FaCalendarCheck /> Book New Billboard
        </button>
      </div>
    </motion.div>
  );
};

export default PageHeader;
