import React from "react";
import { motion } from "framer-motion";
import { FaHistory } from "react-icons/fa";
import { Booking } from "../utils/types";
import { ExpiredBookingCard } from "./";

interface RecentlyCompletedSectionProps {
  bookings: Booking[];
}

const RecentlyCompletedSection: React.FC<RecentlyCompletedSectionProps> = ({
  bookings,
}) => {
  if (bookings.length === 0) return null;

  return (
    <motion.section
      id="expired-campaigns-section"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.3 }}
    >
      <h2 className="text-xl font-semibold text-gray-600 mb-5 flex items-center gap-3">
        <FaHistory className="text-gray-500" /> Recently Completed
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {bookings.map((booking) => (
          <motion.div
            key={booking._id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <ExpiredBookingCard
              booking={{
                ...booking,
                status: booking.status as Booking["status"],
              }}
            />
          </motion.div>
        ))}
      </div>
    </motion.section>
  );
};

export default RecentlyCompletedSection;
