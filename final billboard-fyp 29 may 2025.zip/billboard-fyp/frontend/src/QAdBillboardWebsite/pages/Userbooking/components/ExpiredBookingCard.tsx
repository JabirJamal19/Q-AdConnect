import React from "react";
import { useNavigate } from "react-router-dom";
import { Booking } from "../utils/types";
import { formatFullDate, getFullImageUrl } from "../utils/utils";

interface ExpiredBookingCardProps {
  booking: Booking;
}

const ExpiredBookingCard: React.FC<ExpiredBookingCardProps> = ({ booking }) => {
  const navigate = useNavigate();

  return (
    <div className="bg-gray-100 rounded-lg shadow-sm overflow-hidden border border-gray-200 hover:shadow-md transition-shadow duration-200 group flex flex-col h-full">
      <div className="relative h-36 sm:h-40 opacity-70 group-hover:opacity-90 transition-opacity duration-300">
        <img
          src={getFullImageUrl(booking.billboardId?.imageUrl)}
          alt={booking.billboardId?.title || "Billboard"}
          className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-300"
          onError={(e) => {
            e.currentTarget.src = "/placeholder-image.png";
          }}
        />
        <div className="absolute inset-0 bg-black/40"></div>
        <div
          className={`absolute top-2 right-2 text-white text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider ${booking.status === "cancelled" || booking.status === "rejected" ? "bg-red-600" : "bg-gray-600"}`}
        >
          {booking.status === "cancelled"
            ? "Cancelled"
            : booking.status === "rejected"
              ? "Rejected"
              : "Completed"}
        </div>
      </div>
      <div className="p-3 flex flex-col flex-grow">
        <h4
          className="text-xs font-semibold text-gray-700 truncate"
          title={booking.billboardId?.title}
        >
          {booking.billboardId?.title || "N/A"}
        </h4>
        <p className="text-[11px] text-gray-500 truncate mb-2">
          {booking.billboardId?.location || "N/A"}
        </p>
        <p className="text-[11px] text-gray-500 mb-3">
          {formatFullDate(booking.startDate)} -{" "}
          {formatFullDate(booking.endDate)}
        </p>
        <div className="mt-auto flex justify-end">
          {booking.status !== "rejected" && booking.status !== "cancelled" && (
            <button
              onClick={() => navigate("/billboard-list")}
              className="text-[10px] bg-indigo-100 text-indigo-700 px-2.5 py-1 rounded-md hover:bg-indigo-200 transition-colors font-medium"
            >
              Book Again
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExpiredBookingCard;
