import React from "react";
import { motion } from "framer-motion";
import { FaWifi } from "react-icons/fa";
import { Booking } from "../utils/types";
import { LiveBookingCard, EmptyState } from "./";

interface LiveCampaignsSectionProps {
  bookings: Booking[];
}

const LiveCampaignsSection: React.FC<LiveCampaignsSectionProps> = ({
  bookings,
}) => {
  return (
    <motion.section
      id="live-campaigns-section"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <h2 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center gap-3">
        <FaWifi className="text-red-500 animate-pulse" /> Live Campaigns
      </h2>
      {bookings.length === 0 ? (
        <EmptyState
          message="No campaigns are currently live."
          showButton={true}
        />
      ) : (
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          variants={{
            hidden: { opacity: 0 },
            show: { opacity: 1, transition: { staggerChildren: 0.07 } },
          }}
          initial="hidden"
          animate="show"
        >
          {bookings.map((booking) => (
            <motion.div
              key={booking._id}
              variants={{
                hidden: { y: 20, opacity: 0 },
                show: { y: 0, opacity: 1 },
              }}
            >
              <LiveBookingCard booking={booking} />
            </motion.div>
          ))}
        </motion.div>
      )}
    </motion.section>
  );
};

export default LiveCampaignsSection;
