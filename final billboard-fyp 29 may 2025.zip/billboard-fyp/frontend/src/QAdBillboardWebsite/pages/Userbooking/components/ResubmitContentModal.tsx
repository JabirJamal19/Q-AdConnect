import React from "react";
import { motion } from "framer-motion";
import { FaTimes, FaCloudUploadAlt, FaTrashAlt, FaSync } from "react-icons/fa";
import { Booking } from "../utils/types";

interface ResubmitModalProps {
  booking: Booking;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => Promise<void>;
  isSubmitting: boolean;
  uploadedFiles: File[];
  previewUrls: string[];
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemoveFile: (index: number) => void;
}

const ResubmitContentModal: React.FC<ResubmitModalProps> = ({
  booking,
  isOpen,
  onClose,
  onSubmit,
  isSubmitting,
  uploadedFiles,
  previewUrls,
  onFileChange,
  onRemoveFile,
}) => {
  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="bg-white rounded-xl p-6 md:p-8 w-full max-w-lg shadow-xl max-h-[90vh] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-5 pb-3 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800">
            {booking.status === "payment_verified" || booking.status === "pending" ? "Upload Ad Content" : "Resubmit Ad Content"}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-red-500 transition-colors"
            aria-label="Close modal"
          >
            <FaTimes size={20} />
          </button>
        </div>
        <p className="text-sm text-gray-600 mb-4">
          For:{" "}
          <strong className="text-indigo-700">
            {booking.billboardId?.title}
          </strong>
        </p>
        {booking.rejectionReason && (
          <div className="mb-3 p-3 bg-red-50 rounded-lg border border-red-200">
            <h3 className="text-sm font-semibold text-red-700 mb-1">Rejection Reason:</h3>
            <p className="text-xs text-red-600">{booking.rejectionReason}</p>
          </div>
        )}
        {booking.feedbackMessage && (
          <div className="mb-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="text-sm font-semibold text-blue-700 mb-1">Agency Feedback:</h3>
            <p className="text-xs text-blue-600">{booking.feedbackMessage}</p>
          </div>
        )}

        <div className="mb-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
          <h3 className="text-sm font-semibold text-yellow-700 mb-1">Content Guidelines:</h3>
          <ul className="text-xs text-yellow-600 list-disc pl-4 space-y-1">
            <li>Images should be high resolution (minimum 1920x1080 pixels)</li>
            <li>Supported formats: JPEG, PNG, GIF for images; MP4 for videos</li>
            <li>Content must comply with local advertising regulations</li>
            <li>Avoid content that may be considered offensive or inappropriate</li>
            <li>Maximum file size: 100MB per file</li>
          </ul>
        </div>
        <form onSubmit={onSubmit} className="space-y-5">
          <div>
            <label
              htmlFor="ad-files-upload"
              className="block text-sm font-medium text-gray-700 mb-1.5"
            >
              Upload New Files (Max 5)
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md hover:border-indigo-400 transition-colors">
              {/* ... File Input Area ... */}
              <div className="space-y-1 text-center">
                <FaCloudUploadAlt className="mx-auto h-12 w-12 text-gray-400" />
                <div className="flex text-sm text-gray-600">
                  <label
                    htmlFor="ad-files-upload"
                    className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                  >
                    <span>Upload files</span>
                    <input
                      id="ad-files-upload"
                      name="ad-files-upload"
                      type="file"
                      multiple
                      className="sr-only"
                      onChange={onFileChange}
                      disabled={isSubmitting}
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">
                  Images or Videos up to 100MB each
                </p>
              </div>
            </div>
          </div>
          {(uploadedFiles.length > 0 || previewUrls.length > 0) && (
            <div className="space-y-3 max-h-60 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
              <h3 className="text-sm font-medium text-gray-800 border-b pb-1">
                Selected Files:
              </h3>
              {uploadedFiles.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between bg-gray-50 p-2 rounded text-sm"
                >
                  <span className="text-gray-700 truncate mr-2">
                    {file.name}
                  </span>
                  <div className="flex items-center flex-shrink-0">
                    <span className="text-xs text-gray-500 mr-2">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </span>
                    <button
                      type="button"
                      onClick={() => onRemoveFile(index)}
                      className="text-red-500 hover:text-red-700"
                      disabled={isSubmitting}
                    >
                      <FaTrashAlt size={14} />
                    </button>
                  </div>
                </div>
              ))}
              {previewUrls.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                  {previewUrls.map((url, index) => (
                    <img
                      key={index}
                      src={url}
                      alt={`Preview ${index + 1}`}
                      className="w-full h-24 object-cover rounded border border-gray-200"
                    />
                  ))}
                </div>
              )}
            </div>
          )}
          <div className="flex justify-end space-x-3 pt-5 border-t border-gray-200 mt-6">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-5 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm font-medium transition disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || uploadedFiles.length === 0}
              className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 text-sm font-medium flex items-center justify-center min-w-[110px] transition shadow-md hover:shadow-lg disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <FaSync className="animate-spin" size={18} />
              ) : (
                booking.status === "payment_verified" || booking.status === "pending" ? "Upload" : "Resubmit"
              )}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default ResubmitContentModal;
