import React, { useState, useEffect, useRef } from "react";
import { FaClock, FaRegClock } from "react-icons/fa";

interface CountdownTimerProps {
  endDate: string;
  endTime?: string;
  onExpire?: () => void;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({
  endDate,
  endTime,
  onExpire,
}) => {
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });
  const [isExpired, setIsExpired] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Calculate end datetime
    const calculateTimeLeft = () => {
      const now = new Date();
      const end = new Date(endDate);

      // If we have endTime, use it for precise expiration
      if (endTime) {
        const [hours, minutes] = endTime.split(":").map(Number);
        end.setHours(hours, minutes, 0, 0);
      } else {
        // Default to end of day if no specific time
        end.setHours(23, 59, 59, 999);
      }

      const difference = end.getTime() - now.getTime();

      if (difference <= 0) {
        // Timer expired
        setIsExpired(true);
        // Call onExpire callback if provided
        if (onExpire) {
          onExpire();
        }
        return { days: 0, hours: 0, minutes: 0, seconds: 0 };
      }

      // Calculate time units
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor(
        (difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
      );
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      return { days, hours, minutes, seconds };
    };

    // Initial calculation
    setTimeLeft(calculateTimeLeft());

    // Set up interval to update countdown
    timerRef.current = setInterval(() => {
      const timeLeft = calculateTimeLeft();
      setTimeLeft(timeLeft);

      // Clear interval if expired
      if (
        timeLeft.days === 0 &&
        timeLeft.hours === 0 &&
        timeLeft.minutes === 0 &&
        timeLeft.seconds === 0
      ) {
        if (timerRef.current) {
          clearInterval(timerRef.current);
        }
      }
    }, 1000);

    // Cleanup on unmount
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [endDate, endTime, onExpire]);

  if (isExpired) {
    return (
      <div className="bg-red-100 text-red-800 px-3 py-2 rounded-md text-xs font-medium flex items-center gap-1.5">
        <FaRegClock />
        <span>Campaign Expired</span>
      </div>
    );
  }

  return (
    <div className="bg-blue-50 text-blue-800 px-3 py-2 rounded-md text-xs font-medium">
      <div className="flex items-center justify-between gap-1 mb-1">
        <FaClock className="text-blue-600" />
        <span>Campaign Ends In:</span>
      </div>
      <div className="grid grid-cols-4 gap-1 text-center">
        <div className="bg-white px-1 py-0.5 rounded shadow-sm">
          <div className="text-sm font-bold">{timeLeft.days}</div>
          <div className="text-[10px] text-gray-500">Days</div>
        </div>
        <div className="bg-white px-1 py-0.5 rounded shadow-sm">
          <div className="text-sm font-bold">{timeLeft.hours}</div>
          <div className="text-[10px] text-gray-500">Hours</div>
        </div>
        <div className="bg-white px-1 py-0.5 rounded shadow-sm">
          <div className="text-sm font-bold">{timeLeft.minutes}</div>
          <div className="text-[10px] text-gray-500">Mins</div>
        </div>
        <div className="bg-white px-1 py-0.5 rounded shadow-sm">
          <div className="text-sm font-bold">{timeLeft.seconds}</div>
          <div className="text-[10px] text-gray-500">Secs</div>
        </div>
      </div>
    </div>
  );
};

export default CountdownTimer;
