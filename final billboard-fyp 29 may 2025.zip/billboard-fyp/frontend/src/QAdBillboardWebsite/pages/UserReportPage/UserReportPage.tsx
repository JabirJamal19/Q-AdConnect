// ReportPage.tsx
import React, { useState, useEffect, useCallback } from "react";
import axios from "../../../axiosInstance";
import { useAuthStore } from "../../../stores/authStore";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";

interface Report {
  _id: string;
  title: string;
  description: string;
  status: "pending" | "in-progress" | "resolved" | "rejected";
  statusNote?: string;
  createdAt: string;
  updatedAt: string;
}

const UserReportPage: React.FC = () => {
  const { token } = useAuthStore();
  const navigate = useNavigate();

  // Form state for report submission
  const [formData, setFormData] = useState({ title: "", description: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch reports submitted by the current user
  const fetchUserReports = useCallback(async () => {
    if (!token) return;

    setLoading(true);
    try {
      const { data } = await axios.get("/api/report/user-reports", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setReports(data.reports);
    } catch (err: any) {
      console.error("Error fetching reports:", err);
      toast.error(err.response?.data?.message || "Failed to fetch reports.");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    if (!token) {
      // Redirect to login if user is not authenticated
      toast.error("Please login to view reports.");
      navigate("/login");
      return;
    }
    fetchUserReports();
  }, [token, navigate, fetchUserReports]);

  // Handle form input changes
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Submit a new report
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!token) {
      toast.error("Please login to submit a report.");
      navigate("/login");
      return;
    }

    setIsSubmitting(true);
    try {
      const { data } = await axios.post("/api/report/submit", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      if (data.status === 1) {
        toast.success("Report submitted successfully.");
        setFormData({ title: "", description: "" });
        fetchUserReports(); // Refresh list after submission
      } else {
        toast.error(data.message || "Failed to submit report.");
      }
    } catch (err: any) {
      console.error("Error submitting report:", err);
      toast.error(err.response?.data?.message || "Failed to submit report.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Map report status to a Tailwind color class
  const getStatusColor = (status: string) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      "in-progress": "bg-blue-100 text-blue-800",
      resolved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
    };
    return colors[status as keyof typeof colors] || colors.pending;
  };

  return (
    <div className="min-h-screen mt-16 bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Report Submission Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <header className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900">
              Submit a Report
            </h2>
            <p className="mt-2 text-gray-600">
              Report any issues or concerns regarding billboards.
            </p>
          </header>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label
                htmlFor="title"
                className="block text-sm font-medium text-gray-700"
              >
                Report Title
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
                placeholder="Enter a brief title"
                className="mt-1 block w-full px-4 py-3 rounded-lg border border-gray-300 shadow-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
              />
            </div>
            <div>
              <label
                htmlFor="description"
                className="block text-sm font-medium text-gray-700"
              >
                Description
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
                rows={6}
                placeholder="Describe the issue in detail..."
                className="mt-1 block w-full px-4 py-3 rounded-lg border border-gray-300 shadow-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
              />
            </div>
            <div>
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full flex justify-center items-center px-6 py-3 rounded-lg font-medium text-white transition-all ${
                  isSubmitting
                    ? "bg-indigo-400 cursor-not-allowed"
                    : "bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-500/20"
                }`}
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                        fill="none"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    Submitting...
                  </span>
                ) : (
                  "Submit Report"
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Reports List */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Your Reports
          </h2>
          {loading ? (
            <div className="flex justify-center items-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : reports.length > 0 ? (
            <div className="space-y-4">
              {reports.map((report) => (
                <div
                  key={report._id}
                  className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
                >
                  <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {report.title}
                      </h3>
                      <p className="text-gray-600 mt-2">{report.description}</p>

                      {report.statusNote && (
                        <div className="mt-4 p-4 bg-gray-50 rounded-md border-l-4 border-indigo-500">
                          <p className="text-sm font-medium text-gray-700">
                            Admin Response:
                          </p>
                          <p className="text-sm text-gray-600 mt-1">
                            {report.statusNote}
                          </p>
                        </div>
                      )}

                      <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-gray-500">
                        <div>
                          <span className="font-medium">Submitted:</span>{" "}
                          {new Date(report.createdAt).toLocaleDateString(
                            undefined,
                            {
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            }
                          )}
                        </div>

                        {report.updatedAt &&
                          report.updatedAt !== report.createdAt && (
                            <div>
                              <span className="font-medium">Last Updated:</span>{" "}
                              {new Date(report.updatedAt).toLocaleDateString(
                                undefined,
                                {
                                  year: "numeric",
                                  month: "short",
                                  day: "numeric",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                }
                              )}
                            </div>
                          )}
                      </div>
                    </div>

                    <div className="flex flex-col items-center">
                      <span
                        className={`px-4 py-2 rounded-full text-sm text-center font-medium ${getStatusColor(report.status)}`}
                      >
                        {report.status.replace("-", " ")}
                      </span>

                      {report.status === "pending" && (
                        <p className="text-xs text-gray-500 mt-2">
                          Awaiting review
                        </p>
                      )}
                      {report.status === "in-progress" && (
                        <p className="text-xs text-blue-600 mt-2">
                          Being processed
                        </p>
                      )}
                      {report.status === "resolved" && (
                        <p className="text-xs text-green-600 mt-2">
                          Issue resolved
                        </p>
                      )}
                      {report.status === "rejected" && (
                        <p className="text-xs text-red-600 mt-2">
                          Could not process
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500">
              No reports submitted yet.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserReportPage;
