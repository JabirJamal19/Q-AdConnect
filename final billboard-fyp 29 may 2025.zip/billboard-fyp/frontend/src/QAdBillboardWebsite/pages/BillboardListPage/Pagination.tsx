// frontend/components/shared/Pagination.tsx
import React from "react";
import { FaChevronLeft, FaChevronRight } from "react-icons/fa";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  maxVisiblePages?: number; // How many page numbers to show max (excluding prev/next/ellipses)
}

const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
  maxVisiblePages = 5, // Sensible default
}) => {
  if (totalPages <= 1) {
    return null; // Don't render pagination if there's only one page or less
  }

  const generatePageNumbers = (): (number | string)[] => {
    const pages: (number | string)[] = [];
    const halfVisible = Math.floor(maxVisiblePages / 2);

    if (totalPages <= maxVisiblePages + 2) {
      // Show all pages if total is small enough
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      pages.push(1);

      // Ellipsis after first page?
      let startPage = Math.max(2, currentPage - halfVisible);
      let endPage = Math.min(totalPages - 1, currentPage + halfVisible);

      // Adjust if near the beginning
      if (currentPage - halfVisible <= 2) {
        endPage = Math.min(totalPages - 1, maxVisiblePages);
      }
      // Adjust if near the end
      if (currentPage + halfVisible >= totalPages - 1) {
        startPage = Math.max(2, totalPages - maxVisiblePages + 1);
      }

      if (startPage > 2) {
        pages.push("...");
      }

      // Generate middle pages
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }

      // Ellipsis before last page?
      if (endPage < totalPages - 1) {
        pages.push("...");
      }

      // Always show last page
      pages.push(totalPages);
    }

    return pages;
  };

  const pageNumbers = generatePageNumbers();

  return (
    <nav
      aria-label="Pagination"
      className="flex flex-col items-center space-y-4"
    >
      <div className="flex items-center justify-center space-x-1 sm:space-x-2">
        {/* Previous Button */}
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className="p-2.5 rounded-lg bg-white text-gray-500 hover:bg-gray-100 hover:text-blue-600 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white disabled:hover:text-gray-500 transition-all duration-200 shadow-sm border border-gray-200"
          aria-label="Previous Page"
        >
          <FaChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Page Number Buttons */}
        {pageNumbers.map((page, index) =>
          typeof page === "number" ? (
            <button
              key={`page-${page}`}
              onClick={() => onPageChange(page)}
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-lg font-medium transition-all duration-200 shadow-sm border border-gray-200 text-xs sm:text-sm ${
                currentPage === page
                  ? "bg-blue-600 text-white border-blue-600 scale-110 z-10" // Active state
                  : "bg-white text-gray-600 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300" // Inactive state
              }`}
              aria-current={currentPage === page ? "page" : undefined}
              aria-label={`Go to page ${page}`}
            >
              {page}
            </button>
          ) : (
            // Ellipsis
            <span
              key={`ellipsis-${index}`}
              className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center text-gray-400 text-sm"
              aria-hidden="true"
            >
              ...
            </span>
          )
        )}

        {/* Next Button */}
        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className="p-2.5 rounded-lg bg-white text-gray-500 hover:bg-gray-100 hover:text-blue-600 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white disabled:hover:text-gray-500 transition-all duration-200 shadow-sm border border-gray-200"
          aria-label="Next Page"
        >
          <FaChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>
      {/* Optional: Page Info Text */}
      <p className="text-sm text-gray-500">
        Page <span className="font-semibold text-gray-700">{currentPage}</span>{" "}
        of <span className="font-semibold text-gray-700">{totalPages}</span>
      </p>
    </nav>
  );
};

export default Pagination;
