// frontend/components/customer/BillboardListPage.tsx
import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../../../axiosInstance";
import FilterBar from "./FilterBar"; // Assuming FilterBar exists and works

import { useMemo } from "react";
import Pagination from "./Pagination"; // <--- Import the new Pagination component
import {
  FaSearch,
  FaMapMarkerAlt,
  FaRuler,
  // FaChevronLeft, // Moved to Pagination component
  // FaChevronRight, // Moved to Pagination component
  FaExclamationTriangle,
  FaImage,
} from "react-icons/fa";
import { motion, AnimatePresence } from "framer-motion"; // Added AnimatePresence
import { toast } from "react-hot-toast";

// Interfaces (Billboard, BillboardApiResponse) remain the same...
interface Billboard {
  _id: string;
  title: string;
  description?: string;
  location: string;
  city?: string;
  area?: string;
  price: number;
  size: string;
  status: "active" | "inactive";
  imageUrl?: string;
  images?: string[];
}
interface BillboardApiResponse {
  status: number;
  message: string;
  data: Billboard[];
  total: number;
  totalPages: number;
  page: number;
}

const BillboardListPage: React.FC = () => {
  const navigate = useNavigate();
  const [billboards, setBillboards] = useState<Billboard[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalBillboards, setTotalBillboards] = useState(0);
  const billboardsPerPage = 2; // <--- Updated to 2

  const [filters, setFilters] = useState({
    city: "all",
    location: "all",
    search: "",
  });

  // --- fetchBillboards remains largely the same ---
  const fetchBillboards = useCallback(
    async (page: number, currentFilters: typeof filters) => {
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: billboardsPerPage.toString(),
        });
        // Append filters to params (same logic as before)
        if (currentFilters.city && currentFilters.city !== "all")
          params.append("city", currentFilters.city);
        if (currentFilters.location && currentFilters.location !== "all")
          params.append("location", currentFilters.location);
        if (currentFilters.priceMin)
          params.append("priceMin", currentFilters.priceMin);
        if (currentFilters.priceMax)
          params.append("priceMax", currentFilters.priceMax);
        if (currentFilters.size) params.append("size", currentFilters.size);
        if (currentFilters.search)
          params.append("search", currentFilters.search);
        // if (currentFilters.status && currentFilters.status !== 'all') params.append('status', currentFilters.status); // Add if FilterBar supports status

        const response = await axios.get<BillboardApiResponse>(
          `/api/billboard/public/list?${params.toString()}`
        );

        if (response.data.status === 1) {
          setBillboards(response.data.data);
          setTotalBillboards(response.data.total);
          setTotalPages(response.data.totalPages);
          // Reset page if fetched page is out of bounds (e.g., after filtering)
          if (page > response.data.totalPages && response.data.totalPages > 0) {
            setCurrentPage(response.data.totalPages);
          } else if (page <= 0 && response.data.totalPages > 0) {
            setCurrentPage(1);
          }
        } else {
          throw new Error(response.data.message || "Failed to load billboards");
        }
      } catch (err: any) {
        console.error("Error fetching billboards:", err);
        let message = "An unexpected error occurred.";
        if (err.code === "ERR_NETWORK")
          message =
            "Unable to connect to the server. Please check your connection or if the server is running.";
        else if (err.response)
          message =
            err.response.data?.message ||
            `Server Error: ${err.response.status}`;
        else if (err.message) message = err.message;
        setError(message);
        toast.error(message);
        setBillboards([]);
        setTotalBillboards(0);
        setTotalPages(1);
        setCurrentPage(1); // Reset page on error
      } finally {
        setLoading(false);
      }
    },
    [billboardsPerPage]
  );

  useEffect(() => {
    fetchBillboards(currentPage, filters);
  }, [currentPage, filters, fetchBillboards]);

  // --- handleFilterChange remains the same ---
  // This function receives the *entire updated filters object* from FilterBar
  const handleFilterChange = (newFilters: typeof filters) => {
    setFilters(newFilters); // Update the entire filter state
    setCurrentPage(1); // Reset to first page when filters change
  };

  // --- handlePageChange remains the same ---
  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages && page !== currentPage) {
      setCurrentPage(page);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  // Format price function
  const formatCurrency = (amount: number) => {
    /* ... same as before ... */
    return new Intl.NumberFormat("en-PK", {
      style: "currency",
      currency: "PKR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // --- Animation Variants ---
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1, // Stagger animation for each card
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 12,
      },
    },
  };
  // --- Calculate dynamic options ---
  const availableCities = useMemo(() => {
    const cities = new Set(billboards.map((b) => b.city).filter(Boolean));
    return ["all", ...Array.from(cities).sort()];
  }, [billboards]);

  const availableLocations = useMemo(() => {
    let locations = new Set<string>();
    if (filters.city === "all") {
      locations = new Set(billboards.map((b) => b.location).filter(Boolean));
    } else {
      locations = new Set(
        billboards
          .filter((b) => b.city === filters.city && b.location)
          .map((b) => b.location)
      );
    }
    return ["all", ...Array.from(locations).sort()];
  }, [billboards, filters.city]);

  return (
    <div className="min-h-screen mt-16 bg-gradient-to-br from-gray-50 via-white to-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      {/* Hero Section (Optional - Keep if desired) */}
      <div className="max-w-7xl mx-auto mb-12 text-center relative overflow-hidden rounded-3xl bg-blue-600 p-8 shadow-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-400 opacity-90"></div>
        <div className="relative z-10">
          <h1 className="text-4xl font-bold text-white mb-4">
            Find Your Perfect Billboard
          </h1>
          <p className="text-xl text-blue-100">
            Discover premium advertising spaces across Pakistan
          </p>
        </div>
      </div>

      {/* Filter Section */}
      <div className="max-w-7xl mx-auto mb-10">
        {/* Pass ONLY filters state and the callback */}
        <FilterBar
          filters={filters}
          onFilterChange={handleFilterChange}
          availableCities={availableCities} // Pass dynamic cities
          availableLocations={availableLocations} // Pass dynamic (and potentially filtered) locations
        />
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center h-60">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-600"></div>
        </div>
      )}

      {/* Error State */}
      {!loading && error && (
        <div className="max-w-5xl mx-auto text-center py-16 bg-red-50 rounded-2xl shadow-lg border border-red-200">
          <FaExclamationTriangle className="mx-auto text-5xl text-red-500 mb-4" />
          <h3 className="text-2xl font-semibold text-red-800 mb-2">
            Oops! Something went wrong.
          </h3>
          <p className="text-red-600 mb-6">{error}</p>
          <button
            onClick={() => fetchBillboards(currentPage, filters)}
            className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      )}

      {/* Content Area: Only show if not loading and no error */}
      {!loading && !error && (
        <>
          {/* Billboard Count / Results Header */}
          <div className="max-w-5xl mx-auto mb-6 text-center sm:text-left text-gray-600 text-sm">
            {totalBillboards > 0
              ? `Showing ${
                  (currentPage - 1) * billboardsPerPage + 1
                }-${Math.min(
                  currentPage * billboardsPerPage,
                  totalBillboards
                )} of ${totalBillboards} billboards`
              : ""}{" "}
            {/* Show nothing or '0 results' if empty */}
          </div>

          {/* Billboard Grid */}
          {billboards.length > 0 ? (
            <motion.div
              key={currentPage} // Key changes on page change to re-trigger stagger
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 px-4" // Always 2 columns on medium+
            >
              <AnimatePresence>
                {" "}
                {/* Needed if items can be removed by filtering */}
                {billboards.map((billboard) => (
                  <motion.div
                    key={billboard._id}
                    variants={itemVariants}
                    layout // Animate layout changes smoothly
                    whileHover={{
                      y: -6,
                      scale: 1.01,
                      boxShadow:
                        "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
                    }} // Enhanced hover
                    className="bg-white rounded-xl shadow-md overflow-hidden cursor-pointer group border border-gray-100" // Added subtle border
                    onClick={() => navigate(`/billboards/${billboard._id}`)} // Navigate to detail page
                  >
                    {/* Image Handling */}
                    <div className="relative h-56 sm:h-64 bg-gray-100 overflow-hidden">
                      {" "}
                      {/* Consistent height */}
                      {billboard.imageUrl ? (
                        <>
                          <img
                            src={billboard.imageUrl}
                            alt={billboard.title}
                            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300 ease-in-out"
                            loading="lazy"
                            onError={(e) => {
                              const target = e.currentTarget;
                              target.onerror = null;
                              target.style.display = "none";
                              const placeholder = target.nextElementSibling;
                              if (placeholder)
                                placeholder.classList.remove("hidden");
                            }}
                          />
                          <div className="hidden absolute inset-0 w-full h-full flex items-center justify-center text-gray-400 bg-gray-200">
                            <FaImage className="w-12 h-12" />
                          </div>
                        </>
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400 bg-gray-200">
                          <FaImage className="w-12 h-12" />
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="p-5">
                      {" "}
                      {/* Slightly reduced padding */}
                      <h2
                        className="text-lg font-semibold text-gray-800 mb-2 line-clamp-1"
                        title={billboard.title}
                      >
                        {billboard.title}
                      </h2>
                      <div className="flex items-center gap-2 text-gray-500 mb-2 text-sm">
                        <FaMapMarkerAlt className="text-blue-500 w-4 h-4 flex-shrink-0" />
                        <span
                          className="truncate"
                          title={[billboard.location, billboard.city]
                            .filter(Boolean)
                            .join(", ")}
                        >
                          {[billboard.location, billboard.city]
                            .filter(Boolean)
                            .join(", ")}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-500 mb-3 text-sm">
                        <FaRuler className="text-blue-500 w-4 h-4 flex-shrink-0" />
                        <span>{billboard.size || "N/A"}</span>
                      </div>
                      <div className="flex justify-between items-center mt-4">
                        <div className="text-blue-600 font-bold text-lg">
                          {formatCurrency(billboard.price)}
                          <span className="text-xs text-gray-500 ml-1 font-normal">
                            /day
                          </span>
                        </div>
                        <span className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-xs font-medium shadow-sm">
                          View Details
                        </span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </motion.div>
          ) : (
            // No Results Message (when filtering leads to none)
            <div className="text-center py-16 bg-white rounded-2xl shadow-lg max-w-2xl mx-auto mt-8 border border-gray-100">
              <div className="text-gray-400 text-6xl mb-4">🔍</div>
              <h3 className="text-2xl font-semibold text-gray-700 mb-2">
                No Billboards Found
              </h3>
              <p className="text-gray-500">
                Try adjusting your search or filter criteria.
              </p>
            </div>
          )}

          {/* Modern Pagination - Only show if needed */}
          {totalPages > 1 && billboards.length > 0 && (
            <div className="mt-16">
              {" "}
              {/* Add margin top */}
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
              />
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default BillboardListPage;
