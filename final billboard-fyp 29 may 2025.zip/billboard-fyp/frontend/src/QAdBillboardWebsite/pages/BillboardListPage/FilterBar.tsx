import React from "react";
import {
  FaFilter,
  FaMapMarkerAlt,
  FaCity,
  FaSearch,
  FaTimes,
  // FaRuler, // Keep if size filter is added later
} from "react-icons/fa";

// Interface for the filters object structure (matches state in BillboardListPage)
interface Filters {
  city: string;
  location: string;
  size: string; // Keep if size filter is planned
  search: string;
}

// Interface for props expected by FilterBar
interface FilterBarProps {
  filters: Filters; // Receive current filters
  onFilterChange: (newFilters: Filters) => void; // Function to call on change
  // *** NEW: Receive dynamic options from the parent component ***
  availableCities: string[]; // e.g., ['all', 'Karachi', 'Lahore'] derived from actual billboards
  availableLocations: string[]; // e.g., ['all', 'Clifton', 'Gulberg', 'Shahr-e-Faisal'] derived from actual billboards
  // Ideally, the parent filters this list based on the selected city before passing it down.
}

// --- REMOVED STATIC OPTIONS ---
// const CITIES_OPTIONS = [ ... ];
// const LOCATION_OPTIONS = [ ... ];

const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onFilterChange,
  availableCities, // Use the received prop
  availableLocations, // Use the received prop
}) => {
  // Helper function to update a single filter value and call the parent callback
  const handleFilterValueChange = (
    filterName: keyof Filters,
    value: string
  ) => {
    const updatedFilters = {
      ...filters,
      [filterName]: value,
    };

    // If city changes, reset location to 'all'.
    // The parent component will likely recalculate and pass down
    // the appropriate 'availableLocations' based on the new city selection.
    if (filterName === "city") {
      updatedFilters.location = "all";
    }

    // Call the callback passed from the parent (e.g., BillboardListPage)
    onFilterChange(updatedFilters);
  };

  // Handle search input change
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    handleFilterValueChange("search", event.target.value);
  };

  // Clear specific filters or all filters
  const clearFilters = () => {
    const defaultFilters: Filters = {
      city: "all",
      location: "all",
      size: "", // Keep if size filter exists
      search: "",
    };
    onFilterChange(defaultFilters);
    // When clearing filters, the parent should also update and pass down
    // the full list of available cities and locations again.
  };

  // Reusable Filter Select Component (no changes needed inside this sub-component)
  const FilterSelect = ({
    label,
    value,
    options, // This will now receive the dynamic lists passed as props
    onChange,
    icon: Icon,
    filterKey,
    disabled = false,
  }: {
    label: string;
    value: string;
    options: string[]; // Expecting an array of strings
    onChange: (filterName: keyof Filters, value: string) => void;
    icon: React.ComponentType<any>;
    filterKey: keyof Filters;
    disabled?: boolean;
  }) => (
    <div className="relative flex-1 min-w-[150px]">
      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
        <Icon
          className={`h-4 w-4 ${disabled ? "text-gray-300" : "text-gray-400"}`}
        />
      </div>
      <select
        value={value}
        onChange={(e) => onChange(filterKey, e.target.value)}
        disabled={disabled || options.length <= 1} // Also disable if only 'all' is available
        className={`block w-full pl-9 pr-8 py-2 text-sm ${
          disabled || options.length <= 1
            ? "text-gray-400 bg-gray-100 cursor-not-allowed"
            : "text-gray-700 bg-gray-50 hover:border-gray-300 cursor-pointer"
        } border border-gray-200 rounded-lg
                 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 focus:outline-none focus:bg-white transition-colors
                 appearance-none`}
        aria-label={`Filter by ${label}`}
      >
        {/* Handle the 'all' option text slightly differently */}
        <option value="all">
          {options.length <= 1 ? `- No ${label}s Found -` : `All ${label}s`}
        </option>
        {/* Map over the dynamic options, excluding 'all' which is handled above */}
        {options
          .filter((opt) => opt && opt.toLowerCase() !== "all") // Ensure opt is valid and filter out 'all'
          .sort() // Optional: Sort options alphabetically
          .map((option) => (
            <option key={option} value={option}>
              {/* Capitalize first letter for display */}
              {option.charAt(0).toUpperCase() + option.slice(1)}
            </option>
          ))}
      </select>
      <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
        <svg
          className={`w-4 h-4 ${
            disabled || options.length <= 1 ? "text-gray-300" : "text-gray-400"
          }`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M19 9l-7 7-7-7"
          ></path>
        </svg>
      </div>
    </div>
  );

  // --- PriceInput Component Removed ---

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200/80 p-4 sm:p-6">
      {/* Header section remains the same */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
        <div className="flex items-center gap-2">
          <FaFilter className="text-blue-600 w-5 h-5" />
          <h2 className="text-base sm:text-lg font-semibold text-gray-700">
            Filters
          </h2>
        </div>
        <button
          onClick={clearFilters}
          className="text-xs text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 transition-colors"
          aria-label="Clear all filters"
        >
          <FaTimes /> Clear All
        </button>
      </div>

      <div className="space-y-4">
        {/* Search Bar remains the same */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
            <FaSearch className="h-4 w-4 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search by title, location, etc..."
            value={filters.search}
            onChange={handleSearchChange}
            className="block w-full pl-10 pr-3 py-2 text-sm text-gray-700 bg-gray-50 border border-gray-200 rounded-lg
                           focus:border-blue-500 focus:ring-1 focus:ring-blue-500 focus:outline-none focus:bg-white transition-colors"
            aria-label="Search billboards"
          />
        </div>

        {/* Row for City and Location filters */}
        <div className="flex flex-wrap items-center gap-3 sm:gap-4">
          {/* City Filter - Uses dynamic availableCities prop */}
          <FilterSelect
            label="City"
            value={filters.city}
            options={availableCities} // Use the prop passed from parent
            onChange={handleFilterValueChange}
            icon={FaCity}
            filterKey="city"
          />

          {/* Location Filter - Uses dynamic availableLocations prop */}
          {/* IMPORTANT: The parent component should ideally filter 'availableLocations'
                         based on the 'filters.city' state before passing it here.
                         For example, if 'Karachi' is selected, only locations within
                         Karachi (plus 'all') should be in the 'availableLocations' prop.
                         If city is 'all', then all unique locations should be passed.
           */}
          <FilterSelect
            label="Location"
            value={filters.location}
            options={availableLocations} // Use the prop passed from parent
            onChange={handleFilterValueChange}
            icon={FaMapMarkerAlt}
            filterKey="location"
            // Conditionally disable if no city is selected OR if no locations are available for the selected city.
            // The parent should handle passing an appropriate list (e.g., ['all'] if no specific locations exist).
            // The disable logic inside FilterSelect already handles the case where options.length <= 1.
            disabled={filters.city === "all"} // Keep location disabled until a city is selected for better UX? Or allow filtering location across all cities? Let's allow it for now. Remove this line if you want it disabled when city is 'all'.
          />

          {/* --- Price Inputs Removed --- */}

          {/* Add FilterSelect for Size if needed */}
          {/* <FilterSelect label="Size" value={filters.size} options={['all', '20x10', '40x10', '60x20']} onChange={handleFilterValueChange} icon={FaRuler} filterKey="size" /> */}
        </div>
      </div>
    </div>
  );
};

export default FilterBar;
