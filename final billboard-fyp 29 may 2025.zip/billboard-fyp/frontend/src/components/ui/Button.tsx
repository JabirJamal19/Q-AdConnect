import React from 'react';

type ButtonVariant = 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info';
type ButtonSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  pill?: boolean;
  outline?: boolean;
  className?: string;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'left',
  fullWidth = false,
  pill = false,
  outline = false,
  className = '',
  children,
  ...props
}) => {
  const getVariantClasses = () => {
    if (outline) {
      switch (variant) {
        case 'primary':
          return 'text-blue-700 border border-blue-700 hover:bg-blue-700 hover:text-white';
        case 'secondary':
          return 'text-gray-900 border border-gray-800 hover:bg-gray-900 hover:text-white';
        case 'success':
          return 'text-green-700 border border-green-700 hover:bg-green-700 hover:text-white';
        case 'danger':
          return 'text-red-700 border border-red-700 hover:bg-red-700 hover:text-white';
        case 'warning':
          return 'text-yellow-400 border border-yellow-400 hover:bg-yellow-400 hover:text-white';
        case 'info':
          return 'text-blue-400 border border-blue-400 hover:bg-blue-400 hover:text-white';
        default:
          return 'text-blue-700 border border-blue-700 hover:bg-blue-700 hover:text-white';
      }
    } else {
      switch (variant) {
        case 'primary':
          return 'text-white bg-blue-700 hover:bg-blue-800';
        case 'secondary':
          return 'text-white bg-gray-800 hover:bg-gray-900';
        case 'success':
          return 'text-white bg-green-700 hover:bg-green-800';
        case 'danger':
          return 'text-white bg-red-700 hover:bg-red-800';
        case 'warning':
          return 'text-white bg-yellow-400 hover:bg-yellow-500';
        case 'info':
          return 'text-white bg-blue-400 hover:bg-blue-500';
        default:
          return 'text-white bg-blue-700 hover:bg-blue-800';
      }
    }
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'xs':
        return 'px-2 py-1 text-xs';
      case 'sm':
        return 'px-3 py-1.5 text-sm';
      case 'md':
        return 'px-4 py-2 text-sm';
      case 'lg':
        return 'px-5 py-2.5 text-base';
      case 'xl':
        return 'px-6 py-3 text-base';
      default:
        return 'px-4 py-2 text-sm';
    }
  };

  const baseClasses = 'font-medium focus:outline-none focus:ring-4 focus:ring-opacity-50';
  const widthClass = fullWidth ? 'w-full' : '';
  const roundedClass = pill ? 'rounded-full' : 'rounded-lg';
  const focusRingClass = `focus:ring-${variant === 'secondary' ? 'gray' : variant}-300`;
  
  const buttonClasses = `
    ${baseClasses} 
    ${getVariantClasses()} 
    ${getSizeClasses()} 
    ${widthClass} 
    ${roundedClass} 
    ${focusRingClass}
    ${className}
  `;

  return (
    <button className={buttonClasses} {...props}>
      <span className="flex items-center justify-center">
        {icon && iconPosition === 'left' && <span className="mr-2">{icon}</span>}
        {children}
        {icon && iconPosition === 'right' && <span className="ml-2">{icon}</span>}
      </span>
    </button>
  );
};
