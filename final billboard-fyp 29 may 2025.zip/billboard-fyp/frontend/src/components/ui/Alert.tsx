import React from 'react';
import { 
  HiInformationCircle, 
  HiExclamationCircle, 
  HiCheckCircle, 
  HiXMark 
} from 'react-icons/hi2';

type AlertType = 'info' | 'warning' | 'success' | 'error';

interface AlertProps {
  type?: AlertType;
  children: React.ReactNode;
  onDismiss?: () => void;
  className?: string;
}

export const Alert: React.FC<AlertProps> = ({ 
  type = 'info', 
  children, 
  onDismiss,
  className = ''
}) => {
  const getAlertStyles = () => {
    switch (type) {
      case 'info':
        return {
          bg: 'bg-blue-50',
          text: 'text-blue-800',
          icon: <HiInformationCircle className="h-5 w-5 text-blue-500" />
        };
      case 'warning':
        return {
          bg: 'bg-yellow-50',
          text: 'text-yellow-800',
          icon: <HiExclamationCircle className="h-5 w-5 text-yellow-500" />
        };
      case 'success':
        return {
          bg: 'bg-green-50',
          text: 'text-green-800',
          icon: <HiCheckCircle className="h-5 w-5 text-green-500" />
        };
      case 'error':
        return {
          bg: 'bg-red-50',
          text: 'text-red-800',
          icon: <HiExclamationCircle className="h-5 w-5 text-red-500" />
        };
      default:
        return {
          bg: 'bg-blue-50',
          text: 'text-blue-800',
          icon: <HiInformationCircle className="h-5 w-5 text-blue-500" />
        };
    }
  };

  const { bg, text, icon } = getAlertStyles();

  return (
    <div className={`flex p-4 ${bg} ${text} rounded-lg ${className}`} role="alert">
      <div className="flex items-center">
        <span className="mr-2">{icon}</span>
        <div>{children}</div>
      </div>
      {onDismiss && (
        <button
          type="button"
          className="ml-auto -mx-1.5 -my-1.5 rounded-lg p-1.5 inline-flex items-center justify-center h-8 w-8 hover:bg-gray-100"
          onClick={onDismiss}
          aria-label="Close"
        >
          <HiXMark className="h-5 w-5" />
        </button>
      )}
    </div>
  );
};
