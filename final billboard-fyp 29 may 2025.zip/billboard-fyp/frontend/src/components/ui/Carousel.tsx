import React, { useState, useEffect, useCallback, useRef } from "react";
import { HiChevronLeft, HiChevronRight } from "react-icons/hi2";

interface CarouselProps {
  children: React.ReactNode[];
  indicators?: boolean;
  leftControl?: React.ReactNode;
  rightControl?: React.ReactNode;
  slide?: boolean;
  slideInterval?: number;
  className?: string;
  height?: string;
  onSlideChange?: (index: number) => void;
  indicatorType?: "dot" | "line" | "number";
  indicatorPosition?: "inside" | "outside";
  captionPosition?: "bottom" | "center" | "top";
  effect?: "fade" | "slide";
}

export const Carousel: React.FC<CarouselProps> = ({
  children,
  indicators = true,
  leftControl,
  rightControl,
  slide = true,
  slideInterval = 5000,
  className = "",
  height = "h-56 md:h-96 lg:h-[30rem] xl:h-[40rem]",
  onSlideChange,
  indicatorType = "dot",
  indicatorPosition = "inside",
  captionPosition = "bottom",
  effect = "fade",
}) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const carouselRef = useRef<HTMLDivElement>(null);
  const items = React.Children.toArray(children);

  // Minimum swipe distance (in px)
  const minSwipeDistance = 50;

  const goToSlide = useCallback(
    (index: number) => {
      if (isTransitioning) return;

      let newIndex = index;
      if (newIndex < 0) {
        newIndex = items.length - 1;
      } else if (newIndex >= items.length) {
        newIndex = 0;
      }

      setIsTransitioning(true);
      setActiveIndex(newIndex);

      if (onSlideChange) {
        onSlideChange(newIndex);
      }

      // Reset transition state after animation completes
      setTimeout(() => {
        setIsTransitioning(false);
      }, 700); // Match the duration in the CSS transition
    },
    [items.length, onSlideChange, isTransitioning]
  );

  const goToPrevious = useCallback(() => {
    goToSlide(activeIndex - 1);
  }, [activeIndex, goToSlide]);

  const goToNext = useCallback(() => {
    goToSlide(activeIndex + 1);
  }, [activeIndex, goToSlide]);

  // Handle touch events for mobile swipe
  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;

    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe) {
      goToNext();
    } else if (isRightSwipe) {
      goToPrevious();
    }
  };

  // Auto-play functionality
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (slide && !isPaused && items.length > 1) {
      interval = setInterval(() => {
        goToNext();
      }, slideInterval);
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [slide, isPaused, goToNext, slideInterval, items.length]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement === carouselRef.current ||
        carouselRef.current?.contains(document.activeElement)
      ) {
        if (e.key === "ArrowLeft") {
          goToPrevious();
        } else if (e.key === "ArrowRight") {
          goToNext();
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [goToPrevious, goToNext]);

  // Get indicator styles based on type
  const getIndicatorStyles = (isActive: boolean) => {
    switch (indicatorType) {
      case "line":
        return `w-8 h-1 rounded-sm ${isActive ? "bg-white" : "bg-white/40"}`;
      case "number":
        return `w-8 h-8 flex items-center justify-center rounded-full ${isActive ? "bg-white text-black" : "bg-black/30 text-white"}`;
      case "dot":
      default:
        return `w-3 h-3 rounded-full ${isActive ? "bg-white" : "bg-white/40"}`;
    }
  };

  // Get transition effect styles
  const getTransitionStyles = (index: number) => {
    const isActive = index === activeIndex;

    if (effect === "slide") {
      return `absolute top-0 left-0 w-full h-full transition-transform duration-700 ease-in-out transform ${isActive ? "translate-x-0" : index < activeIndex ? "-translate-x-full" : "translate-x-full"}`;
    }

    // Default to fade effect
    return `absolute top-0 left-0 w-full h-full transition-opacity duration-700 ease-in-out ${isActive ? "opacity-100 z-10" : "opacity-0 z-0"}`;
  };

  return (
    <div
      ref={carouselRef}
      className={`relative w-full ${className}`}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      tabIndex={0}
      role="region"
      aria-roledescription="carousel"
      aria-label="Image carousel"
    >
      {/* Carousel container with responsive height */}
      <div className={`relative overflow-hidden rounded-lg ${height}`}>
        {/* Slides */}
        <div className="relative h-full w-full">
          {items.map((item, index) => (
            <div
              key={index}
              className={getTransitionStyles(index)}
              aria-hidden={index !== activeIndex}
              role="group"
              aria-roledescription="slide"
              aria-label={`Slide ${index + 1} of ${items.length}`}
            >
              {item}
            </div>
          ))}
        </div>

        {/* Gradient overlay for better control visibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/20 via-transparent to-black/20 pointer-events-none"></div>
      </div>

      {/* Left Control */}
      <button
        type="button"
        className="absolute top-1/2 -translate-y-1/2 left-2 z-30 flex items-center justify-center cursor-pointer group focus:outline-none sm:left-4 md:left-6 lg:left-8"
        onClick={goToPrevious}
        aria-label="Previous slide"
      >
        {leftControl || (
          <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-black/30 backdrop-blur-sm group-hover:bg-black/50 transition-all duration-300 group-focus:ring-4 group-focus:ring-white/30">
            <HiChevronLeft className="w-6 h-6 text-white" />
          </span>
        )}
      </button>

      {/* Right Control */}
      <button
        type="button"
        className="absolute top-1/2 -translate-y-1/2 right-2 z-30 flex items-center justify-center cursor-pointer group focus:outline-none sm:right-4 md:right-6 lg:right-8"
        onClick={goToNext}
        aria-label="Next slide"
      >
        {rightControl || (
          <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-black/30 backdrop-blur-sm group-hover:bg-black/50 transition-all duration-300 group-focus:ring-4 group-focus:ring-white/30">
            <HiChevronRight className="w-6 h-6 text-white" />
          </span>
        )}
      </button>

      {/* Indicators */}
      {indicators && items.length > 1 && (
        <div
          className={`absolute z-30 flex space-x-3 -translate-x-1/2 left-1/2 ${indicatorPosition === "outside" ? "-bottom-12" : "bottom-5"}`}
          role="tablist"
        >
          {items.map((_, index) => (
            <button
              key={index}
              type="button"
              className={getIndicatorStyles(index === activeIndex)}
              aria-current={index === activeIndex}
              aria-label={`Slide ${index + 1}`}
              onClick={() => goToSlide(index)}
              role="tab"
              aria-selected={index === activeIndex}
            >
              {indicatorType === "number" && index + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
