import {
  // HiIcons (using Hi2 since Hi is deprecated)
  HiChevronDown,
  HiChevronUp,
  HiChevronRight,
  HiChevronLeft,
  HiXMark,
  HiExclamationCircle,
  HiInformationCircle,
  HiCheckCircle,
  HiClipboard,
  HiClipboardDocumentCheck,
} from "react-icons/hi2";

import {
  // FaIcons
  FaTimes,
  FaCheck,
  FaClipboard,
  FaClipboardCheck,
} from "react-icons/fa";

import {
  // MdIcons
  MdClose,
  MdHome,
} from "react-icons/md";

// Export all icons with their original names
export {
  // Hi2 icons
  HiChevronDown,
  HiChevronUp,
  HiChevronRight,
  HiChevronLeft,
  HiXMark,
  HiExclamationCircle,
  HiInformationCircle,
  HiCheckCircle,
  HiClipboard,
  HiClipboardDocumentCheck,

  // Fa icons
  FaTimes,
  FaCheck,
  FaClipboard,
  FaClipboardCheck,

  // Md icons
  MdClose,
  MdHome,
};

// Also export with Flowbite's expected names for compatibility
export {
  // Map HiOutline* to Hi2 icons
  HiChevronDown as HiOutlineChevronDown,
  HiChevronUp as HiOutlineChevronUp,
  HiChevronRight as HiOutlineChevronRight,
  HiChevronLeft as HiOutlineChevronLeft,
  HiXMark as HiOutlineX,
  HiExclamationCircle as HiOutlineExclamationCircle,
  HiInformationCircle as HiOutlineInformationCircle,
  HiCheckCircle as HiOutlineCheckCircle,
  HiClipboard as HiOutlineClipboard,
  HiClipboardDocumentCheck as HiOutlineClipboardCheck,

  // Map Fa6 icons to Fa icons
  FaTimes as FaXmark,
};
