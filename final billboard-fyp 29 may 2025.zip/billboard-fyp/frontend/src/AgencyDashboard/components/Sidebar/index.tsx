import { useEffect, useRef, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { useAuthStore } from "../../../stores/authStore";
import { FaAcquisitionsIncorporated, FaAddressBook, FaBuilding, FaFileAlt, FaProjectDiagram } from "react-icons/fa";
import { SiFlipboard } from "react-icons/si";
import { MdSpaceDashboard } from "react-icons/md";
import { FaUsers, FaChartLine } from "react-icons/fa";

interface SidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (arg: boolean) => void;
}

const Sidebar = ({ sidebarOpen, setSidebarOpen }: SidebarProps) => {
  const user = useAuthStore((state) => state.user);
  const location = useLocation();
  const { pathname } = location;

  const trigger = useRef<any>(null);
  const sidebar = useRef<any>(null);

  const storedSidebarExpanded = localStorage.getItem("sidebar-expanded");
  const [sidebarExpanded, setSidebarExpanded] = useState(
    storedSidebarExpanded === null ? false : storedSidebarExpanded === "true"
  );

  // close on click outside
  useEffect(() => {
    const clickHandler = ({ target }: MouseEvent) => {
      if (!sidebar.current || !trigger.current) return;
      if (
        !sidebarOpen ||
        sidebar.current.contains(target) ||
        trigger.current.contains(target)
      )
        return;
      setSidebarOpen(false);
    };
    document.addEventListener("click", clickHandler);
    return () => document.removeEventListener("click", clickHandler);
  });

  // close if the esc key is pressed
  useEffect(() => {
    const keyHandler = ({ keyCode }: KeyboardEvent) => {
      if (!sidebarOpen || keyCode !== 27) return;
      setSidebarOpen(false);
    };
    document.addEventListener("keydown", keyHandler);
    return () => document.removeEventListener("keydown", keyHandler);
  });

  useEffect(() => {
    localStorage.setItem("sidebar-expanded", sidebarExpanded.toString());
    if (sidebarExpanded) {
      document.querySelector("body")?.classList.add("sidebar-expanded");
    } else {
      document.querySelector("body")?.classList.remove("sidebar-expanded");
    }
  }, [sidebarExpanded]);

  return (
    <aside
      ref={sidebar}
      className={`absolute left-0 top-0 z-9999 flex h-screen w-72.5 flex-col overflow-y-hidden bg-black duration-300 ease-linear dark:bg-boxdark lg:static lg:translate-x-0 ${
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      }`}
    >
      {/* <!-- SIDEBAR HEADER --> */}
      <div className="flex items-center justify-between gap-2 px-6 py-5.5 lg:py-6.5">
        <NavLink
          to="/dashboard"
          className="flex items-center justify-between gap-3 px-4 py-3 rounded-lg transition-all duration-300 hover:bg-white/10"
        >
          <div className="flex-1">
            <h1 className="text-xl font-semibold text-white tracking-wide">
              Q_ADConnect
            </h1>
            <p className="text-xs text-blue-200">{user?.role} Dashboard</p>
          </div>
          {/* if role is admin then shows the admin logo other wises show the agency logo in the users logo */}
          {user?.role === "admin" ? (
            <img
              src="/qadconnect.png"
              alt="Logo"
              className="w-10 h-10 rounded-lg"
            />
          ) : (
            <img
              src="/qadconnect.png"
              alt="Logo"
              className="w-10 h-10 rounded-lg"
            />
          )}
        </NavLink>

        <button
          ref={trigger}
          onClick={() => setSidebarOpen(!sidebarOpen)}
          aria-controls="sidebar"
          aria-expanded={sidebarOpen}
          className="block lg:hidden"
        ></button>
      </div>
      {/* <!-- SIDEBAR HEADER --> */}

      <div className="no-scrollbar flex flex-col overflow-y-auto duration-300 ease-linear">
        {/* <!-- Sidebar Menu --> */}
        <nav className="mt-5 py-4 px-4 lg:mt-9 lg:px-6">
          {/* <!-- Menu Group --> */}
          <div>
            <h3 className="mb-4 ml-4 text-sm font-semibold text-white">MENU</h3>

            <ul className="mb-6 flex flex-col gap-1.5">
              {/* Dashboard Link */}
              <li>
                <NavLink
                  to="/dashboard"
                  className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                    pathname === "/dashboard" && "bg-graydark dark:bg-meta-4"
                  }`}
                >
                  <MdSpaceDashboard />
                  Dashboard
                </NavLink>
              </li>

              {user?.role === "agency" && (
                <>
                  {/* Billboard Link */}
                  <li>
                    <NavLink
                      to="/dashboard/billboard"
                      className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                        pathname === "/dashboard/billboard" &&
                        "bg-graydark dark:bg-meta-4"
                      }`}
                    >
                      <SiFlipboard />
                      My Billboards
                    </NavLink>
                  </li>
                  
                  {/* Workflow Management Link */}
                  <li>
                    <NavLink
                      to="/dashboard/workflow"
                      className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                        pathname === "/dashboard/workflow" &&
                        "bg-graydark dark:bg-meta-4"
                      }`}
                    >
                      <FaProjectDiagram />
                      Booking Workflow
                    </NavLink>
                  </li>
                  
                  {/* Booking Records Link */}
                  <li>
                    <NavLink
                      to="/dashboard/booking-records"
                      className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                        pathname === "/dashboard/agency-bookings" &&
                        "bg-graydark dark:bg-meta-4"
                      }`}
                    >
                      
                      <FaAddressBook />              
                       Booking Records
                    </NavLink>
                  </li>


                  {/* Users Link */}
                  <li>
                    <NavLink
                      to="/dashboard/users"
                      className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                        pathname === "/dashboard/team" &&
                        "bg-graydark dark:bg-meta-4"
                      }`}
                    >
                      <FaUsers />
                      Users Management
                    </NavLink>
                  </li>
                  {/* Revenue Link */}
                  <li>
                    <NavLink
                      to="/dashboard/revenue"
                      className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                        pathname === "/dashboard/financials" &&
                        "bg-graydark dark:bg-meta-4"
                      }`}
                    >
                      <FaChartLine /> Revenue Management
                    </NavLink>
                  </li>
                </>
              )}

              {/* Hide Agencies List and Users List for agency role */}
              {user?.role === "admin" && (
                <>
                  {/* Agencies List */}
                  <li>
                    <NavLink
                      to="/dashboard/agencies"
                      className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                        pathname === "/dashboard/agencies" &&
                        "bg-graydark dark:bg-meta-4"
                      }`}
                    >
                      <FaBuilding />
                      Agency Management
                    </NavLink>
                  </li>
                  {/* Report Link */}
                  <li>
                    <NavLink
                      to="/dashboard/user-reports"
                      className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                        pathname === "/dashboadr/report" &&
                        "bg-graydark dark:bg-meta-4"
                      }`}
                    >
                      <FaFileAlt />
                      Report Management
                    </NavLink>
                  </li>
                  {/* Admin Revenue Link */}
                  <li>
                    <NavLink
                      to="/dashboard/total-revenue"
                      className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium text-bodydark1 duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                        pathname === "/dashboard/total-revenue" &&
                        "bg-graydark dark:bg-meta-4"
                      }`}
                    >
                      <FaChartLine />
                      Total Revenue
                    </NavLink>
                  </li>
                </>
              )}
            </ul>
          </div>
        </nav>
      </div>
    </aside>
  );
};

export default Sidebar;
