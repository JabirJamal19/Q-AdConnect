// components/AgencyDocuments.jsx
import { useSearchParams } from 'react-router-dom';

const AgencyDocuments = () => {
  const [searchParams] = useSearchParams();
  const docsParam = searchParams.get('docs') || '';
  const documents = docsParam.split(',').filter(Boolean);

  return (
    <div className="p-4 space-y-4">
      {documents.map((doc, index) => (
        <iframe
          key={index}
          src={`${import.meta.env.VITE_BASE_URL}/files/${doc}`}
          className="w-full h-screen"
          title={`Document ${index + 1}`}
        />
      ))}
      {documents.length === 0 && (
        <p className="text-center text-gray-500">No documents available</p>
      )}
    </div>
  );
};

export default AgencyDocuments;
