// Header Component
import { Link } from "react-router-dom";
import DropdownAgency from "./DropdownAgency";
import DarkModeSwitcher from "./DarkModeSwitcher";
import { useAuthStore } from "../../../stores/authStore";
import { handleImageError } from "../../../utils/imageUtils";
import LogoIcon from "/qadconnect.png";

const Header = ({
  sidebarOpen,
  setSidebarOpen,
}: {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}) => {
  // Get user data from auth store
  const { user } = useAuthStore();

  // Get the API base URL
  const getBaseUrl = () => {
    return import.meta.env.VITE_API_URL || "http://localhost:4000";
  };

  // Prepare the image URL
  const imageUrl =
    user?.role === "admin"
      ? "/qadconnect.png"
      : user?.agencyImage
        ? `${getBaseUrl()}/files/${user.agencyImage}`
        : LogoIcon;

  return (
    <header className="sticky top-0 z-999 flex w-full bg-white drop-shadow-1 dark:bg-boxdark dark:drop-shadow-none">
      <div className="flex flex-grow items-center justify-between px-4 py-4 shadow-2 md:px-6 2xl:px-11">
        <div className="flex items-center gap-2 sm:gap-4 lg:hidden">
          {/* Hamburger Toggle Button */}
          <button
            aria-controls="sidebar"
            onClick={(e) => {
              e.stopPropagation();
              setSidebarOpen(!sidebarOpen);
            }}
            className="z-99999 block rounded-sm border border-stroke bg-white p-1.5 shadow-sm dark:border-strokedark dark:bg-boxdark lg:hidden"
          >
            <span className="relative block h-5.5 w-5.5 cursor-pointer">
              <span className="absolute right-0 h-full w-full">
                {[...Array(3)].map((_, idx) => (
                  <span
                    key={idx}
                    className={`block my-1 h-0.5 w-0 rounded-sm bg-black duration-200 dark:bg-white ${
                      !sidebarOpen && `!w-full delay-${idx * 100}`
                    }`}
                  ></span>
                ))}
              </span>
            </span>
          </button>
          {/* if role is admin then shows the admin logo otherwise show the agency logo */}
          <Link className="block flex-shrink-0 lg:hidden" to="/">
            <img
              src={imageUrl}
              alt="Logo"
              className="w-10 h-10 object-cover rounded-full"
              onError={(e) => handleImageError(e, LogoIcon)}
            />
          </Link>
        </div>

        <div className="hidden sm:block">
          {/* Optional Search Component Placeholder */}
        </div>

        <div className="flex items-center gap-3 2xsm:gap-7">
          <ul className="flex items-center gap-2 2xsm:gap-4">
            <DarkModeSwitcher />
          </ul>
          <DropdownAgency />
        </div>
      </div>
    </header>
  );
};

export default Header;
