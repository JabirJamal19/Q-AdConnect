import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ClickOutside from "./ClickOutside";
import { useAuthStore } from "../../../stores/authStore";
import { useNavigate } from "react-router-dom";
import axios from "../../../axiosInstance";
import UserPlaceholder from "/qadconnect.png";
import { FaSignOutAlt } from "react-icons/fa";
import { MdAccountCircle } from "react-icons/md";
// import { FiSettings } from "react-icons/fi";
import { handleImageError } from "../../../utils/imageUtils";

const DropdownAgency = () => {
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { logout, login, user: storedUser } = useAuthStore();

  // Add fallback values
  const DEFAULT_USER_NAME = "Guest User";
  const DEFAULT_ROLE = "User";

  // Admin User Info (for role 'admin')
  const ADMIN_NAME = "Q_AdConnect";

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          setLoading(false);
          setError("No token found.");
          return;
        }

        const response = await axios.get("/api/user/me");

        if (response.data?.user) {
          // Only call login if we don't already have a user in the store
          if (!storedUser) {
            login(token, response.data.user);
          }
        } else {
          setError("No user data found.");
        }
      } catch (error) {
        console.error("Failed to fetch user data:", error);
        setError("Failed to fetch user data.");
      } finally {
        setLoading(false);
      }
    };

    if (!storedUser) {
      fetchUser();
    } else {
      setLoading(false);
    }
  }, []);

  // Get the API base URL
  const getBaseUrl = () => {
    return import.meta.env.VITE_API_URL || "http://localhost:4000";
  };

  // Conditional user name and image for admin
  const userName =
    storedUser?.role === "admin"
      ? ADMIN_NAME
      : storedUser?.name || DEFAULT_USER_NAME;
  const userImage =
    storedUser?.role === "admin"
      ? UserPlaceholder
      : storedUser?.agencyImage
        ? `${getBaseUrl()}/files/${storedUser.agencyImage}`
        : UserPlaceholder;

  console.log("DropdownAgency - User Image URL:", userImage);

  const handleLogout = () => {
    logout();
    localStorage.clear();
    navigate("/auth");
    setDropdownOpen(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center">
        <span>Loading...</span>
      </div>
    );
  }

  return (
    <ClickOutside onClick={() => setDropdownOpen(false)} className="relative">
      <button
        onClick={() => setDropdownOpen((prev) => !prev)}
        className="flex items-center gap-4 focus:outline-none"
        aria-haspopup="true"
        aria-expanded={dropdownOpen}
      >
        <span className="hidden text-right lg:block">
          <span className="block text-sm font-medium text-black dark:text-white">
            {userName}
          </span>
          <span className="block text-xs">
            {storedUser?.role || DEFAULT_ROLE}
          </span>
        </span>
        <span className="h-12 w-12 rounded-full">
          <img
            src={userImage}
            alt={`${userName}'s profile`}
            className="rounded-full object-cover w-full h-full"
            onError={(e) => handleImageError(e, UserPlaceholder)}
          />
        </span>
      </button>

      {dropdownOpen && (
        <div
          className="absolute right-0 mt-4 flex w-62.5 flex-col rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark z-999999 dark:bg-boxdark"
          role="menu"
        >
          <ul className="flex flex-col gap-5 border-b border-stroke px-6 py-7.5 dark:border-strokedark">
            {/* is user role is agency then shows the profile list item */}
            {storedUser?.role === "agency" && (
              <li>
                <Link
                  to="/dashboard/agency-profile"
                  className="flex items-center gap-3.5 text-sm font-medium duration-300 ease-in-out hover:text-primary lg:text-base"
                >
                  <MdAccountCircle />
                  My Profile
                </Link>
              </li>
            )}
          </ul>
          <button
            className="flex items-center gap-3.5 px-6 py-4 text-sm font-medium duration-300 ease-in-out hover:text-primary lg:text-base"
            onClick={handleLogout}
            role="menuitem"
          >
            <FaSignOutAlt />
            Log Out
          </button>
        </div>
      )}
    </ClickOutside>
  );
};

export default DropdownAgency;
