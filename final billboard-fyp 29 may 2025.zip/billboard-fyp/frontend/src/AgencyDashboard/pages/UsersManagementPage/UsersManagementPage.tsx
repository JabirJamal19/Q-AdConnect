import Breadcrumb from "../../components/Breadcrumbs/Breadcrumb";
import React, { useState, useEffect, useCallback } from "react";
import axios from "../../../axiosInstance";
import { toast } from "react-hot-toast";
import {
  FaUserPlus,
  FaSearch,
  FaEdit,
  FaTrash,
  FaCheck,
  FaBan,
  FaSpinner,
  FaExclamationTriangle,
} from "react-icons/fa";
import { useAuthStore } from "../../../stores/authStore";

// Define User interface
interface User {
  _id: string;
  name: string;
  email: string;
  role: "admin" | "agency" | "customer";
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
  agencyName?: string;
  address?: string;
  city?: string;
  ntnNumber?: string;
  approvalStatus?: "pending" | "approved" | "rejected";
}

const CustomModal: React.FC<{
  isOpen: boolean;
  title: string;
  message?: string;
  children?: React.ReactNode;
  onCancel: () => void;
  onConfirm?: () => void;
  confirmText?: string;
  confirmColor?: string;
  showConfirmButton?: boolean;
  isProcessing?: boolean;
}> = ({
  isOpen,
  title,
  message,
  children,
  onCancel,
  onConfirm,
  confirmText = "Confirm",
  confirmColor = "red",
  showConfirmButton = true,
  isProcessing = false,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
        <h3 className="text-xl font-bold mb-4 text-gray-800">{title}</h3>
        {message && <p className="mb-6 text-gray-600">{message}</p>}
        {children}
        <div className="flex justify-end mt-6">
          <button
            onClick={onCancel}
            className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium px-4 py-2 rounded-md mr-2 transition-colors"
          >
            Cancel
          </button>
          {showConfirmButton && onConfirm && (
            <button
              onClick={onConfirm}
              disabled={isProcessing}
              className={`bg-${confirmColor}-500 hover:bg-${confirmColor}-600 text-white bg-[var(--color-brand-primary)] font-medium px-4 py-2 rounded-md transition-colors ${isProcessing ? "opacity-70 cursor-not-allowed" : ""}`}
            >
              {isProcessing ? (
                <>
                  <FaSpinner className="inline animate-spin mr-2" />
                  Processing...
                </>
              ) : (
                confirmText
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

const UsersManagementPage: React.FC = () => {
  const { token } = useAuthStore();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [userIdToDelete, setUserIdToDelete] = useState<User | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [userToEdit, setUserToEdit] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Form state for editing and adding users
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "customer",
    status: "active",
    agencyName: "",
    address: "",
    city: "",
    ntnNumber: "",
  });

  // Fetch Users
  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      // Build query parameters
      const params = new URLSearchParams();

      // For agency users, always restrict to only see customer users
      const { user } = useAuthStore.getState();
      const isAgency = user?.role === "agency";

      // If user is agency, force role to be customer only
      if (isAgency) {
        params.append("role", "customer");
      } else if (roleFilter !== "all") {
        // For admin users, allow filtering by role
        params.append("role", roleFilter);
      }

      // Add search term if provided
      if (searchTerm && searchTerm.trim() !== "") {
        params.append("search", searchTerm);
      }

      // Add status filter if not 'all'
      if (statusFilter !== "all") {
        params.append("status", statusFilter);
      }

      // Add pagination parameters
      params.append("page", currentPage.toString());
      params.append("limit", "10"); // Show 10 users per page

      // Construct final URL with query parameters
      const url = `/api/user/users?${params.toString()}`;

      console.log("Fetching users from:", url);

      const response = await axios.get(url, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.data.status === 1) {
        // Map the response to match our User interface
        const mappedUsers = response.data.users.map((user: any) => ({
          _id: user._id,
          name: user.name || "",
          email: user.email || "",
          role: user.role || "customer",
          status:
            user.status?.toLowerCase() === "active" ? "active" : "inactive",
          createdAt: user.createdAt || "",
          updatedAt: user.updatedAt || "",
          agencyName: user.agencyName || "",
          address: user.address || "",
          city: user.city || "",
          ntnNumber: user.ntnNumber || "",
          approvalStatus: user.approvalStatus || "pending",
        }));

        setUsers(mappedUsers);
        setTotalPages(response.data.totalPages || 1);
      } else {
        throw new Error(response.data.message || "Failed to fetch users");
      }
    } catch (err: any) {
      console.error("Error fetching users:", err);
      setError(
        err.response?.data?.message || err.message || "Failed to fetch users"
      );
      toast.error("Failed to fetch users");
    } finally {
      setLoading(false);
    }
  }, [token, roleFilter, statusFilter, searchTerm, currentPage]);

  // Load users on mount and when filters change
  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  // Delete Handlers
  const handleDelete = (user: User) => {
    setUserIdToDelete(user);
    setIsModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!userIdToDelete) return;

    try {
      setIsProcessing(true);

      const response = await axios.delete(
        `/api/user/delete/${userIdToDelete._id}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.data.status === 1) {
        setUsers((prevUsers) =>
          prevUsers.filter((user) => user._id !== userIdToDelete._id)
        );
        toast.success("User deleted successfully!");
      } else {
        throw new Error(response.data.message || "Failed to delete user");
      }
    } catch (err: any) {
      console.error("Error deleting user:", err);
      toast.error(
        err.response?.data?.message || err.message || "Failed to delete user"
      );
    } finally {
      setIsProcessing(false);
      setIsModalOpen(false);
      setUserIdToDelete(null);
    }
  };

  const cancelDelete = () => {
    setIsModalOpen(false);
    setUserIdToDelete(null);
  };

  // Handle form input changes
  const handleFormChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Add new user
  const handleAddUser = () => {
    // Reset form data
    setFormData({
      name: "",
      email: "",
      password: "",
      role: "customer",
      status: "active",
      agencyName: "",
      address: "",
      city: "",
      ntnNumber: "",
    });

    setIsAddModalOpen(true);
  };

  const handleAddUserSubmit = async () => {
    try {
      setIsProcessing(true);

      // Validate form data
      if (!formData.name || !formData.email || !formData.password) {
        toast.error("Please fill in all required fields");
        return;
      }

      const response = await axios.post("/api/auth/signup", formData, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.data.status === 1) {
        toast.success("User added successfully!");
        fetchUsers(); // Refresh the user list
        setIsAddModalOpen(false);
      } else {
        throw new Error(response.data.message || "Failed to add user");
      }
    } catch (err: any) {
      console.error("Error adding user:", err);
      toast.error(
        err.response?.data?.message || err.message || "Failed to add user"
      );
    } finally {
      setIsProcessing(false);
    }
  };

  // Edit Handlers
  const handleEdit = (user: User) => {
    setUserToEdit(user);

    // Populate form data with user details
    setFormData({
      name: user.name || "",
      email: user.email || "",
      password: "", // Don't populate password for security
      role: user.role || "customer",
      status: user.status || "active",
      agencyName: user.agencyName || "",
      address: user.address || "",
      city: user.city || "",
      ntnNumber: user.ntnNumber || "",
    });

    setIsEditModalOpen(true);
  };

  const handleEditSubmit = async () => {
    if (!userToEdit) return;

    try {
      setIsProcessing(true);

      // Validate form data
      if (!formData.name || !formData.email) {
        toast.error("Please fill in all required fields");
        return;
      }

      // Create data object without password if it's empty
      const dataToSend: Record<string, any> = { ...formData };
      if (!dataToSend.password) {
        delete dataToSend.password;
      }

      const response = await axios.put(
        `/api/user/update/${userToEdit._id}`,
        dataToSend,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data.status === 1) {
        // Update the user in the local state
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user._id === userToEdit._id
              ? {
                  ...user,
                  name: formData.name,
                  email: formData.email,
                  role: formData.role as User["role"],
                  status: formData.status as User["status"],
                  agencyName: formData.agencyName,
                  address: formData.address,
                  city: formData.city,
                  ntnNumber: formData.ntnNumber,
                }
              : user
          )
        );

        toast.success("User updated successfully!");
        setIsEditModalOpen(false);
        setUserToEdit(null);
      } else {
        throw new Error(response.data.message || "Failed to update user");
      }
    } catch (err: any) {
      console.error("Error updating user:", err);
      toast.error(
        err.response?.data?.message || err.message || "Failed to update user"
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const cancelEdit = () => {
    setIsEditModalOpen(false);
    setUserToEdit(null);
  };

  // Toggle user status
  const handleToggleStatus = async (user: User) => {
    try {
      setIsProcessing(true);

      const newStatus = user.status === "active" ? "inactive" : "active";

      const response = await axios.put(
        `/api/user/update/${user._id}`,
        { status: newStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data.status === 1) {
        // Update the user in the local state
        setUsers((prevUsers) =>
          prevUsers.map((u) =>
            u._id === user._id
              ? { ...u, status: newStatus as User["status"] }
              : u
          )
        );

        toast.success(
          `User ${newStatus === "active" ? "activated" : "deactivated"} successfully!`
        );
      } else {
        throw new Error(
          response.data.message ||
            `Failed to ${newStatus === "active" ? "activate" : "deactivate"} user`
        );
      }
    } catch (err: any) {
      console.error("Error toggling user status:", err);
      toast.error(
        err.response?.data?.message ||
          err.message ||
          "Failed to update user status"
      );
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle search
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  // Handle filter changes
  const handleStatusFilterChange = (
    e: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setStatusFilter(e.target.value);
  };

  // Handle pagination
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // Render loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <FaSpinner className="animate-spin text-indigo-600 text-3xl mr-2" />
        <p className="text-gray-600 dark:text-gray-300">Loading...</p>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <FaExclamationTriangle className="text-red-500 text-3xl mr-2" />
        <p className="text-red-500 dark:text-red-400">{error}</p>
      </div>
    );
  }

  return (
    <>
      <Breadcrumb pageName="Users Management" />

      {/* Header with actions */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div className="mb-4 md:mb-0">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
            {useAuthStore.getState().user?.role === "agency"
              ? "Manage Customer Users"
              : "Manage Users"}
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            {useAuthStore.getState().user?.role === "agency"
              ? "View, add, edit, and manage customer accounts"
              : "View, add, edit, and manage user accounts"}
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-3">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search users..."
              value={searchTerm}
              onChange={handleSearch}
              className="w-full md:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <FaSearch className="absolute left-3 top-3 text-gray-400" />
          </div>

          {/* Role filter - Only show for admin users */}
          {useAuthStore.getState().user?.role !== "agency" && (
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              <option value="all">All Roles</option>
              <option value="admin">Admin</option>
              <option value="agency">Agency</option>
              <option value="customer">Customer</option>
            </select>
          )}

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={handleStatusFilterChange}
            className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>

          {/* Add User Button */}
          <button
            onClick={handleAddUser}
            className="flex items-center justify-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            <FaUserPlus className="mr-2" />
            Add User
          </button>
        </div>
      </div>

      {/* Users Table */}
      <div className="rounded-sm border border-stroke bg-white px-5 pt-6 pb-2.5 shadow-default dark:border-strokedark dark:bg-boxdark sm:px-7.5 xl:pb-1">
        <div className="max-w-full overflow-x-auto">
          <table className="w-full table-auto">
            <thead>
              <tr className="bg-gray-2 dark:bg-meta-4 text-left">
                <th className="py-4 px-4 font-medium text-black dark:text-white">
                  Name
                </th>
                <th className="py-4 px-4 font-medium text-black dark:text-white">
                  Email
                </th>
                <th className="py-4 px-4 font-medium text-black dark:text-white">
                  Role
                </th>
                <th className="py-4 px-4 font-medium text-black dark:text-white">
                  Status
                </th>
                <th className="py-4 px-4 font-medium text-black dark:text-white text-center">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody>
              {users.length === 0 ? (
                <tr>
                  <td
                    colSpan={5}
                    className="text-center py-4 text-gray-500 dark:text-gray-400"
                  >
                    No users found.
                  </td>
                </tr>
              ) : (
                users.map((user) => (
                  <tr
                    key={user._id}
                    className="border-b border-stroke dark:border-strokedark hover:bg-gray-50 dark:hover:bg-meta-4"
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center">
                        <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 font-semibold mr-3">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <h5 className="font-medium text-black dark:text-white">
                            {user.name}
                          </h5>
                          {user.agencyName && (
                            <p className="text-sm text-gray-500">
                              {user.agencyName}
                            </p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-black dark:text-white">
                      {user.email}
                    </td>
                    <td className="py-4 px-4">
                      <span
                        className={`inline-block rounded-full py-1 px-3 text-xs font-medium ${
                          user.role === "admin"
                            ? "bg-indigo-100 text-indigo-800"
                            : user.role === "agency"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-green-100 text-green-800"
                        }`}
                      >
                        {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <span
                        className={`inline-block rounded-full py-1 px-3 text-xs font-medium ${
                          user.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }`}
                      >
                        {user.status.charAt(0).toUpperCase() +
                          user.status.slice(1)}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center justify-center space-x-3.5">
                        <button
                          onClick={() => handleEdit(user)}
                          className="hover:text-indigo-600 text-gray-600 dark:text-gray-400 dark:hover:text-white"
                          title="Edit User"
                        >
                          <FaEdit className="text-lg" />
                        </button>

                        <button
                          onClick={() => handleToggleStatus(user)}
                          className={`hover:${user.status === "active" ? "text-red-600" : "text-green-600"} text-gray-600 dark:text-gray-400 dark:hover:text-white`}
                          title={
                            user.status === "active"
                              ? "Deactivate User"
                              : "Activate User"
                          }
                        >
                          {user.status === "active" ? (
                            <FaBan className="text-lg" />
                          ) : (
                            <FaCheck className="text-lg" />
                          )}
                        </button>

                        <button
                          onClick={() => handleDelete(user)}
                          className="hover:text-red-600 text-gray-600 dark:text-gray-400 dark:hover:text-white"
                          title="Delete User"
                        >
                          <FaTrash className="text-lg" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center mt-6 mb-4">
            <div className="flex space-x-1">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className={`px-3 py-1 rounded-md ${currentPage === 1 ? "bg-gray-100 text-gray-400 cursor-not-allowed" : "bg-gray-200 text-gray-700 hover:bg-gray-300"}`}
              >
                Previous
              </button>

              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className={`px-3 py-1 rounded-md ${currentPage === page ? "bg-indigo-600 text-white" : "bg-gray-200 text-gray-700 hover:bg-gray-300"}`}
                  >
                    {page}
                  </button>
                )
              )}

              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className={`px-3 py-1 rounded-md ${currentPage === totalPages ? "bg-gray-100 text-gray-400 cursor-not-allowed" : "bg-gray-200 text-gray-700 hover:bg-gray-300"}`}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      <CustomModal
        isOpen={isModalOpen}
        title="Confirm Delete"
        message={`Are you sure you want to delete ${userIdToDelete?.name}?`}
        onCancel={cancelDelete}
        onConfirm={confirmDelete}
        confirmText="Delete"
        confirmColor="red"
        isProcessing={isProcessing}
      />

      {/* Add User Modal */}
      <CustomModal
        isOpen={isAddModalOpen}
        title="Add New User"
        onCancel={() => setIsAddModalOpen(false)}
        onConfirm={handleAddUserSubmit}
        confirmText="Add User"
        confirmColor="indigo"
        isProcessing={isProcessing}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Name
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleFormChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Enter name"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleFormChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Enter email"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleFormChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Enter password"
              required
            />
          </div>
        </div>
      </CustomModal>

      {/* Edit User Modal */}
      <CustomModal
        isOpen={isEditModalOpen}
        title="Edit User"
        onCancel={cancelEdit}
        onConfirm={handleEditSubmit}
        confirmText="Update"
        confirmColor="indigo"
        isProcessing={isProcessing}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Name
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleFormChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Enter name"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleFormChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Enter email"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password (leave blank to keep current)
            </label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleFormChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Enter new password"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              name="status"
              value={formData.status}
              onChange={handleFormChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </CustomModal>
    </>
  );
};

export default UsersManagementPage;
