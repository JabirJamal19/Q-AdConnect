import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../../../stores/authStore";
import { toast } from "react-toastify";
import ReportsPage from "../AdminReportPage/AdminReportPage";
import AgencyManagementPage from "../AgencyManagement/AgencyManagementPage";
import AgencyTotalNumbers from "./TotalMetaData/AgencyTotalNumbers";
import BillboardTotalNumbers from "./TotalMetaData/BillboardTotalNumbers";
import UsersTotalNumbers from "./TotalMetaData/UsersTotalNumbers";
import { fetchDashboardData } from "../../../services/dashboardService";
import BillboardPage from "../BillboardPage/BillboardPage";

import UsersManagementPage from "../UsersManagementPage/UsersManagementPage";
import RevenueManagementPage from "../RevenueManagement/RevenueManagementPage";
import AdminRevenuePage from "../AdminRevenue/AdminRevenuePage";
import DashboardStats from "./DashboardStats";

const ECommerce: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore((state) => state);
  const [dashboard, setDashboard] = useState<{
    users: number;
    agency: number;
    billboards: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/auth");
    }
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    const getDashboardData = async () => {
      try {
        setLoading(true);
        const data = await fetchDashboardData();
        setDashboard({
          users: data.users,
          agency: data.agency,
          billboards: data.billboards,
        });
      } catch (error: any) {
        toast.error(error.message || "Failed to fetch dashboard data");
        console.error("Dashboard data error:", error);
      } finally {
        setLoading(false);
      }
    };

    if (isAuthenticated) {
      getDashboardData();
    }
  }, [isAuthenticated]);

  if (!isAuthenticated) return null;

  const isAdmin = user?.role === "admin";
  const isAgency = user?.role === "agency";

  return (
    <>
      {/* <div className="grid grid-cols-1 gap-4 md:grid-cols-2 md:gap-6 xl:grid-cols-4 2xl:gap-7.5">
        {loading ? (
          <>
            <div className="rounded-sm border border-stroke bg-white py-6 px-7.5 shadow-default dark:border-strokedark dark:bg-boxdark animate-pulse">
              <div className="h-12 w-12 rounded-full bg-gray-200 dark:bg-gray-700 mb-4"></div>
              <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
            </div>
            <div className="rounded-sm border border-stroke bg-white py-6 px-7.5 shadow-default dark:border-strokedark dark:bg-boxdark animate-pulse">
              <div className="h-12 w-12 rounded-full bg-gray-200 dark:bg-gray-700 mb-4"></div>
              <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
            </div>
            <div className="rounded-sm border border-stroke bg-white py-6 px-7.5 shadow-default dark:border-strokedark dark:bg-boxdark animate-pulse">
              <div className="h-12 w-12 rounded-full bg-gray-200 dark:bg-gray-700 mb-4"></div>
              <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
            </div>
          </>
        ) : (
          <>
            {isAdmin && (
              <>
                <AgencyTotalNumbers dashboard={dashboard} />

                <BillboardTotalNumbers dashboard={dashboard} />

                <UsersTotalNumbers dashboard={dashboard} />
              </>
            )}
            {isAgency && (
              <>
                <UsersTotalNumbers dashboard={dashboard} />
              </>
            )}
          </>
        )}
      </div> */}
      <DashboardStats
        loading={loading}
        dashboard={dashboard}
        isAdmin={isAdmin}
        isAgency={isAgency}
      />

      <div className="mt-4 grid grid-cols-12 gap-6 md:mt-6 md:gap-8 2xl:mt-7.5 2xl:gap-10">
        <div className="col-span-12 xl:col-span-12 space-y-6">
          {/* Admin view */}
          {isAdmin && (
            <div>
              <AgencyManagementPage />
              <ReportsPage />
              <AdminRevenuePage />
            </div>
          )}

          {/* Agency view */}
          {isAgency && (
            <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-200 dark:bg-gray-800 dark:border-gray-700">
              <RevenueManagementPage />
              <BillboardPage />
             
              <UsersManagementPage />
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default ECommerce;
