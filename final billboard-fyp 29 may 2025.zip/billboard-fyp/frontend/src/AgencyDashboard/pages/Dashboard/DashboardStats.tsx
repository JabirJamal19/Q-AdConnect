import React from "react";
import { Users, Building, Activity, Layout } from "lucide-react";

// Reusable Card Component
const StatCard = ({ icon, title, value, trend, color }) => {
  const [count, setCount] = React.useState(0);

  React.useEffect(() => {
    if (value !== undefined) {
      const duration = 1000;
      const steps = 20;
      const step = Math.ceil(value / steps);
      let current = 0;

      const timer = setInterval(() => {
        current += step;
        if (current >= value) {
          setCount(value);
          clearInterval(timer);
        } else {
          setCount(current);
        }
      }, duration / steps);

      return () => clearInterval(timer);
    }
  }, [value]);

  return (
    <div className="rounded-lg border border-stroke bg-white p-5 shadow-md hover:shadow-lg transition-all duration-300 dark:border-strokedark dark:bg-boxdark w-full relative overflow-hidden h-full">
      <div
        className="absolute -right-4 -top-4 w-20 h-20 rounded-full bg-opacity-10 dark:bg-opacity-20 z-0"
        style={{ backgroundColor: color }}
      ></div>
      <div
        className="absolute right-12 bottom-3 w-8 h-8 rounded-full bg-opacity-10 dark:bg-opacity-20 z-0"
        style={{ backgroundColor: color }}
      ></div>

      <div className="flex items-center justify-between relative z-10">
        <div>
          <h4 className="text-2xl font-bold text-black dark:text-white mb-1">
            {count.toLocaleString()}
          </h4>
          <span className="text-sm font-medium text-gray-600 dark:text-gray-300">
            {title}
          </span>

          {trend && (
            <div className="flex items-center mt-2">
              <div
                className={`flex items-center ${trend > 0 ? "text-green-500" : "text-red-500"}`}
              >
                {trend > 0 ? (
                  <span className="text-xs font-medium">{`+${trend}%`}</span>
                ) : (
                  <span className="text-xs font-medium">{`${trend}%`}</span>
                )}
              </div>
              <span className="text-xs text-gray-500 ml-1">vs last month</span>
            </div>
          )}
        </div>

        <div
          className="flex h-14 w-14 items-center justify-center rounded-full text-white shadow-lg transform hover:scale-105 transition-transform duration-300"
          style={{
            background: `linear-gradient(to right, ${color}, ${color})`,
          }}
        >
          {icon}
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-700">
        <div className="flex items-center">
          <Activity size={14} className="text-gray-400 mr-2" />
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
            <div
              className="h-1.5 rounded-full animate-pulse"
              style={{
                width: `${Math.min((value || 0) / 10, 100)}%`,
                backgroundColor: color,
              }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Dashboard Components
const UsersTotalNumbers = ({ dashboard }) => (
  <StatCard
    icon={<Users size={24} />}
    title="Total Users"
    value={dashboard?.users}
    trend={5.8}
    color="#4F46E5" // Indigo
  />
);

const AgencyTotalNumbers = ({ dashboard }) => (
  <StatCard
    icon={<Building size={24} />}
    title="Total Agencies"
    value={dashboard?.agency}
    trend={-2.3}
    color="#10B981" // Emerald
  />
);

const BillboardTotalNumbers = ({ dashboard }) => (
  <StatCard
    icon={<Layout size={24} />}
    title="Total Billboards"
    value={dashboard?.billboards}
    trend={12.1}
    color="#F59E0B" // Amber
  />
);

// Loading Skeleton Component
const SkeletonCard = () => (
  <div className="rounded-lg border border-stroke bg-white py-6 px-5 shadow-default dark:border-strokedark dark:bg-boxdark animate-pulse h-full">
    <div className="h-12 w-12 rounded-full bg-gray-200 dark:bg-gray-700 mb-4"></div>
    <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
    <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4"></div>
    <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded w-full mt-4"></div>
  </div>
);

// Dashboard with auto-adjusting grid layout
const DashboardStats = ({ loading, dashboard, isAdmin, isAgency }) => {
  // Calculate number of cards to show based on user role
  const getNumCards = () => {
    if (isAdmin) return 3; // Admin sees 3 cards
    if (isAgency) return 1; // Agency sees 1 card
    return 0;
  };

  // Dynamically set grid columns based on number of cards
  const numCards = getNumCards();
  const getGridClass = () => {
    if (numCards === 1) return "grid-cols-1";
    if (numCards === 2) return "grid-cols-1 md:grid-cols-2";
    return "grid-cols-1 md:grid-cols-2 xl:grid-cols-3";
  };

  return (
    <div className={`grid gap-4 md:gap-6 xl:gap-8 ${getGridClass()}`}>
      {loading ? (
        // Loading skeletons - match number of expected cards
        Array(numCards)
          .fill(0)
          .map((_, index) => <SkeletonCard key={`skeleton-${index}`} />)
      ) : (
        <>
          {isAdmin && (
            <>
              <AgencyTotalNumbers dashboard={dashboard} />
              <BillboardTotalNumbers dashboard={dashboard} />
              <UsersTotalNumbers dashboard={dashboard} />
            </>
          )}
          {isAgency && <UsersTotalNumbers dashboard={dashboard} />}
        </>
      )}
    </div>
  );
};

export default DashboardStats;
