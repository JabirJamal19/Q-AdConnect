import React, { useState, useEffect, useCallback } from "react";
import { useAuthStore } from "../../../stores/authStore";
import axios from "../../../axiosInstance";
import toast from "react-hot-toast";
import {
  FaChartLine,
  FaMoneyBillWave,
  FaUsers,
  FaCalendarAlt,
  FaSearch,
  FaFilter,
  FaDownload,
  FaExclamationTriangle,
  FaSpinner,
  FaSortAmountDown,
  FaSortAmountUp,
  FaUserCircle,
  FaMapMarkerAlt,
} from "react-icons/fa";
import { Line, Bar, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import Breadcrumb from "../../components/Breadcrumbs/Breadcrumb";

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

// Define interfaces
interface CustomerRevenue {
  customerId: string;
  customerName: string;
  customerEmail: string;
  totalSpent: number;
  bookingsCount: number;
  bookings: BookingDetail[];
}

interface BookingDetail {
  bookingId: string;
  amount: number;
  date: string;
  billboardTitle: string;
  billboardLocation: string;
  startDate: string;
  endDate: string;
  duration: number;
  paymentMethod?: string;
  paymentStatus?: string;
  status?: string;
  paymentVerified?: boolean;
}

interface MonthlyRevenue {
  month: string;
  amount: number;
}

interface BillboardRevenue {
  billboardId: string;
  billboardTitle: string;
  billboardLocation: string;
  totalRevenue: number;
  bookingsCount: number;
}

interface RecentBooking {
  bookingId: string;
  customerName: string;
  billboardTitle: string;
  amount: number;
  date: string;
  duration: number; // Assuming duration was intended here based on modal usage
  paymentMethod?: string;
  paymentStatus?: string;
  status?: string;
}

interface PaymentMethodStats {
  method: string;
  count: number;
  amount: number;
}

interface RevenueData {
  totalRevenue: number;
  totalBookings: number;
  customerRevenue: CustomerRevenue[];
  monthlyRevenue: MonthlyRevenue[];
  topBillboards: BillboardRevenue[];
  recentBookings: RecentBooking[];
  paymentMethods?: PaymentMethodStats[];
}

const RevenueManagementPage: React.FC = () => {
  const { token } = useAuthStore();
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [revenueData, setRevenueData] = useState<RevenueData | null>(null);
  const [dateRange, setDateRange] = useState<{
    startDate: string;
    endDate: string;
  }>({
    startDate: new Date(new Date().getFullYear(), new Date().getMonth() - 6, 1)
      .toISOString()
      .split("T")[0],
    endDate: new Date().toISOString().split("T")[0],
  });
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [sortField, setSortField] = useState<string>("totalSpent");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [selectedCustomer, setSelectedCustomer] =
    useState<CustomerRevenue | null>(null);
  const [showCustomerDetails, setShowCustomerDetails] =
    useState<boolean>(false);
  const [paymentMethodFilter, setPaymentMethodFilter] = useState<string>("all");
  const [showPaymentMethodChart, setShowPaymentMethodChart] = useState<boolean>(true);

  // Format currency
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "PKR",
    }).format(amount);
  };

  // Format date
  const formatDate = (dateString: string): string => {
    // Basic check for invalid date strings before formatting
    if (!dateString || isNaN(new Date(dateString).getTime())) {
      return "Invalid Date";
    }
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // Format month
  const formatMonth = (monthStr: string): string => {
    // Basic check for invalid month strings
    if (!monthStr || !monthStr.includes("-")) {
      return "Invalid Month";
    }
    const [year, month] = monthStr.split("-");
    // Ensure year and month are valid numbers
    const yearNum = parseInt(year, 10);
    const monthNum = parseInt(month, 10);
    if (isNaN(yearNum) || isNaN(monthNum) || monthNum < 1 || monthNum > 12) {
      return "Invalid Month Format";
    }
    return new Date(yearNum, monthNum - 1, 1).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
    });
  };

  // Fetch revenue data
  const fetchRevenueData = useCallback(async () => {
    if (!token) {
      setError("Authentication token not found. Please log in again.");
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        startDate: dateRange.startDate,
        endDate: dateRange.endDate,
      });
      // Ensure the base URL and path are correct
      const response = await axios.get(
        `/api/booking/agency-revenue?${params.toString()}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      // More robust check for success
      if (response.data && response.data.status === 1 && response.data.data) {
        // Log the agency-specific data for debugging
        console.log("Agency-specific revenue data:", response.data.data);

        // Verify that this is agency-specific data
        if (response.data.data.agencyId) {
          console.log(
            `Data belongs to agency ID: ${response.data.data.agencyId}`
          );
        }

        // Ensure customerRevenue is an array
        if (!Array.isArray(response.data.data.customerRevenue)) {
          console.warn(
            "customerRevenue is not an array, setting to empty array"
          );
          response.data.data.customerRevenue = [];
        }

        // Ensure each customer has a bookings array
        if (response.data.data.customerRevenue) {
          response.data.data.customerRevenue =
            response.data.data.customerRevenue.map((customer: any) => {
              if (!customer.bookings || !Array.isArray(customer.bookings)) {
                console.warn(
                  `Customer ${customer.customerName} has no bookings array, creating empty one`
                );
                return { ...customer, bookings: [] };
              }
              return customer;
            });
        }

        setRevenueData(response.data.data);
        toast.success("Revenue data loaded successfully");
      } else {
        // Provide a more informative error based on response
        throw new Error(
          response.data?.message ||
            "Failed to fetch revenue data: Invalid response format"
        );
      }
    } catch (err: any) {
      console.error("Error fetching revenue data:", err);
      // Try to extract a meaningful error message
      const message =
        err.response?.data?.message ||
        err.message ||
        "An unknown error occurred while fetching revenue data.";
      setError(message);
    } finally {
      setLoading(false);
    }
  }, [token, dateRange]); // dateRange should be a dependency

  // Load data on mount and when date range or token changes
  useEffect(() => {
    fetchRevenueData();
  }, [fetchRevenueData]); // fetchRevenueData already includes token and dateRange as dependencies

  // Filter customers by search term
  const filteredCustomers =
    revenueData?.customerRevenue?.filter(
      (customer) =>
        customer.customerName
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        customer.customerEmail?.toLowerCase().includes(searchTerm.toLowerCase())
    ) || []; // Added optional chaining for safety

  // Sort customers
  const sortedCustomers = [...filteredCustomers].sort((a, b) => {
    let comparison = 0;
    // Ensure properties exist before comparing
    if (sortField === "customerName") {
      comparison = (a.customerName || "").localeCompare(b.customerName || "");
    } else if (sortField === "totalSpent") {
      comparison = (a.totalSpent || 0) - (b.totalSpent || 0);
    } else if (sortField === "bookingsCount") {
      comparison = (a.bookingsCount || 0) - (b.bookingsCount || 0);
    }
    return sortDirection === "asc" ? comparison : -comparison;
  });

  // Toggle sort direction
  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc"); // Default to desc when changing field
    }
  };

  // Prepare chart data
  const prepareMonthlyRevenueChart = () => {
    if (!revenueData?.monthlyRevenue || revenueData.monthlyRevenue.length === 0)
      return null; // Added check for empty array
    const labels = revenueData.monthlyRevenue.map((item) =>
      formatMonth(item.month)
    );
    const data = revenueData.monthlyRevenue.map((item) => item.amount || 0); // Default to 0 if amount is missing
    return {
      labels,
      datasets: [
        {
          label: "Monthly Revenue",
          data,
          fill: true,
          backgroundColor: "rgba(75, 192, 192, 0.2)",
          borderColor: "rgba(75, 192, 192, 1)",
          tension: 0.4,
        },
      ],
    };
  };

  const prepareTopBillboardsChart = () => {
    if (!revenueData?.topBillboards || revenueData.topBillboards.length === 0)
      return null;
    // Take top 5 billboards
    const topBillboards = revenueData.topBillboards.slice(0, 5);
    const labels = topBillboards.map(
      (item) => item.billboardTitle || "Unknown Billboard"
    ); // Default label
    const data = topBillboards.map((item) => item.totalRevenue || 0); // Default revenue
    return {
      labels,
      datasets: [
        {
          label: "Revenue by Billboard",
          data,
          backgroundColor: [
            "rgba(255, 99, 132, 0.7)",
            "rgba(54, 162, 235, 0.7)",
            "rgba(255, 206, 86, 0.7)",
            "rgba(75, 192, 192, 0.7)",
            "rgba(153, 102, 255, 0.7)",
          ],
          borderColor: [
            "rgba(255, 99, 132, 1)",
            "rgba(54, 162, 235, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(75, 192, 192, 1)",
            "rgba(153, 102, 255, 1)",
          ],
          borderWidth: 1,
        },
      ],
    };
  };

  const prepareCustomerDistributionChart = () => {
    if (
      !revenueData?.customerRevenue ||
      revenueData.customerRevenue.length === 0
    )
      return null;

    // Group customers by spending ranges
    const spendingRanges = {
      "Under PKR 1,000": 0,
      "PKR 1,000 - PKR 4,999": 0, // Adjusted ranges for clarity
      "PKR 5,000 - PKR 9,999": 0,
      "PKR 10,000 - PKR 19,999": 0,
      "PKR 20,000 & Over": 0, // Adjusted label
    };

    revenueData.customerRevenue.forEach((customer) => {
      const spent = customer.totalSpent || 0; // Handle potentially missing value
      if (spent < 1000) {
        spendingRanges["Under PKR 1,000"]++;
      } else if (spent < 5000) {
        spendingRanges["PKR 1,000 - PKR 4,999"]++;
      } else if (spent < 10000) {
        spendingRanges["PKR 5,000 - PKR 9,999"]++;
      } else if (spent < 20000) {
        spendingRanges["PKR 10,000 - PKR 19,999"]++;
      } else {
        spendingRanges["PKR 20,000 & Over"]++;
      }
    });

    const labels = Object.keys(spendingRanges);
    const data = Object.values(spendingRanges);

    // Filter out ranges with 0 customers for a cleaner chart
    const filteredLabels = labels.filter((_, index) => data[index] > 0);
    const filteredData = data.filter((value) => value > 0);

    if (filteredData.length === 0) return null; // No customers fit any range

    return {
      labels: filteredLabels,
      datasets: [
        {
          label: "Customer Spending Distribution",
          data: filteredData,
          backgroundColor: [
            // Ensure enough colors if ranges change
            "rgba(255, 99, 132, 0.7)",
            "rgba(54, 162, 235, 0.7)",
            "rgba(255, 206, 86, 0.7)",
            "rgba(75, 192, 192, 0.7)",
            "rgba(153, 102, 255, 0.7)",
            "rgba(255, 159, 64, 0.7)",
          ],
          borderColor: [
            "rgba(255, 99, 132, 1)",
            "rgba(54, 162, 235, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(75, 192, 192, 1)",
            "rgba(153, 102, 255, 1)",
            "rgba(255, 159, 64, 1)",
          ],
          borderWidth: 1,
        },
      ],
    };
  };

  // Prepare payment method distribution chart
  const preparePaymentMethodChart = () => {
    if (!revenueData?.paymentMethods || revenueData.paymentMethods.length === 0) {
      // If no payment methods data, try to calculate from bookings
      if (!revenueData?.recentBookings || revenueData.recentBookings.length === 0) {
        return null;
      }

      // Count payment methods from recent bookings
      const methodCounts: Record<string, number> = {};
      const methodAmounts: Record<string, number> = {};

      revenueData.recentBookings.forEach(booking => {
        const method = booking.paymentMethod || 'Unknown';
        methodCounts[method] = (methodCounts[method] || 0) + 1;
        methodAmounts[method] = (methodAmounts[method] || 0) + (booking.amount || 0);
      });

      const labels = Object.keys(methodCounts);
      const data = Object.values(methodCounts);

      if (data.length === 0) return null;

      return {
        labels,
        datasets: [
          {
            label: "Payment Methods Distribution",
            data,
            backgroundColor: [
              "rgba(54, 162, 235, 0.7)",
              "rgba(255, 99, 132, 0.7)",
              "rgba(255, 206, 86, 0.7)",
              "rgba(75, 192, 192, 0.7)",
              "rgba(153, 102, 255, 0.7)",
            ],
            borderColor: [
              "rgba(54, 162, 235, 1)",
              "rgba(255, 99, 132, 1)",
              "rgba(255, 206, 86, 1)",
              "rgba(75, 192, 192, 1)",
              "rgba(153, 102, 255, 1)",
            ],
            borderWidth: 1,
          },
        ],
      };
    }

    // Use the payment methods data from the API
    const labels = revenueData.paymentMethods.map(pm =>
      pm.method.charAt(0).toUpperCase() + pm.method.slice(1) || 'Unknown'
    );
    const data = revenueData.paymentMethods.map(pm => pm.count);

    return {
      labels,
      datasets: [
        {
          label: "Payment Methods Distribution",
          data,
          backgroundColor: [
            "rgba(54, 162, 235, 0.7)",
            "rgba(255, 99, 132, 0.7)",
            "rgba(255, 206, 86, 0.7)",
            "rgba(75, 192, 192, 0.7)",
            "rgba(153, 102, 255, 0.7)",
          ],
          borderColor: [
            "rgba(54, 162, 235, 1)",
            "rgba(255, 99, 132, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(75, 192, 192, 1)",
            "rgba(153, 102, 255, 1)",
          ],
          borderWidth: 1,
        },
      ],
    };
  };

  // Handle customer selection
  const handleCustomerSelect = async (customer: CustomerRevenue) => {
    console.log("Selected customer:", customer); // Add logging to debug

    try {
      // Fetch detailed customer booking data from the API
      const response = await axios.get(
        `/api/booking/customer-bookings/${customer.customerId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      if (response.data && response.data.status === 1) {
        console.log("Fetched customer bookings:", response.data.data);

        // Create a deep copy to avoid reference issues
        const customerCopy = JSON.parse(JSON.stringify(customer));

        // Add the detailed booking information
        customerCopy.bookings = response.data.data.bookings || [];

        setSelectedCustomer(customerCopy);
        setShowCustomerDetails(true);
      } else {
        toast.error("Failed to load customer booking details");
        console.error("API error:", response.data);
      }
    } catch (error) {
      console.error("Error fetching customer bookings:", error);
      toast.error("Failed to load customer details");

      // Fallback to using the existing data
      const customerCopy = JSON.parse(JSON.stringify(customer));
      if (!customerCopy.bookings || !Array.isArray(customerCopy.bookings)) {
        customerCopy.bookings = [];
      }

      setSelectedCustomer(customerCopy);
      setShowCustomerDetails(true);
    }
  };

  // Export data as CSV
  const exportToCSV = () => {
    if (
      !revenueData?.customerRevenue ||
      revenueData.customerRevenue.length === 0
    ) {
      alert("No customer data available to export."); // Inform user
      return;
    }
    // Define headers more robustly
    const headers = [
      "Customer Name",
      "Email",
      "Total Spent (USD)",
      "Bookings Count",
    ];
    const rows = revenueData.customerRevenue.map((customer) => [
      `"${(customer.customerName || "").replace(/"/g, '""')}"`, // Escape quotes within names
      `"${(customer.customerEmail || "").replace(/"/g, '""')}"`, // Escape quotes within emails
      customer.totalSpent?.toString() || "0", // Handle missing value
      customer.bookingsCount?.toString() || "0", // Handle missing value
    ]);

    // Construct CSV content
    const csvContent = [
      headers.join(","),
      ...rows.map((row) => row.join(",")),
    ].join("\n");

    // Create and trigger download
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    const timestamp = new Date().toISOString().split("T")[0];
    link.setAttribute("download", `revenue_report_${timestamp}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url); // Clean up blob URL
  };

  // Render loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="flex items-center text-gray-600">
          <FaSpinner className="animate-spin text-indigo-600 text-3xl mr-3" />
          <p className="text-lg">Loading revenue data...</p>
        </div>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center">
        <FaExclamationTriangle className="text-red-500 text-4xl mb-3" />
        <p className="text-red-600 text-lg font-semibold mb-2">
          Failed to load data
        </p>
        <p className="text-red-500 max-w-md">{error}</p>
        <button
          onClick={fetchRevenueData}
          className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  // Show loading indicator
  if (loading && !revenueData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500 mb-4"></div>
        <p className="text-indigo-600 text-lg font-semibold">
          Loading your agency's revenue data...
        </p>
        <p className="text-gray-500 mt-2">
          This may take a moment as we gather your agency-specific information.
        </p>
      </div>
    );
  }

  // Render main component if data loaded successfully
  return (
    <>
      {" "}
      {/* Using Fragment shorthand */}
      <Breadcrumb pageName="Revenue Management" />
      {/* --- FIX 5: Removed unnecessary outer div, direct children of fragment is fine --- */}
      {/* Header with filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        {" "}
        {/* Added mb-6 for spacing */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">
              Your Agency Revenue Dashboard
            </h1>
            <p className="text-gray-600 mt-1">
              Track and analyze revenue from your agency's billboards only
            </p>
            <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded-md">
              <p className="text-xs text-blue-700">
                <span className="font-semibold">Note:</span> This dashboard
                shows data only for your agency. Each agency has their own
                separate revenue system and cannot view data from other
                agencies.
              </p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {" "}
            {/* Added items-center */}
            <div className="flex items-center gap-2">
              <label
                htmlFor="startDate"
                className="text-sm text-gray-600 whitespace-nowrap"
              >
                From:
              </label>
              <input
                type="date"
                id="startDate"
                value={dateRange.startDate}
                onChange={(e) =>
                  setDateRange((prev) => ({
                    ...prev,
                    startDate: e.target.value,
                  }))
                }
                className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                max={dateRange.endDate}
              />
            </div>
            <div className="flex items-center gap-2">
              <label
                htmlFor="endDate"
                className="text-sm text-gray-600 whitespace-nowrap"
              >
                To:
              </label>
              <input
                type="date"
                id="endDate"
                value={dateRange.endDate}
                onChange={(e) =>
                  setDateRange((prev) => ({ ...prev, endDate: e.target.value }))
                }
                className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min={dateRange.startDate} // Prevent end date before start date
              />
            </div>
            <button
              onClick={fetchRevenueData}
              disabled={loading} // Disable button while loading
              className={`bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors flex items-center ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              {loading ? (
                <FaSpinner className="animate-spin mr-2" />
              ) : (
                <FaFilter className="inline mr-2" />
              )}
              Apply
            </button>
          </div>
        </div>
      </div>
      <div className="container mx-auto px-4">
        <div className="container mx-auto px-4">
          {/* Summary Cards */}
          <div className="grid gap-6 mb-6 grid-cols-[repeat(auto-fit,minmax(250px,1fr))]">
            {/* Total Revenue Card */}
            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
              <div className="flex items-start justify-between">
                {/* Add min-w-0 to allow the inner text container to shrink properly */}
                <div className="min-w-0">
                  <p className="text-sm text-gray-600 font-medium">
                    Your Agency's Total Revenue
                  </p>
                  <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all">
                    {formatCurrency(revenueData?.totalRevenue || 0)}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">
                    Period: {formatDate(dateRange.startDate)} -{" "}
                    {formatDate(dateRange.endDate)}
                  </p>
                </div>
                <div className="p-3 bg-green-100 rounded-full">
                  <FaMoneyBillWave className="text-green-600 text-xl" />
                </div>
              </div>
            </div>

            {/* Total Bookings Card */}
            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
              <div className="flex items-start justify-between">
                <div className="min-w-0">
                  <p className="text-sm text-gray-600 font-medium">
                    Your Agency's Bookings
                  </p>
                  <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all">
                    {revenueData?.totalBookings?.toLocaleString() || 0}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">
                    Completed transactions
                  </p>
                </div>
                <div className="p-3 bg-blue-100 rounded-full">
                  <FaCalendarAlt className="text-blue-600 text-xl" />
                </div>
              </div>
            </div>

            {/* Total Customers Card */}
            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
              <div className="flex items-start justify-between">
                <div className="min-w-0">
                  <p className="text-sm text-gray-600 font-medium">
                    Your Agency's Customers
                  </p>
                  <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all">
                    {revenueData?.customerRevenue?.length?.toLocaleString() ||
                      0}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">
                    Paying customers in period
                  </p>
                </div>
                <div className="p-3 bg-purple-100 rounded-full">
                  <FaUsers className="text-purple-600 text-xl" />
                </div>
              </div>
            </div>

            {/* Average Revenue Card */}
            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-amber-500">
              <div className="flex items-start justify-between">
                <div className="min-w-0">
                  <p className="text-sm text-gray-600 font-medium">
                    Your Avg. Revenue / Booking
                  </p>
                  <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all">
                    {formatCurrency(
                      revenueData &&
                        revenueData.totalBookings &&
                        revenueData.totalBookings > 0
                        ? (revenueData.totalRevenue || 0) /
                            revenueData.totalBookings
                        : 0
                    )}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">
                    Per transaction average
                  </p>
                </div>
                <div className="p-3 bg-amber-100 rounded-full">
                  <FaChartLine className="text-amber-600 text-xl" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Monthly Revenue Chart */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Your Agency's Monthly Revenue Trend
          </h3>
          {prepareMonthlyRevenueChart() ? (
            <div className="h-80">
              {" "}
              {/* Consider adjusting height based on content */}
              <Line
                data={prepareMonthlyRevenueChart()!} // Use non-null assertion as we checked above
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: "top" as const }, // Explicit type
                    tooltip: {
                      callbacks: {
                        label: function (context) {
                          return `Revenue: ${formatCurrency(context.raw as number)}`;
                        },
                      },
                    },
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: {
                        callback: function (value) {
                          return formatCurrency(value as number);
                        },
                      },
                    },
                  },
                }}
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-80 bg-gray-50 rounded-lg">
              <p className="text-gray-500">
                No monthly revenue data for this period.
              </p>
            </div>
          )}
        </div>

        {/* Top Billboards Chart */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Your Agency's Top 5 Performing Billboards
          </h3>
          {prepareTopBillboardsChart() ? (
            <div className="h-80">
              <Bar
                data={prepareTopBillboardsChart()!}
                options={{
                  indexAxis: "y" as const, // Horizontal bar chart might be better for labels
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { display: false },
                    tooltip: {
                      callbacks: {
                        label: function (context) {
                          return `Revenue: ${formatCurrency(context.raw as number)}`;
                        },
                      },
                    },
                  },
                  scales: {
                    x: {
                      // Changed from y to x for horizontal bar chart
                      beginAtZero: true,
                      ticks: {
                        callback: function (value) {
                          return formatCurrency(value as number);
                        },
                      },
                    },
                  },
                }}
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-80 bg-gray-50 rounded-lg">
              <p className="text-gray-500">
                No billboard revenue data for this period.
              </p>
            </div>
          )}
        </div>

        {/* Customer Distribution Chart */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Your Agency's Customer Spending Distribution
          </h3>
          {prepareCustomerDistributionChart() ? (
            <div className="h-80 flex items-center justify-center">
              {" "}
              {/* Added centering */}
              <Doughnut
                data={prepareCustomerDistributionChart()!}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: "right" as const }, // Explicit type
                    tooltip: {
                      callbacks: {
                        label: function (context) {
                          const value = context.raw as number;
                          const totalCustomers =
                            revenueData?.customerRevenue?.length || 1; // Avoid division by zero
                          const percentage = Math.round(
                            (value / totalCustomers) * 100
                          );
                          return `${context.label}: ${value} customers (${percentage}%)`;
                        },
                      },
                    },
                  },
                }}
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-80 bg-gray-50 rounded-lg">
              <p className="text-gray-500">
                No customer data available for distribution.
              </p>
            </div>
          )}
        </div>

        {/* Payment Methods Chart */}
        {showPaymentMethodChart && (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-800">
                Payment Methods Distribution
              </h3>
              <div className="flex items-center">
                <select
                  value={paymentMethodFilter}
                  onChange={(e) => setPaymentMethodFilter(e.target.value)}
                  className="text-sm border border-gray-300 rounded-md px-2 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">All Methods</option>
                  <option value="jazzcash">JazzCash</option>
                  <option value="easypais">EasyPaisa</option>
                  <option value="nayapay">NayaPay</option>
                  <option value="stripe">Stripe</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
            {preparePaymentMethodChart() ? (
              <div className="h-80 flex items-center justify-center">
                <Doughnut
                  data={preparePaymentMethodChart()!}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: { position: "right" as const },
                      tooltip: {
                        callbacks: {
                          label: function (context) {
                            const value = context.raw as number;
                            const totalBookings = revenueData?.totalBookings || 1;
                            const percentage = Math.round((value / totalBookings) * 100);
                            return `${context.label}: ${value} payments (${percentage}%)`;
                          },
                        },
                      },
                    },
                  }}
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-80 bg-gray-50 rounded-lg">
                <p className="text-gray-500">
                  No payment method data available for this period.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Recent Bookings */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Your Agency's Recent Bookings
          </h3>
          {revenueData?.recentBookings &&
          revenueData.recentBookings.length > 0 ? (
            <div className="overflow-auto max-h-80">
              {" "}
              {/* Max height for scroll */}
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50 sticky top-0">
                  {" "}
                  {/* Sticky header */}
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Customer
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Billboard
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Payment
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {revenueData.recentBookings.map((booking) => (
                    <tr key={booking.bookingId} className="hover:bg-gray-50">
                      <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {booking.customerName || "N/A"}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                        {booking.billboardTitle || "N/A"}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatCurrency(booking.amount || 0)}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                        {booking.paymentMethod ? (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">
                            {booking.paymentMethod}
                          </span>
                        ) : (
                          "N/A"
                        )}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(booking.date)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex items-center justify-center h-80 bg-gray-50 rounded-lg">
              <p className="text-gray-500">
                No recent bookings found in this period.
              </p>
            </div>
          )}
        </div>
      </div>
      {/* Customer Revenue Table */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <h3 className="text-lg font-semibold text-gray-800">
            Your Agency's Customer Revenue Details
          </h3>
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {" "}
            {/* Added items-center */}
            <div className="relative flex-grow sm:flex-grow-0">
              {" "}
              {/* Allow search to grow on small screens */}
              <input
                type="text"
                placeholder="Search customers (name/email)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
              />
              <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            <button
              onClick={exportToCSV}
              className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center text-sm" // Consistent text size
            >
              <FaDownload className="inline mr-2" />
              Export CSV
            </button>
          </div>
        </div>
        {sortedCustomers.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                    onClick={() => toggleSort("customerName")}
                  >
                    Customer
                    {sortField === "customerName" &&
                      (sortDirection === "asc" ? (
                        <FaSortAmountUp className="inline ml-1 text-gray-700" />
                      ) : (
                        <FaSortAmountDown className="inline ml-1 text-gray-700" />
                      ))}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                    onClick={() => toggleSort("totalSpent")}
                  >
                    Total Spent
                    {sortField === "totalSpent" &&
                      (sortDirection === "asc" ? (
                        <FaSortAmountUp className="inline ml-1 text-gray-700" />
                      ) : (
                        <FaSortAmountDown className="inline ml-1 text-gray-700" />
                      ))}
                  </th>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                    onClick={() => toggleSort("bookingsCount")}
                  >
                    Bookings
                    {sortField === "bookingsCount" &&
                      (sortDirection === "asc" ? (
                        <FaSortAmountUp className="inline ml-1 text-gray-700" />
                      ) : (
                        <FaSortAmountDown className="inline ml-1 text-gray-700" />
                      ))}
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sortedCustomers.map((customer) => (
                  <tr key={customer.customerId} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-indigo-100 rounded-full flex items-center justify-center">
                          {/* Placeholder icon, replace with image if available */}
                          <FaUserCircle className="h-6 w-6 text-indigo-600" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {customer.customerName || "N/A"}
                          </div>
                          {/* Removed email here as it's in its own column */}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {customer.customerEmail || "N/A"}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {formatCurrency(customer.totalSpent || 0)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                      {" "}
                      {/* Centered count */}
                      {customer.bookingsCount || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleCustomerSelect(customer)}
                        className="text-indigo-600 hover:text-indigo-900 hover:underline"
                      >
                        View Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="flex items-center justify-center h-40 bg-gray-50 rounded-lg">
            <p className="text-gray-500">
              {searchTerm
                ? "No customers match your search."
                : "No customer revenue data available for this period."}
            </p>
          </div>
        )}
      </div>
      {/* Customer Details Modal */}
      {showCustomerDetails && selectedCustomer && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 transition-opacity duration-300">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col transform transition-all duration-300">
            {/* Modal Header */}
            <div className="p-5 border-b border-gray-200 flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-gray-800">
                  Customer Details
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  {selectedCustomer.customerName || "Unknown"} (
                  {selectedCustomer.customerEmail || "No email"})
                </p>
              </div>
              <button
                onClick={() => setShowCustomerDetails(false)}
                className="text-gray-400 hover:text-gray-600 focus:outline-none p-1 rounded-full hover:bg-gray-100"
                aria-label="Close modal"
              >
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
            {/* Modal Body */}
            <div className="p-6 flex-1 overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                {/* Summary Section */}
                <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100">
                  <h4 className="text-md font-semibold text-indigo-800 mb-3">
                    Spending Summary
                  </h4>
                  <div className="space-y-2 text-sm">
                    <p className="flex justify-between">
                      <span className="text-gray-600">Total Spent:</span>
                      <span className="font-semibold text-gray-800">
                        {formatCurrency(selectedCustomer.totalSpent || 0)}
                      </span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-gray-600">Total Bookings:</span>
                      <span className="font-semibold text-gray-800">
                        {selectedCustomer.bookingsCount || 0}
                      </span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-gray-600">
                        Average per Booking:
                      </span>
                      <span className="font-semibold text-gray-800">
                        {formatCurrency(
                          (selectedCustomer.bookingsCount || 0) > 0
                            ? (selectedCustomer.totalSpent || 0) /
                                selectedCustomer.bookingsCount
                            : 0
                        )}
                      </span>
                    </p>
                  </div>
                </div>

                {/* Booking History Section */}
                <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                  <h4 className="text-md font-semibold text-green-800 mb-3">
                    Booking Activity
                  </h4>
                  {selectedCustomer.bookings &&
                  Array.isArray(selectedCustomer.bookings) &&
                  selectedCustomer.bookings.length > 0 ? (
                    <div className="space-y-2 text-sm">
                      <p className="flex justify-between">
                        <span className="text-gray-600">First Booking:</span>
                        <span className="font-semibold text-gray-800">
                          {/* Sort bookings by date to find the first one reliably */}
                          {selectedCustomer.bookings.length > 0 &&
                          selectedCustomer.bookings[0]?.date
                            ? formatDate(
                                selectedCustomer.bookings.sort(
                                  (a, b) =>
                                    new Date(a.date || 0).getTime() -
                                    new Date(b.date || 0).getTime()
                                )[0]?.date
                              )
                            : "N/A"}
                        </span>
                      </p>
                      <p className="flex justify-between">
                        <span className="text-gray-600">Latest Booking:</span>
                        <span className="font-semibold text-gray-800">
                          {/* Sort bookings by date descending to find the latest one reliably */}
                          {selectedCustomer.bookings.length > 0 &&
                          selectedCustomer.bookings[0]?.date
                            ? formatDate(
                                selectedCustomer.bookings.sort(
                                  (a, b) =>
                                    new Date(b.date || 0).getTime() -
                                    new Date(a.date || 0).getTime()
                                )[0]?.date
                              )
                            : "N/A"}
                        </span>
                      </p>
                      <p className="flex justify-between">
                        <span className="text-gray-600">
                          Total Duration Booked:
                        </span>
                        <span className="font-semibold text-gray-800">
                          {selectedCustomer.bookings.reduce(
                            (sum, booking) => sum + (booking.duration || 0),
                            0
                          )}{" "}
                          days
                        </span>
                      </p>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">
                      No booking history found.
                    </p>
                  )}
                </div>

                {/* Payment Methods Section */}
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                  <h4 className="text-md font-semibold text-blue-800 mb-3">
                    Payment Methods Used
                  </h4>
                  {selectedCustomer.bookings &&
                  Array.isArray(selectedCustomer.bookings) &&
                  selectedCustomer.bookings.length > 0 ? (
                    <div className="space-y-2">
                      {/* Count payment methods */}
                      {(() => {
                        const methodCounts: Record<string, number> = {};
                        selectedCustomer.bookings.forEach(booking => {
                          const method = booking.paymentMethod || 'Unknown';
                          methodCounts[method] = (methodCounts[method] || 0) + 1;
                        });

                        return Object.entries(methodCounts).map(([method, count]) => (
                          <div key={method} className="flex justify-between items-center">
                            <span className="flex items-center">
                              <span className="w-3 h-3 rounded-full bg-blue-500 mr-2"></span>
                              <span className="text-gray-700 capitalize">{method}</span>
                            </span>
                            <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                              {count} {count === 1 ? 'booking' : 'bookings'}
                            </span>
                          </div>
                        ));
                      })()}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">
                      No payment method data available.
                    </p>
                  )}
                </div>
              </div>
              {/* Booking Details Table */}
              <h4 className="text-md font-semibold text-gray-800 mb-4">
                Booking Details
              </h4>
              {selectedCustomer.bookings &&
              Array.isArray(selectedCustomer.bookings) &&
              selectedCustomer.bookings.length > 0 ? (
                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Billboard
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Location
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Dates
                        </th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Duration
                        </th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Payment Method
                        </th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Amount
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {/* Sort bookings by date descending for display */}
                      {selectedCustomer.bookings
                        .sort((a, b) => {
                          // Safely handle missing dates
                          const dateA = a.date ? new Date(a.date).getTime() : 0;
                          const dateB = b.date ? new Date(b.date).getTime() : 0;
                          return dateB - dateA;
                        })
                        .map((booking) => (
                          <tr
                            key={booking.bookingId}
                            className="hover:bg-gray-50 text-sm"
                          >
                            <td className="px-4 py-3 whitespace-nowrap font-medium text-gray-900">
                              {booking.billboardTitle || "N/A"}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-gray-500">
                              <div className="flex items-center">
                                <FaMapMarkerAlt
                                  className="text-red-500 mr-1.5 flex-shrink-0"
                                  size={14}
                                />
                                <span>
                                  {booking.billboardLocation || "N/A"}
                                </span>
                              </div>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-gray-500">
                              {booking.startDate
                                ? formatDate(booking.startDate)
                                : "N/A"}{" "}
                              -{" "}
                              {booking.endDate
                                ? formatDate(booking.endDate)
                                : "N/A"}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-gray-500 text-center">
                              {booking.duration || "N/A"} days
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-center">
                              {booking.paymentMethod ? (
                                <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">
                                  {booking.paymentMethod}
                                </span>
                              ) : (
                                <span className="text-gray-400">-</span>
                              )}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-center">
                              {booking.status ? (
                                <span className={`px-2 py-1 text-xs font-medium rounded-full
                                  ${booking.status.includes('rejected') ? 'bg-red-100 text-red-800' :
                                    booking.status === 'live' ? 'bg-green-100 text-green-800' :
                                    booking.status.includes('verified') ? 'bg-blue-100 text-blue-800' :
                                    'bg-yellow-100 text-yellow-800'
                                  } capitalize`}>
                                  {booking.status.replace(/_/g, ' ')}
                                </span>
                              ) : (
                                <span className="text-gray-400">-</span>
                              )}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap font-medium text-gray-900 text-right">
                              {formatCurrency(booking.amount || 0)}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="flex items-center justify-center h-20 bg-gray-50 rounded-lg">
                  <p className="text-gray-500 text-sm">
                    No specific booking details found for this customer.
                  </p>
                </div>
              )}
            </div>
            {/* Modal Footer */}
            <div className="p-4 border-t border-gray-200 bg-gray-50 flex justify-end">
              <button
                onClick={() => setShowCustomerDetails(false)}
                className="bg-gray-200 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-300 transition-colors text-sm font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default RevenueManagementPage;
