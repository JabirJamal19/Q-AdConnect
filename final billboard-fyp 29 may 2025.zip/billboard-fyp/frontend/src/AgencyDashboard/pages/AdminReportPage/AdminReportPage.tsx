import React, { useCallback, useEffect, useState } from "react";
import toast from "react-hot-toast";
import {
  FaCheckCircle,
  FaHourglassHalf,
  FaTimesCircle,
  FaTools,
} from "react-icons/fa";
import { MdDelete, MdRefresh, MdSearch, MdVisibility } from "react-icons/md";
import axios from "../../../axiosInstance";
import { useAuthStore } from "../../../stores/authStore";
import Breadcrumb from "../../components/Breadcrumbs/Breadcrumb";

interface Report {
  _id: string;
  title: string;
  description: string;
  status: "pending" | "in-progress" | "resolved" | "rejected";
  statusNote?: string;
  createdAt: string;
  updatedAt: string;
  userId?: {
    _id: string;
    name: string;
    email: string;
  };
  userEmail: string;
}

const AdminReportPage: React.FC = () => {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [newStatus, setNewStatus] = useState<string>("");
  const [statusNote, setStatusNote] = useState<string>("");
  const [deletingReportId, setDeletingReportId] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const token = useAuthStore((state) => state.token);
  const user = useAuthStore((state) => state.user);
  const isAdmin = user?.role === "admin";

  const fetchReports = useCallback(async () => {
    if (!token) return;

    setLoading(true);
    try {
      // Use different endpoints based on user role
      const endpoint = isAdmin ? "/api/report/all" : "/api/report/user-reports";

      const response = await axios.get(endpoint, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Check if response has the expected structure
      if (response.data && Array.isArray(response.data.reports)) {
        setReports(response.data.reports);
      } else {
        console.error("Invalid API response format:", response.data);
        toast.error("Received invalid data format from server");
        setReports([]);
      }
    } catch (err: any) {
      console.error("Fetch reports error:", err);
      toast.error(err.response?.data?.message || "Failed to fetch reports");
      setReports([]);
    } finally {
      setLoading(false);
    }
  }, [token, isAdmin]);

  useEffect(() => {
    if (token) {
      fetchReports();
    }
  }, [token, fetchReports]);

  const handleDelete = async (reportId: string) => {
    if (!window.confirm("Are you sure you want to delete this report?")) return;
    try {
      setDeletingReportId(reportId);

      // Use different endpoints based on user role
      const endpoint = isAdmin
        ? `/api/report/admin/delete/${reportId}`
        : `/api/report/delete/${reportId}`;

      await axios.delete(endpoint, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success("Report deleted successfully");
      fetchReports();
    } catch (err: any) {
      console.error("Delete report error:", err);
      toast.error(err.response?.data?.message || "Failed to delete report");
    } finally {
      setDeletingReportId(null);
    }
  };

  const handleStatusUpdate = async () => {
    if (!selectedReport) return;
    try {
      setIsProcessing(true);
      await axios.put(
        `/api/report/${selectedReport._id}/status`,
        {
          status: newStatus,
          statusNote: statusNote, // Include the admin's note about the status change
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success("Status updated successfully");
      fetchReports();
      closeModal();
    } catch (err: any) {
      toast.error(err.response?.data?.message || "Failed to update status");
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusBadgeColor = (status: string) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      "in-progress": "bg-blue-100 text-blue-800",
      resolved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
    };
    return colors[status as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  const filteredReports = reports.filter((report) => {
    // Filter by status
    const statusMatch =
      filterStatus === "all" ? true : report.status === filterStatus;

    // Filter by search term (title, description, or user email/name)
    const searchMatch =
      searchTerm.trim() === ""
        ? true
        : report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          report.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          report.userId?.name
            ?.toLowerCase()
            .includes(searchTerm.toLowerCase()) ||
          false ||
          report.userEmail?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          false;

    return statusMatch && searchMatch;
  });

  const openModal = (report: Report) => {
    setSelectedReport(report);
    setNewStatus(report.status);
    setStatusNote(""); // Clear previous notes
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedReport(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 2xl:p-10">
      <Breadcrumb pageName={isAdmin ? "Reports Management" : "My Reports"} />

      {/* Header with stats */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">
          User Reports Dashboard
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          Manage and respond to user-submitted reports and issues
        </p>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-yellow-500">
            <div className="flex justify-between">
              <div>
                <p className="text-sm text-gray-500">Pending</p>
                <p className="text-2xl font-semibold">
                  {reports.filter((r) => r.status === "pending").length}
                </p>
              </div>
              <div className="bg-yellow-100 p-2 rounded-full">
                <FaHourglassHalf className="text-yellow-500" size={20} />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-blue-500">
            <div className="flex justify-between">
              <div>
                <p className="text-sm text-gray-500">In Progress</p>
                <p className="text-2xl font-semibold">
                  {reports.filter((r) => r.status === "in-progress").length}
                </p>
              </div>
              <div className="bg-blue-100 p-2 rounded-full">
                <FaTools className="text-blue-500" size={20} />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-green-500">
            <div className="flex justify-between">
              <div>
                <p className="text-sm text-gray-500">Resolved</p>
                <p className="text-2xl font-semibold">
                  {reports.filter((r) => r.status === "resolved").length}
                </p>
              </div>
              <div className="bg-green-100 p-2 rounded-full">
                <FaCheckCircle className="text-green-500" size={20} />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-4 border-l-4 border-red-500">
            <div className="flex justify-between">
              <div>
                <p className="text-sm text-gray-500">Rejected</p>
                <p className="text-2xl font-semibold">
                  {reports.filter((r) => r.status === "rejected").length}
                </p>
              </div>
              <div className="bg-red-100 p-2 rounded-full">
                <FaTimesCircle className="text-red-500" size={20} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="mb-6 flex flex-col md:flex-row justify-between gap-4">
        <div className="flex flex-wrap gap-4">
          <select
            className="px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="in-progress">In Progress</option>
            <option value="resolved">Resolved</option>
            <option value="rejected">Rejected</option>
          </select>

          <button
            onClick={fetchReports}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors flex items-center gap-2"
            title="Refresh reports"
          >
            <MdRefresh size={18} />
            Refresh
          </button>
        </div>

        <div className="relative">
          <input
            type="text"
            placeholder="Search reports..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full md:w-64 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <MdSearch
            className="absolute left-3 top-2.5 text-gray-400"
            size={18}
          />
        </div>
      </div>

      {/* Add New Report Button (for non-admin users) */}
      {!isAdmin && (
        <div className="mb-6">
          <button
            onClick={() => {
              // Logic to create a new report would go here
              // For now, we'll just show a toast
              toast.success("This would open a new report form");
            }}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Submit New Report
          </button>
        </div>
      )}

      {/* Reports Table */}
      <div className="rounded-sm border border-stroke bg-white px-5 pt-6 pb-2.5 shadow-default dark:border-strokedark dark:bg-boxdark sm:px-7.5 xl:pb-1">
        <div className="max-w-full overflow-x-auto">
          <table className="w-full table-auto">
            <thead>
              <tr className="bg-gray-200 text-left">
                <th className="py-4 px-4 font-medium text-black">User Info</th>
                <th className="py-4 px-4 font-medium text-black">
                  Title & Description
                </th>
                <th className="py-4 px-4 font-medium text-black">Status</th>
                <th className="py-4 px-4 font-medium text-black">Date</th>
                <th className="py-4 px-4 font-medium text-black">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredReports.map((report) => (
                <tr key={report._id} className="border-b border-gray-200">
                  <td className="py-5 px-4">
                    <div className="flex flex-col gap-1">
                      <h5 className="font-medium text-black">
                        {report.userId?.name ||
                          report.userEmail ||
                          "Unknown User"}
                      </h5>
                      <p className="text-sm text-gray-600">
                        {report.userId?.email ||
                          report.userEmail ||
                          "No email available"}
                      </p>
                    </div>
                  </td>
                  <td className="py-5 px-4">
                    <div className="flex flex-col gap-1">
                      <h6 className="font-medium text-black">{report.title}</h6>
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {report.description}
                      </p>
                    </div>
                  </td>
                  <td className="py-5 px-4">
                    <span
                      className={`inline-flex text-center rounded-full py-1 px-3 text-sm font-medium w-[6.5rem]  ${getStatusBadgeColor(report.status)}`}
                    >
                      {report.status}
                    </span>
                  </td>
                  <td className="py-5 px-4">
                    <div className="flex flex-col gap-1">
                      <span className="text-sm text-black">
                        {new Date(report.createdAt).toLocaleDateString()}
                      </span>
                      <span className="text-xs text-gray-500">
                        {new Date(report.createdAt).toLocaleTimeString()}
                      </span>
                    </div>
                  </td>
                  <td className="py-5 px-4">
                    <div className="flex items-center space-x-3">
                      <button
                        className="hover:text-primary"
                        onClick={() => openModal(report)}
                        title={
                          isAdmin ? "View / Update Status" : "View Details"
                        }
                      >
                        <MdVisibility size={20} />
                      </button>

                      {/* Only show delete button if admin or if the report belongs to the current user */}
                      {(isAdmin ||
                        (!isAdmin && report.userId?._id === user?._id)) && (
                        <button
                          className={`${deletingReportId === report._id ? "text-gray-400 cursor-not-allowed" : "hover:text-red-600"}`}
                          onClick={() => handleDelete(report._id)}
                          title="Delete"
                          disabled={deletingReportId === report._id}
                        >
                          {deletingReportId === report._id ? (
                            <svg
                              className="animate-spin h-5 w-5"
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                              ></circle>
                              <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                              ></path>
                            </svg>
                          ) : (
                            <MdDelete size={20} />
                          )}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredReports.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No reports found
            </div>
          )}
        </div>
      </div>

      {/* Modal for Viewing / Updating Report */}
      {isModalOpen && selectedReport && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="text-lg font-medium text-gray-900">
                Update Report Status
              </h3>
              <button
                onClick={closeModal}
                className="text-gray-600 hover:text-gray-900"
              >
                &times;
              </button>
            </div>
            <div className="mt-4">
              <p className="mb-2 text-gray-700">
                <span className="font-medium">Title:</span>{" "}
                {selectedReport.title || "No title"}
              </p>
              <p className="mb-4 text-gray-600">
                {selectedReport.description || "No description"}
              </p>
              <p className="mb-2 text-gray-700">
                <span className="font-medium">Reported by:</span>{" "}
                {selectedReport.userId?.name ||
                  selectedReport.userEmail ||
                  "Unknown User"}
              </p>

              <div className="mb-4">
                <span className="font-medium text-gray-700">
                  Current Status:{" "}
                </span>
                <span
                  className={`inline-flex text-center rounded-full py-1 px-3 text-sm font-medium ${getStatusBadgeColor(selectedReport.status)}`}
                >
                  {selectedReport.status}
                </span>
              </div>

              {selectedReport.statusNote && (
                <div className="mb-4 p-3 bg-gray-50 rounded-md">
                  <p className="text-sm font-medium text-gray-700">
                    Admin Note:
                  </p>
                  <p className="text-sm text-gray-600">
                    {selectedReport.statusNote}
                  </p>
                </div>
              )}

              <label
                className="block mb-2 font-medium text-gray-700"
                htmlFor="status"
              >
                Update Status
              </label>
              <select
                id="status"
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value)}
                className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="pending">Pending</option>
                <option value="in-progress">In Progress</option>
                <option value="resolved">Resolved</option>
                <option value="rejected">Rejected</option>
              </select>

              <div className="mt-4">
                <label
                  className="block mb-2 font-medium text-gray-700"
                  htmlFor="statusNote"
                >
                  Add Note (Optional)
                </label>
                <textarea
                  id="statusNote"
                  value={statusNote}
                  onChange={(e) => setStatusNote(e.target.value)}
                  placeholder="Add a note about this status change..."
                  className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  rows={3}
                ></textarea>
              </div>
            </div>
            <div className="mt-6 flex justify-end space-x-3">
              <button
                onClick={closeModal}
                className="px-4 py-2 bg-gray-300 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={handleStatusUpdate}
                disabled={isProcessing}
                className={`px-4 py-2 bg-indigo-600 text-white rounded-md ${isProcessing ? "opacity-70 cursor-not-allowed" : "hover:bg-indigo-700"}`}
              >
                {isProcessing ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                        fill="none"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    Updating...
                  </span>
                ) : (
                  "Update Status"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminReportPage;
