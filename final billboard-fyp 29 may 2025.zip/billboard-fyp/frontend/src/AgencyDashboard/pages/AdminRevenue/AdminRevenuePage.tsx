import React, { useState, useEffect, useCallback } from "react";
import { useAuthStore } from "../../../stores/authStore";
import axios from "../../../axiosInstance";
import {
  FaChartLine,
  FaMoneyBillWave,
  FaUsers,
  FaBuilding,
  FaCalendarAlt,
  FaSearch,
  FaFilter,
  FaDownload,
  FaExclamationTriangle,
  FaSpinner,
  FaSortAmountDown,
  FaSortAmountUp,
} from "react-icons/fa";
import { Line, Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import Breadcrumb from "../../components/Breadcrumbs/Breadcrumb"; // Ensure this path is correct for your project structure

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

// Define interfaces
interface AgencyRevenue {
  agencyId: string;
  agencyName: string;
  agencyEmail: string;
  totalRevenue: number;
  bookingsCount: number;
  customersCount: number;
  billboardsCount: number; // Ensure your backend sends this if you use it
  monthlyRevenue: MonthlyRevenueItem[];
}

interface MonthlyRevenueItem {
  month: string; // Expects format like "YYYY-MM"
  amount: number;
}

interface TotalRevenueData {
  totalRevenue: number;
  totalBookings: number;
  totalAgencies: number;
  totalCustomers: number;
  totalBillboards: number; // Ensure your backend sends this
  monthlyRevenue: MonthlyRevenueItem[];
  agencyRevenues: AgencyRevenue[];
  topAgencies: AgencyRevenue[]; // Ensure your backend sends this, sorted by revenue desc
}

const AdminRevenuePage: React.FC = () => {
  const token = useAuthStore((state) => state.token);
  const user = useAuthStore((state) => state.user);
  // Ensure user role check is safe even if user is null/undefined initially
  const isAdmin = user?.role === "admin";

  // Log initial auth state
  useEffect(() => {
    console.log("Initial Auth state:", {
      token: !!token, // Log boolean for clarity
      user: user,
      isAdmin: isAdmin,
      isAuthenticated: !!token,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Run only once on mount

  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [revenueData, setRevenueData] = useState<TotalRevenueData | null>(null);
  const [dateRange, setDateRange] = useState<{
    startDate: string;
    endDate: string;
  }>({
    // Default to last 6 months from today
    startDate: new Date(new Date().setMonth(new Date().getMonth() - 6))
      .toISOString()
      .split("T")[0],
    endDate: new Date().toISOString().split("T")[0],
  });
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [sortField, setSortField] = useState<
    keyof AgencyRevenue | "agencyName"
  >("totalRevenue"); // Use keyof for type safety
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [selectedAgency, setSelectedAgency] = useState<AgencyRevenue | null>(
    null
  );
  const [showAgencyDetails, setShowAgencyDetails] = useState<boolean>(false);

  // Format currency (PKR)
  const formatCurrency = (amount: number): string => {
    // Handle potential non-numeric input gracefully
    if (isNaN(amount)) {
      return "PKR 0.00"; // Or some other placeholder
    }
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "PKR",
      // currencyDisplay: "narrowSymbol", // Using narrowSymbol might just show Rs. Use 'symbol' for "PKR" if needed
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  // Format date (e.g., Aug 15, 2024)
  const formatDate = (dateString: string): string => {
    try {
      return new Date(dateString).toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch (e) {
      console.error("Error formatting date:", dateString, e);
      return "Invalid Date";
    }
  };

  // Format month string (e.g., "2024-08" -> "Aug 2024")
  const formatMonth = (monthStr: string): string => {
    // Add validation for monthStr format
    if (!monthStr || !/^\d{4}-\d{2}$/.test(monthStr)) {
      console.warn("Invalid month string format:", monthStr);
      return "Invalid Month";
    }
    const [year, month] = monthStr.split("-");
    // Use UTC to avoid timezone issues when creating the date for formatting
    const date = new Date(
      Date.UTC(parseInt(year, 10), parseInt(month, 10) - 1, 1)
    );
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      timeZone: "UTC", // Specify timezone for consistency
    });
  };

  // Use this for fallback data when revenueData is null
  // Using useMemo helps avoid recreating this object on every render unless dependencies change (which they don't here)
  const safeRevenueData = React.useMemo(
    () =>
      revenueData || {
        totalRevenue: 0,
        totalBookings: 0,
        totalAgencies: 0,
        totalCustomers: 0,
        totalBillboards: 0,
        monthlyRevenue: [],
        agencyRevenues: [],
        topAgencies: [],
      },
    [revenueData]
  );

  // Fetch revenue data
  const fetchRevenueData = useCallback(async () => {
    if (!token) {
      setError("Authentication required. Please log in.");
      setLoading(false);
      return;
    }

    if (!isAdmin) {
      setError("You are not authorized to view this page.");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    setRevenueData(null); // Clear previous data before fetching

    try {
      // Validate date range
      const startDateObj = new Date(dateRange.startDate);
      const endDateObj = new Date(dateRange.endDate);

      if (isNaN(startDateObj.getTime()) || isNaN(endDateObj.getTime())) {
        throw new Error(
          "Invalid date format. Please check your date selections."
        );
      }

      if (endDateObj < startDateObj) {
        throw new Error("End date cannot be before start date.");
      }

      const params = new URLSearchParams({
        startDate: dateRange.startDate,
        endDate: dateRange.endDate,
      });

      console.log(
        "Fetching ADMIN revenue data with params:",
        params.toString()
      );

      // Use the correct ADMIN endpoint that returns platform-wide data
      const response = await axios.get(
        `/api/booking/admin-revenue?${params.toString()}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      console.log("API Response:", response.data); // Log the raw response

      // Check if the response structure is as expected for the ADMIN overview
      if (response.data && response.data.status === 1 && response.data.data) {
        // Directly set the data assuming the admin endpoint returns the correct TotalRevenueData structure
        const fetchedData = response.data.data as TotalRevenueData;

        // --- Optional: Add some validation ---
        if (
          !fetchedData ||
          typeof fetchedData.totalRevenue !== "number" ||
          !Array.isArray(fetchedData.agencyRevenues)
        ) {
          console.error(
            "Invalid data structure received from admin endpoint:",
            fetchedData
          );
          setError(
            "Received invalid data format from server for admin overview."
          );
          setRevenueData(null);
        } else {
          // The data from the admin endpoint should already contain totals and all agency revenues
          setRevenueData(fetchedData);
          console.log("Successfully set revenue data:", fetchedData);
        }
        // ================== REMOVED TRANSFORMATION ==================
        // The manual transformation from 'agencyData' to 'adminData' is removed
        // because the admin endpoint should provide the correct structure directly.
        // ============================================================
      } else {
        console.error(
          "Invalid API response format or status not 1:",
          response.data
        );
        // Use message from API if available, otherwise a generic one
        setError(
          response.data?.message ||
            "Received invalid data format or error status from server"
        );
        setRevenueData(null);
      }
    } catch (err: any) {
      console.error("Error fetching admin revenue data:", err);

      // Provide more detailed error information
      if (err.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        console.error("Response error data:", err.response.data);
        console.error("Response error status:", err.response.status);
        setError(
          `Server error (${err.response.status}): ${err.response?.data?.message || err.message || "Unknown error"}`
        );
      } else if (err.request) {
        // The request was made but no response was received
        console.error("Request error:", err.request);
        setError(
          "No response received from server. Please check your connection."
        );
      } else {
        // Something happened in setting up the request that triggered an Error
        console.error("Error message:", err.message);
        setError(err.message || "Error Loading Data");
      }

      setRevenueData(null); // Ensure data is cleared on error
    } finally {
      setLoading(false);
    }
    // Updated dependencies: include user details only if needed for the API call itself,
    // but the main dependencies are token, admin status, and dateRange.
  }, [token, isAdmin, dateRange.startDate, dateRange.endDate]); // Refined dependencies

  // Load data on mount and when date range or auth state changes
  useEffect(() => {
    // Fetch data only if authenticated and authorized
    if (token && isAdmin) {
      fetchRevenueData();
    } else if (!token) {
      setError("Authentication required. Please log in.");
      setLoading(false);
    } else if (!isAdmin) {
      setError("Access Denied: You do not have permission to view this page.");
      setLoading(false);
    }
    // Dependency array includes fetchRevenueData which itself depends on token, isAdmin, dateRange
  }, [fetchRevenueData, token, isAdmin]);

  // Filter agencies by search term (using safeRevenueData)
  // useMemo prevents recalculation on every render unless dependencies change
  const filteredAgencies = React.useMemo(() => {
    if (!safeRevenueData.agencyRevenues) return [];
    return safeRevenueData.agencyRevenues.filter(
      (agency) =>
        agency.agencyName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        agency.agencyEmail?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [safeRevenueData.agencyRevenues, searchTerm]);

  // Sort agencies (using filteredAgencies)
  // useMemo prevents recalculation on every render unless dependencies change
  const sortedAgencies = React.useMemo(() => {
    return [...filteredAgencies].sort((a, b) => {
      let comparison = 0;
      const field = sortField as keyof AgencyRevenue; // Type assertion for safety

      // Handle potential null/undefined values if necessary, although interfaces suggest they exist
      const valueA = a[field];
      const valueB = b[field];

      if (field === "agencyName" || field === "agencyEmail") {
        comparison = String(valueA).localeCompare(String(valueB));
      } else if (typeof valueA === "number" && typeof valueB === "number") {
        comparison = valueA - valueB;
      }
      // Add more checks if other types are possible

      return sortDirection === "asc" ? comparison : -comparison;
    });
  }, [filteredAgencies, sortField, sortDirection]);

  // Toggle sort direction
  const toggleSort = (field: keyof AgencyRevenue | "agencyName") => {
    // Use specific keys
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc"); // Default to descending for new field
    }
  };

  // Prepare chart data (using safeRevenueData)
  // useMemo prevents recalculation on every render unless dependencies change
  const monthlyRevenueChartData = React.useMemo(() => {
    const monthlyData = safeRevenueData.monthlyRevenue || [];
    if (monthlyData.length === 0) {
      return { labels: [], datasets: [] }; // Return empty structure for ChartJS
    }

    // Sort data by month just in case API doesn't guarantee order
    const sortedMonthlyData = [...monthlyData].sort((a, b) =>
      a.month.localeCompare(b.month)
    );

    const labels = sortedMonthlyData.map((item) => formatMonth(item.month));
    const data = sortedMonthlyData.map((item) => item.amount);

    return {
      labels,
      datasets: [
        {
          label: "Monthly Revenue",
          data,
          fill: true,
          backgroundColor: "rgba(75, 192, 192, 0.2)",
          borderColor: "rgba(75, 192, 192, 1)",
          tension: 0.4, // Smoother curve
        },
      ],
    };
  }, [safeRevenueData.monthlyRevenue]); // formatMonth is stable, no need to include

  // useMemo prevents recalculation on every render unless dependencies change
  const agencyRevenueChartData = React.useMemo(() => {
    const topAgenciesData = safeRevenueData.topAgencies?.slice(0, 5) || []; // Take top 5
    if (topAgenciesData.length === 0) {
      return { labels: [], datasets: [] };
    }

    const labels = topAgenciesData.map((item) => item.agencyName);
    const data = topAgenciesData.map((item) => item.totalRevenue);
    const backgroundColors = [
      "rgba(255, 99, 132, 0.7)", // Red
      "rgba(54, 162, 235, 0.7)", // Blue
      "rgba(255, 206, 86, 0.7)", // Yellow
      "rgba(75, 192, 192, 0.7)", // Teal
      "rgba(153, 102, 255, 0.7)", // Purple
    ];
    const borderColors = [
      "rgba(255, 99, 132, 1)",
      "rgba(54, 162, 235, 1)",
      "rgba(255, 206, 86, 1)",
      "rgba(75, 192, 192, 1)",
      "rgba(153, 102, 255, 1)",
    ];

    return {
      labels,
      datasets: [
        {
          label: "Revenue by Agency",
          data,
          // Use consistent colors up to the number of agencies shown
          backgroundColor: backgroundColors.slice(0, data.length),
          borderColor: borderColors.slice(0, data.length),
          borderWidth: 1,
        },
      ],
    };
  }, [safeRevenueData.topAgencies]);

  // useMemo prevents recalculation on every render unless dependencies change
  const agencyDistributionChartData = React.useMemo(() => {
    const allAgencies = safeRevenueData.agencyRevenues || [];
    if (allAgencies.length === 0) {
      return { labels: [], datasets: [] };
    }

    // Group agencies by revenue ranges
    const revenueRanges = {
      "Under PKR 10,000": 0,
      "PKR 10,000 - 49,999": 0, // Adjusted upper bound for clarity
      "PKR 50,000 - 99,999": 0, // Adjusted upper bound
      "PKR 100,000 - 499,999": 0, // Adjusted upper bound
      "PKR 500,000+": 0, // Simplified label
    };

    allAgencies.forEach((agency) => {
      const revenue = agency.totalRevenue;
      if (revenue < 10000) revenueRanges["Under PKR 10,000"]++;
      else if (revenue < 50000) revenueRanges["PKR 10,000 - 49,999"]++;
      else if (revenue < 100000) revenueRanges["PKR 50,000 - 99,999"]++;
      else if (revenue < 500000) revenueRanges["PKR 100,000 - 499,999"]++;
      else revenueRanges["PKR 500,000+"]++;
    });

    // Filter out ranges with 0 agencies for a cleaner pie chart
    const labels = Object.keys(revenueRanges).filter(
      (key) => revenueRanges[key as keyof typeof revenueRanges] > 0
    );
    const data = labels.map(
      (label) => revenueRanges[label as keyof typeof revenueRanges]
    );

    // Define enough colors for potential categories
    const backgroundColors = [
      "rgba(255, 99, 132, 0.7)", // Red
      "rgba(54, 162, 235, 0.7)", // Blue
      "rgba(255, 206, 86, 0.7)", // Yellow
      "rgba(75, 192, 192, 0.7)", // Teal
      "rgba(153, 102, 255, 0.7)", // Purple
      "rgba(255, 159, 64, 0.7)", // Orange
    ];
    const borderColors = [
      "rgba(255, 99, 132, 1)",
      "rgba(54, 162, 235, 1)",
      "rgba(255, 206, 86, 1)",
      "rgba(75, 192, 192, 1)",
      "rgba(153, 102, 255, 1)",
      "rgba(255, 159, 64, 1)",
    ];

    if (labels.length === 0) {
      return { labels: [], datasets: [] }; // Handle case where filtering removes all labels
    }

    return {
      labels,
      datasets: [
        {
          label: "Agency Revenue Distribution",
          data,
          backgroundColor: backgroundColors.slice(0, data.length),
          borderColor: borderColors.slice(0, data.length),
          borderWidth: 1,
        },
      ],
    };
  }, [safeRevenueData.agencyRevenues]);

  // Handle agency selection for modal
  const handleAgencySelect = (agency: AgencyRevenue) => {
    setSelectedAgency(agency);
    setShowAgencyDetails(true);
  };

  // Export agency data as CSV
  const exportToCSV = () => {
    // Use sortedAgencies to export what the user currently sees filtered and sorted
    if (!sortedAgencies || sortedAgencies.length === 0) {
      alert("No data available to export.");
      return;
    }

    const headers = [
      "Agency Name",
      "Email",
      "Total Revenue (PKR)",
      "Bookings Count",
      "Customers Count",
      "Billboards Count", // Include if available and relevant
    ];
    // Map data, ensuring numbers are formatted as plain numbers for CSV compatibility
    const rows = sortedAgencies.map((agency) => [
      `"${agency.agencyName.replace(/"/g, '""')}"`, // Escape quotes in name
      agency.agencyEmail,
      agency.totalRevenue, // Keep as number
      agency.bookingsCount,
      agency.customersCount,
      agency.billboardsCount ?? 0, // Handle potential undefined billboardsCount
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map((row) => row.join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    const fileName = `admin_revenue_report_${dateRange.startDate}_to_${dateRange.endDate}.csv`;
    link.setAttribute("download", fileName);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url); // Clean up blob URL
  };

  // Render Loading State
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
        {" "}
        {/* Adjust min-height as needed */}
        <FaSpinner className="animate-spin text-indigo-600 text-4xl mr-3" />
        <p className="text-gray-600 text-lg">Loading revenue data...</p>
      </div>
    );
  }

  // Render Error State (after loading is false)
  // Show error prominently if loading is finished and error exists
  if (error) {
    return (
      <>
        <Breadcrumb pageName="Admin Revenue Dashboard" />
        <div className="flex flex-col items-center justify-center bg-red-50 border border-red-200 rounded-lg p-6 mt-6 text-center">
          <FaExclamationTriangle className="text-red-500 text-4xl mb-3" />
          <p className="text-red-700 font-semibold text-lg mb-2">
            Error Loading Data
          </p>
          <p className="text-red-600">{error}</p>
          <button
            onClick={fetchRevenueData} // Allow retry
            className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors text-sm"
          >
            Retry
          </button>
        </div>
      </>
    );
  }

  // Render Unauthorized State (this should ideally be caught earlier, but good as a fallback)
  if (!isAdmin && !loading) {
    // Check !loading to avoid brief flash before redirect/error
    return (
      <>
        <Breadcrumb pageName="Access Denied" />
        <div className="flex flex-col items-center justify-center bg-yellow-50 border border-yellow-200 rounded-lg p-6 mt-6 text-center">
          <FaExclamationTriangle className="text-yellow-500 text-4xl mb-3" />
          <p className="text-yellow-700 font-semibold text-lg mb-2">
            Access Denied
          </p>
          <p className="text-yellow-600">
            You do not have permission to view this page.
          </p>
          {/* Optionally add a link to redirect non-admins */}
          {/* <Link to="/dashboard" className="mt-4 text-indigo-600 hover:underline">Go to your dashboard</Link> */}
        </div>
      </>
    );
  }

  // Main component render (only if loading is false, error is null, and isAdmin is true)
  return (
    <>
      <Breadcrumb pageName="Admin Revenue Dashboard" />

      {/* Main Dashboard */}
      <div className="flex flex-col gap-6">
        {" "}
        {/* Use flex-col for consistent spacing */}
        {/* Header with filters */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
                Platform Revenue Overview
              </h1>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Analyze revenue across all agencies for the selected period.
              </p>
            </div>

            {/* Date Range and Filter Button */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <div className="flex items-center gap-2">
                <label
                  htmlFor="startDate"
                  className="text-sm text-gray-600 dark:text-gray-400 flex-shrink-0"
                >
                  From:
                </label>
                <input
                  type="date"
                  id="startDate"
                  value={dateRange.startDate}
                  onChange={(e) =>
                    setDateRange((prev) => ({
                      ...prev,
                      startDate: e.target.value,
                    }))
                  }
                  // Set reasonable date range
                  min={
                    new Date(
                      new Date().setFullYear(new Date().getFullYear() - 1)
                    )
                      .toISOString()
                      .split("T")[0]
                  }
                  max={dateRange.endDate}
                  className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-form-input dark:border-strokedark dark:text-white"
                />
              </div>

              <div className="flex items-center gap-2">
                <label
                  htmlFor="endDate"
                  className="text-sm text-gray-600 dark:text-gray-400 flex-shrink-0"
                >
                  To:
                </label>
                <input
                  type="date"
                  id="endDate"
                  value={dateRange.endDate}
                  onChange={(e) =>
                    setDateRange((prev) => ({
                      ...prev,
                      endDate: e.target.value,
                    }))
                  }
                  // Ensure date range is valid
                  min={
                    // Use the later of startDate or 1 year ago
                    new Date(
                      Math.max(
                        new Date(dateRange.startDate).getTime(),
                        new Date(
                          new Date().setFullYear(new Date().getFullYear() - 1)
                        ).getTime()
                      )
                    )
                      .toISOString()
                      .split("T")[0]
                  }
                  // Prevent selecting future dates
                  max={new Date().toISOString().split("T")[0]}
                  className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-form-input dark:border-strokedark dark:text-white"
                />
              </div>

              <button
                onClick={fetchRevenueData}
                disabled={loading} // Disable button while loading
                className={`bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                {loading ? (
                  <FaSpinner className="animate-spin" />
                ) : (
                  <FaFilter />
                )}
                Apply Filter
              </button>
            </div>
          </div>
        </div>
        {/* Summary Cards - Using safeRevenueData */}
        <div className="grid gap-6 grid-cols-[repeat(auto-fit,minmax(250px,1fr))]">
          {/* Total Revenue Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500 dark:bg-boxdark dark:border-green-400">
            <div className="flex items-start justify-between">
              <div className="min-w-0">
                <p className="text-sm text-gray-600 font-medium dark:text-gray-400">
                  Total Platform Revenue
                </p>
                <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all dark:text-white">
                  {formatCurrency(safeRevenueData.totalRevenue)}
                </h3>
                <p className="text-xs text-gray-500 mt-1 dark:text-gray-500">
                  Period: {formatDate(dateRange.startDate)} -{" "}
                  {formatDate(dateRange.endDate)}
                </p>
              </div>
              <div className="p-3 bg-green-100 rounded-full dark:bg-green-900/30">
                <FaMoneyBillWave className="text-green-600 dark:text-green-400 text-xl" />
              </div>
            </div>
          </div>

          {/* Total Bookings Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500 dark:bg-boxdark dark:border-blue-400">
            <div className="flex items-start justify-between">
              <div className="min-w-0">
                <p className="text-sm text-gray-600 font-medium dark:text-gray-400">
                  Total Bookings
                </p>
                <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all dark:text-white">
                  {safeRevenueData.totalBookings.toLocaleString()}
                </h3>
                <p className="text-xs text-gray-500 mt-1 dark:text-gray-500">
                  Across all agencies
                </p>
              </div>
              <div className="p-3 bg-blue-100 rounded-full dark:bg-blue-900/30">
                <FaCalendarAlt className="text-blue-600 dark:text-blue-400 text-xl" />
              </div>
            </div>
          </div>

          {/* Total Agencies Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500 dark:bg-boxdark dark:border-purple-400">
            <div className="flex items-start justify-between">
              <div className="min-w-0">
                <p className="text-sm text-gray-600 font-medium dark:text-gray-400">
                  Total Agencies
                </p>
                <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all dark:text-white">
                  {safeRevenueData.totalAgencies.toLocaleString()}
                </h3>
                <p className="text-xs text-gray-500 mt-1 dark:text-gray-500">
                  contributing revenue
                </p>
              </div>
              <div className="p-3 bg-purple-100 rounded-full dark:bg-purple-900/30">
                <FaBuilding className="text-purple-600 dark:text-purple-400 text-xl" />
              </div>
            </div>
          </div>

          {/* Total Customers Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-amber-500 dark:bg-boxdark dark:border-yellow-400">
            <div className="flex items-start justify-between">
              <div className="min-w-0">
                <p className="text-sm text-gray-600 font-medium dark:text-gray-400">
                  Total Customers
                </p>
                <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all dark:text-white">
                  {safeRevenueData.totalCustomers.toLocaleString()}
                </h3>
                <p className="text-xs text-gray-500 mt-1 dark:text-gray-500">
                  involved in bookings
                </p>
              </div>
              <div className="p-3 bg-amber-100 rounded-full dark:bg-yellow-900/30">
                <FaUsers className="text-amber-600 dark:text-yellow-400 text-xl" />
              </div>
            </div>
          </div>

          {/* Average Revenue Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-indigo-500 dark:bg-boxdark dark:border-indigo-400">
            <div className="flex items-start justify-between">
              <div className="min-w-0">
                <p className="text-sm text-gray-600 font-medium dark:text-gray-400">
                  Avg. Revenue / Agency
                </p>
                <h3 className="text-2xl font-bold text-gray-800 mt-1 break-all dark:text-white">
                  {formatCurrency(
                    safeRevenueData.totalAgencies > 0
                      ? safeRevenueData.totalRevenue /
                          safeRevenueData.totalAgencies
                      : 0
                  )}
                </h3>
                <p className="text-xs text-gray-500 mt-1 dark:text-gray-500">
                  during period
                </p>
              </div>
              <div className="p-3 bg-indigo-100 rounded-full dark:bg-indigo-900/30">
                <FaChartLine className="text-indigo-600 dark:text-indigo-400 text-xl" />
              </div>
            </div>
          </div>
        </div>
        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Monthly Revenue Chart */}
          <div className="bg-white rounded-xl shadow-lg p-6 dark:bg-boxdark">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 dark:text-white">
              Platform Monthly Revenue Trend
            </h3>
            {/* Use chartData prepared with useMemo */}
            {monthlyRevenueChartData.labels.length > 0 ? (
              <div className="h-80">
                {" "}
                {/* Fixed height container */}
                <Line
                  data={monthlyRevenueChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: "top",
                        labels: {
                          color: document.documentElement.classList.contains(
                            "dark"
                          )
                            ? "#ccc"
                            : "#333",
                        },
                      },
                      tooltip: {
                        callbacks: {
                          label: (context) =>
                            `Revenue: ${formatCurrency(context.raw as number)}`,
                        },
                      },
                    },
                    scales: {
                      y: {
                        beginAtZero: true,
                        ticks: {
                          callback: (value) => formatCurrency(value as number),
                          color: document.documentElement.classList.contains(
                            "dark"
                          )
                            ? "#ccc"
                            : "#666",
                        },
                        grid: {
                          color: document.documentElement.classList.contains(
                            "dark"
                          )
                            ? "rgba(255, 255, 255, 0.1)"
                            : "rgba(0, 0, 0, 0.1)",
                        },
                      },
                      x: {
                        ticks: {
                          color: document.documentElement.classList.contains(
                            "dark"
                          )
                            ? "#ccc"
                            : "#666",
                        },
                        grid: { display: false },
                      },
                    },
                  }}
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-80 bg-gray-50 rounded-lg dark:bg-boxdark-2">
                <p className="text-gray-500 dark:text-gray-400">
                  No monthly revenue data available for this period.
                </p>
              </div>
            )}
          </div>

          {/* Top Agencies Chart */}
          <div className="bg-white rounded-xl shadow-lg p-6 dark:bg-boxdark">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 dark:text-white">
              Top 5 Performing Agencies by Revenue
            </h3>
            {agencyRevenueChartData.labels.length > 0 ? (
              <div className="h-80">
                <Bar
                  data={agencyRevenueChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    indexAxis: "y", // Horizontal bars might be better for names
                    plugins: {
                      legend: { display: false }, // Already labeled by axis
                      tooltip: {
                        callbacks: {
                          label: (context) =>
                            `Revenue: ${formatCurrency(context.raw as number)}`,
                        },
                      },
                    },
                    scales: {
                      x: {
                        // Now the value axis
                        beginAtZero: true,
                        ticks: {
                          callback: (value) => formatCurrency(value as number),
                          color: document.documentElement.classList.contains(
                            "dark"
                          )
                            ? "#ccc"
                            : "#666",
                        },
                        grid: {
                          color: document.documentElement.classList.contains(
                            "dark"
                          )
                            ? "rgba(255, 255, 255, 0.1)"
                            : "rgba(0, 0, 0, 0.1)",
                        },
                      },
                      y: {
                        // Now the category axis
                        ticks: {
                          color: document.documentElement.classList.contains(
                            "dark"
                          )
                            ? "#ccc"
                            : "#666",
                        },
                        grid: { display: false },
                      },
                    },
                  }}
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-80 bg-gray-50 rounded-lg dark:bg-boxdark-2">
                <p className="text-gray-500 dark:text-gray-400">
                  No agency revenue data available.
                </p>
              </div>
            )}
          </div>

          {/* Agency Distribution Chart */}
          <div className="bg-white rounded-xl shadow-lg p-6 dark:bg-boxdark">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 dark:text-white">
              Agency Revenue Distribution
            </h3>
            {agencyDistributionChartData.labels.length > 0 ? (
              <div className="h-80 flex items-center justify-center">
                {" "}
                {/* Center pie chart */}
                <Pie
                  data={agencyDistributionChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false, // Allow resizing within container
                    plugins: {
                      legend: {
                        position: "right", // Or 'bottom' if space is limited
                        labels: {
                          color: document.documentElement.classList.contains(
                            "dark"
                          )
                            ? "#ccc"
                            : "#333",
                          // Use point style for better legend visuals
                          usePointStyle: true,
                          boxWidth: 10, // Adjust box size
                        },
                      },
                      tooltip: {
                        callbacks: {
                          label: (context) => {
                            const label = context.label || "";
                            const value = context.raw as number;
                            const total = (safeRevenueData.agencyRevenues || [])
                              .length;
                            const percentage =
                              total > 0
                                ? ((value / total) * 100).toFixed(1)
                                : 0;
                            return `${label}: ${value} agencies (${percentage}%)`;
                          },
                        },
                      },
                    },
                  }}
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-80 bg-gray-50 rounded-lg dark:bg-boxdark-2">
                <p className="text-gray-500 dark:text-gray-400">
                  No agency distribution data available.
                </p>
              </div>
            )}
          </div>

          {/* Revenue Breakdown Table (Simplified Example) */}
          <div className="bg-white rounded-xl shadow-lg p-6 dark:bg-boxdark">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 dark:text-white">
              Revenue Insights
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded dark:bg-boxdark-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Total Platform Revenue:
                </span>
                <span className="text-sm font-semibold text-gray-900 dark:text-white">
                  {formatCurrency(safeRevenueData.totalRevenue)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded dark:bg-boxdark-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Top Agency Revenue:
                </span>
                <span className="text-sm font-semibold text-gray-900 dark:text-white">
                  {formatCurrency(
                    safeRevenueData.topAgencies[0]?.totalRevenue ?? 0
                  )}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded dark:bg-boxdark-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Contribution by Top Agency:
                </span>
                <span className="text-sm font-semibold text-gray-900 dark:text-white">
                  {safeRevenueData.totalRevenue > 0 &&
                  safeRevenueData.topAgencies.length > 0
                    ? `${((safeRevenueData.topAgencies[0].totalRevenue / safeRevenueData.totalRevenue) * 100).toFixed(1)}%`
                    : "N/A"}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded dark:bg-boxdark-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Avg. Revenue per Agency:
                </span>
                <span className="text-sm font-semibold text-gray-900 dark:text-white">
                  {formatCurrency(
                    safeRevenueData.totalAgencies > 0
                      ? safeRevenueData.totalRevenue /
                          safeRevenueData.totalAgencies
                      : 0
                  )}
                </span>
              </div>
            </div>
          </div>
        </div>
        {/* Agency Revenue Table */}
        <div className="bg-white rounded-xl shadow-lg p-6 dark:bg-boxdark">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
              Agency Revenue Details
            </h3>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              {/* Search Input */}
              <div className="relative flex-grow">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                  <FaSearch />
                </span>
                <input
                  type="text"
                  placeholder="Search agencies by name or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-form-input dark:border-strokedark dark:text-white dark:focus:border-primary"
                />
              </div>
              {/* Export Button */}
              <button
                onClick={exportToCSV}
                disabled={sortedAgencies.length === 0} // Disable if no data
                className={`bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center justify-center gap-2 ${sortedAgencies.length === 0 ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                <FaDownload />
                Export CSV
              </button>
            </div>
          </div>

          {/* Table Container */}
          {sortedAgencies.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-strokedark">
                <thead className="bg-gray-50 dark:bg-meta-4">
                  <tr>
                    {/* Agency Name */}
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-meta-9"
                      onClick={() => toggleSort("agencyName")}
                    >
                      Agency
                      {sortField === "agencyName" && (
                        <span className="ml-1">
                          {sortDirection === "asc" ? (
                            <FaSortAmountUp className="inline" />
                          ) : (
                            <FaSortAmountDown className="inline" />
                          )}
                        </span>
                      )}
                    </th>
                    {/* Email */}
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Email
                    </th>
                    {/* Total Revenue */}
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-meta-9"
                      onClick={() => toggleSort("totalRevenue")}
                    >
                      Total Revenue
                      {sortField === "totalRevenue" && (
                        <span className="ml-1">
                          {sortDirection === "asc" ? (
                            <FaSortAmountUp className="inline" />
                          ) : (
                            <FaSortAmountDown className="inline" />
                          )}
                        </span>
                      )}
                    </th>
                    {/* Bookings Count */}
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-meta-9"
                      onClick={() => toggleSort("bookingsCount")}
                    >
                      Bookings
                      {sortField === "bookingsCount" && (
                        <span className="ml-1">
                          {sortDirection === "asc" ? (
                            <FaSortAmountUp className="inline" />
                          ) : (
                            <FaSortAmountDown className="inline" />
                          )}
                        </span>
                      )}
                    </th>
                    {/* Customers Count */}
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-meta-9"
                      onClick={() => toggleSort("customersCount")}
                    >
                      Customers
                      {sortField === "customersCount" && (
                        <span className="ml-1">
                          {sortDirection === "asc" ? (
                            <FaSortAmountUp className="inline" />
                          ) : (
                            <FaSortAmountDown className="inline" />
                          )}
                        </span>
                      )}
                    </th>
                    {/* Actions */}
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200 dark:bg-boxdark dark:divide-strokedark">
                  {sortedAgencies.map((agency) => (
                    <tr
                      key={agency.agencyId}
                      className="hover:bg-gray-50 dark:hover:bg-meta-4 transition-colors duration-150"
                    >
                      {/* Agency Name */}
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center">
                            <FaBuilding className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900 dark:text-white">
                              {agency.agencyName}
                            </div>
                          </div>
                        </div>
                      </td>
                      {/* Email */}
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                        {agency.agencyEmail}
                      </td>
                      {/* Total Revenue */}
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                          {formatCurrency(agency.totalRevenue)}
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-500">
                          {safeRevenueData.totalRevenue > 0
                            ? `${((agency.totalRevenue / safeRevenueData.totalRevenue) * 100).toFixed(1)}% of total`
                            : "N/A"}
                        </div>
                      </td>
                      {/* Bookings Count */}
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 text-center">
                        {agency.bookingsCount.toLocaleString()}
                      </td>
                      {/* Customers Count */}
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 text-center">
                        {agency.customersCount.toLocaleString()}
                      </td>
                      {/* Actions */}
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => handleAgencySelect(agency)}
                          className="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 transition-colors"
                          aria-label={`View details for ${agency.agencyName}`}
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            // Message when no agencies match search or filter
            <div className="flex flex-col items-center justify-center h-40 bg-gray-50 rounded-lg dark:bg-boxdark-2 text-center p-4">
              <FaSearch className="text-gray-400 text-3xl mb-2" />
              <p className="text-gray-500 dark:text-gray-400">
                {safeRevenueData.agencyRevenues.length === 0
                  ? "No agency revenue data available for the selected period."
                  : "No agencies match your search criteria."}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Agency Details Modal */}
      {showAgencyDetails && selectedAgency && (
        // Modal backdrop
        <div
          className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 transition-opacity duration-300"
          onClick={() => setShowAgencyDetails(false)} // Close on backdrop click
          aria-labelledby="agency-details-title"
          role="dialog"
          aria-modal="true"
        >
          {/* Modal content */}
          <div
            className="bg-white dark:bg-boxdark rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col transform transition-all duration-300 scale-95 opacity-0 animate-modal-enter"
            onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside modal
          >
            {/* Modal Header */}
            <div className="p-5 border-b border-gray-200 dark:border-strokedark flex justify-between items-center">
              <div>
                <h3
                  id="agency-details-title"
                  className="text-xl font-bold text-gray-800 dark:text-white"
                >
                  Agency Details
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {selectedAgency.agencyName} ({selectedAgency.agencyEmail})
                </p>
              </div>
              <button
                onClick={() => setShowAgencyDetails(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 focus:outline-none rounded-full p-1 hover:bg-gray-100 dark:hover:bg-gray-700"
                aria-label="Close modal"
              >
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 flex-1 overflow-y-auto">
              {" "}
              {/* Enable vertical scroll */}
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="bg-indigo-50 dark:bg-indigo-900/30 p-4 rounded-lg">
                  <h4 className="text-sm font-semibold text-indigo-800 dark:text-indigo-300 mb-2 uppercase tracking-wider">
                    Revenue
                  </h4>
                  <div className="space-y-1">
                    <p className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">
                        Total:
                      </span>
                      <span className="font-semibold text-gray-800 dark:text-white">
                        {formatCurrency(selectedAgency.totalRevenue)}
                      </span>
                    </p>
                    <p className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">
                        Platform Share:
                      </span>
                      <span className="font-semibold text-gray-800 dark:text-white">
                        {safeRevenueData.totalRevenue > 0
                          ? `${((selectedAgency.totalRevenue / safeRevenueData.totalRevenue) * 100).toFixed(1)}%`
                          : "N/A"}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
                  <h4 className="text-sm font-semibold text-blue-800 dark:text-blue-300 mb-2 uppercase tracking-wider">
                    Bookings
                  </h4>
                  <div className="space-y-1">
                    <p className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">
                        Total Count:
                      </span>
                      <span className="font-semibold text-gray-800 dark:text-white">
                        {selectedAgency.bookingsCount.toLocaleString()}
                      </span>
                    </p>
                    <p className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">
                        Avg. Value:
                      </span>
                      <span className="font-semibold text-gray-800 dark:text-white">
                        {formatCurrency(
                          selectedAgency.bookingsCount > 0
                            ? selectedAgency.totalRevenue /
                                selectedAgency.bookingsCount
                            : 0
                        )}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="bg-green-50 dark:bg-green-900/30 p-4 rounded-lg">
                  <h4 className="text-sm font-semibold text-green-800 dark:text-green-300 mb-2 uppercase tracking-wider">
                    Engagement
                  </h4>
                  <div className="space-y-1">
                    <p className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">
                        Customers:
                      </span>
                      <span className="font-semibold text-gray-800 dark:text-white">
                        {selectedAgency.customersCount.toLocaleString()}
                      </span>
                    </p>
                    <p className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">
                        Billboards:
                      </span>
                      <span className="font-semibold text-gray-800 dark:text-white">
                        {selectedAgency.billboardsCount?.toLocaleString() ??
                          "N/A"}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
              {/* Monthly Revenue Chart for Agency */}
              <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">
                Monthly Revenue Trend (Agency)
              </h4>
              {selectedAgency.monthlyRevenue &&
              selectedAgency.monthlyRevenue.length > 0 ? (
                <div className="h-64">
                  {" "}
                  {/* Fixed height for chart */}
                  <Line
                    data={{
                      // Ensure months are sorted for the chart
                      labels: [...selectedAgency.monthlyRevenue]
                        .sort((a, b) => a.month.localeCompare(b.month))
                        .map((item) => formatMonth(item.month)),
                      datasets: [
                        {
                          label: "Monthly Revenue",
                          data: [...selectedAgency.monthlyRevenue]
                            .sort((a, b) => a.month.localeCompare(b.month))
                            .map((item) => item.amount),
                          fill: true,
                          backgroundColor: "rgba(75, 192, 192, 0.2)",
                          borderColor: "rgba(75, 192, 192, 1)",
                          tension: 0.4,
                        },
                      ],
                    }}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: { display: false },
                        tooltip: {
                          callbacks: {
                            label: (context) =>
                              `Revenue: ${formatCurrency(context.raw as number)}`,
                          },
                        },
                      },
                      scales: {
                        y: {
                          beginAtZero: true,
                          ticks: {
                            callback: (value) =>
                              formatCurrency(value as number),
                            color: document.documentElement.classList.contains(
                              "dark"
                            )
                              ? "#ccc"
                              : "#666",
                          },
                          grid: {
                            color: document.documentElement.classList.contains(
                              "dark"
                            )
                              ? "rgba(255, 255, 255, 0.1)"
                              : "rgba(0, 0, 0, 0.1)",
                          },
                        },
                        x: {
                          ticks: {
                            color: document.documentElement.classList.contains(
                              "dark"
                            )
                              ? "#ccc"
                              : "#666",
                          },
                          grid: { display: false },
                        },
                      },
                    }}
                  />
                </div>
              ) : (
                <div className="flex items-center justify-center h-40 bg-gray-50 rounded-lg dark:bg-boxdark-2">
                  <p className="text-gray-500 dark:text-gray-400">
                    No monthly revenue data available for this agency in the
                    selected period.
                  </p>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-gray-200 dark:border-strokedark flex justify-end bg-gray-50 dark:bg-boxdark-2">
              <button
                onClick={() => setShowAgencyDetails(false)}
                className="bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 px-5 py-2 rounded-md hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors text-sm font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AdminRevenuePage;
