// frontend/components/billboard/BillboardsTable.tsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../../axiosInstance";
import { toast } from "react-hot-toast";
import { Billboard, BillboardFormData } from "./types";
import { useBillboardTable } from "./useBillboardTable";
import BillboardForm from "./BillboardForm";
import { useAuthStore } from "../../../stores/authStore";
// Import icons for actions (optional, but nice for dashboards)
import {
  FaEdit,
  FaTrashAlt,
  FaPlus,
  FaImage,
  FaMapMarkerAlt,
} from "react-icons/fa";
import Breadcrumb from "../../components/Breadcrumbs/Breadcrumb"; // Assuming you have this

const BillboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, token } = useAuthStore();
  const {
    billboards,
    loading,
    error,
    currentPage,
    totalPages,
    handleDelete,
    handlePageChange,
    refreshData,
    // Add a setter for billboards if useBillboardTable doesn't directly expose it after edit/delete updates
    // Or ensure refreshData updates the list correctly after edits/deletes
  } = useBillboardTable();

  const [showForm, setShowForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [billboardData, setBillboardData] = useState<BillboardFormData>({
    title: "",
    description: "",
    status: "active",
    location: "",
    city: "",
    area: "",
    price: "",
    contact: "",
    size: "",
    imageUrl: "",
    id: "",
  });

  // Check if user is authenticated and is an agency
  React.useEffect(() => {
    if (!user || user.role !== "agency") {
      toast.error("Access denied. Only agencies can access this page.");
      navigate("/login"); // Redirect to login or an appropriate page
    }
  }, [user, navigate]);

  // Helper to format price (optional)
  const formatPrice = (price: string | number) => {
    const num = Number(price);
    return isNaN(num) ? price : `PKR ${num.toLocaleString()}`;
  };

  // Helper for status badge styling
  const getStatusBadgeClass = (status: string) => {
    switch (status?.toLowerCase()) {
      case "active":
        return "bg-green-100 text-green-800";
      case "inactive":
        return "bg-red-100 text-red-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleBillboardSubmit = async (formData: BillboardFormData) => {
    try {
      setSubmitting(true);
      if (!token || !user) {
        toast.error("Authentication required. Please log in.");
        setSubmitting(false);
        return;
      }

      // Check if the user is an agency
      if (user.role !== 'agency') {
        toast.error("Only agencies can create billboards.");
        setSubmitting(false);
        return;
      }

      // Log the token for debugging (only first few characters)
      console.log("Using token:", token.substring(0, 10) + "...");

      // Verify token is in localStorage
      const localToken = localStorage.getItem('token');
      if (!localToken) {
        toast.error("Authentication token not found. Please log in again.");
        setSubmitting(false);
        return;
      }

      // Validate price is a valid number before submitting
      const priceValue = Number(formData.price);
      if (isNaN(priceValue)) {
        toast.error("Price must be a valid number");
        setSubmitting(false);
        return;
      }

      const submitData = {
        title: formData.title.trim(),
        description: formData.description.trim(),
        // Ensure status is handled correctly based on your API logic
        status: formData.status || "active",
        location: formData.location.trim(),
        city: formData.city.trim(),
        area: formData.area.trim(),
        price: priceValue, // Use the validated number
        contact: formData.contact.trim(),
        size: formData.size.trim(),
        imageUrl: formData.imageUrl.trim(),
        // Don't include agencyId in the request body, it will be set by the server
      };

      let response;
      if (isEditing && formData.id) {
        // Use axiosInstance which already has the authentication interceptor
        response = await axiosInstance.put(
          `/api/billboard/update/${formData.id}`,
          submitData
        );
        toast.success("Billboard updated successfully");
        // Refresh data to show changes in the table
        refreshData();
      } else {
        // Log the data being sent for debugging
        console.log("Submitting billboard data:", JSON.stringify(submitData, null, 2));

        try {
          // Use axiosInstance which already has the authentication interceptor
          response = await axiosInstance.post("/api/billboard/create", submitData);

          // Log successful response
          console.log("Billboard creation response:", response.data);
        } catch (err: any) {
          // Log detailed error information
          console.error("Billboard creation error details:", {
            status: err.response?.status,
            statusText: err.response?.statusText,
            data: err.response?.data,
            headers: err.response?.headers,
          });

          // Log the full error response for debugging
          console.error("Full error response:", JSON.stringify(err.response?.data, null, 2));
          throw err; // Re-throw to be caught by the outer catch block
        }
        if (response.data.status === 1 && response.data.data) {
          // Add locally or refresh? Refreshing might be safer if pagination/sorting is complex
          // addBillboardToList(response.data.data); // Keep if your hook handles this well
          refreshData(); // Refresh to ensure list consistency
          toast.success("Billboard added successfully");
        } else {
          throw new Error(response.data.message || "Failed to add billboard");
        }
      }

      setShowForm(false);
      setIsEditing(false);
      // Reset form state only after successful submission handled
      setBillboardData({
        title: "",
        description: "",
        status: "active",
        location: "",
        city: "",
        area: "",
        price: "",
        contact: "",
        size: "",
        id: "",
        imageUrl: "",
      });
    } catch (error: any) {
      console.error("Error submitting billboard:", error);

      // Handle different error formats
      if (error.response?.data?.errors && Array.isArray(error.response.data.errors)) {
        // If we have an array of validation errors from Joi validation
        toast.error(`Validation errors: ${error.response.data.errors.join(", ")}`);
      } else if (error.response?.data?.errors && typeof error.response.data.errors === 'object') {
        // If we have mongoose validation errors
        const errorMessages = Object.values(error.response.data.errors)
          .map((err: any) => err.message || err)
          .join(", ");
        toast.error(`Validation errors: ${errorMessages}`);
      } else if (error.response?.data?.message) {
        // If we have a specific error message from the server
        toast.error(`Submission failed: ${error.response.data.message}`);
      } else {
        // Generic error message
        toast.error("Failed to submit billboard. Please try again.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (billboard: Billboard) => {
    setBillboardData({
      title: billboard.title,
      description: billboard.description || "",
      status: billboard.status || "active", // Default if status is missing
      location: billboard.location,
      city: billboard.city || "",
      area: billboard.area || "",
      price: String(billboard.price), // Convert number to string for form input
      contact: billboard.contact || "",
      size: billboard.size || "",
      id: billboard._id,
      imageUrl: billboard.imageUrl || "",
    });
    setIsEditing(true);
    setShowForm(true);
  };

  const handleDeleteConfirm = (id: string) => {
    // Optional: Add a confirmation dialog here
    // e.g., using window.confirm or a modal library
    if (window.confirm("Are you sure you want to delete this billboard?")) {
      handleDelete(id)
        .then(() => {
          toast.success("Billboard deleted successfully");
          // Refresh or rely on handleDelete hook to update the list
          // refreshData(currentPage); // Uncomment if handleDelete doesn't refresh
        })
        .catch((err) => {
          toast.error("Failed to delete billboard.");
          console.error("Delete error:", err);
        });
    }
  };

  // --- Render Logic ---

  if (loading && !billboards.length) {
    // Show loader only on initial load
    return (
      <>
        <Breadcrumb pageName="Manage Billboards" />
        <div className="flex items-center justify-center pt-10">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          <span className="ml-3 text-gray-600">Loading billboards...</span>
        </div>
      </>
    );
  }

  if (error) {
    return (
      <>
        <Breadcrumb pageName="Manage Billboards" />
        <div className="bg-white p-6 rounded-lg shadow-md border border-red-200 text-center">
          <p className="text-red-600 font-semibold mb-3">
            Error loading billboards:
          </p>
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={() => refreshData()}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
          >
            Try Again
          </button>
        </div>
      </>
    );
  }

  return (
    <>
      <Breadcrumb pageName="Manage Billboards" />

      <div className="bg-white p-6 rounded-xl shadow-lg mb-6">
        <div className="flex flex-col sm:flex-row justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4 sm:mb-0">
            My Billboards ({billboards.length}) {/* Optional: show count */}
          </h2>
          <button
            onClick={() => {
              setShowForm(true);
              setIsEditing(false);
              setBillboardData({
                title: "",
                description: "",
                status: "active",
                location: "",
                city: "",
                area: "",
                price: "",
                contact: "",
                size: "",
                id: "",
                imageUrl: "",
              });
            }}
            className="flex items-center px-5 py-2.5 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition text-sm font-medium shadow-sm"
            disabled={submitting} // Disable while form is submitting
          >
            <FaPlus className="mr-2" size={14} />
            Add New Billboard
          </button>
        </div>
      </div>

      {/* Billboards Table */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Image
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Title
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Location
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  City
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Price
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Status
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {billboards.length === 0 ? (
                <tr>
                  <td
                    colSpan={7}
                    className="px-6 py-10 text-center text-gray-500"
                  >
                    <div className="mb-2">
                      <svg
                        className="mx-auto h-10 w-10 text-gray-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                        />
                      </svg>
                    </div>
                    You haven't created any billboards yet. Click 'Add New
                    Billboard' to start.
                  </td>
                </tr>
              ) : (
                billboards.map((billboard) => (
                  <tr
                    key={billboard._id}
                    className="hover:bg-gray-50 transition-colors duration-150"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex-shrink-0 h-10 w-16 bg-gray-100 rounded flex items-center justify-center">
                        {billboard.imageUrl ? (
                          <img
                            className="h-10 w-16 object-cover rounded"
                            src={billboard.imageUrl}
                            alt={billboard.title}
                          />
                        ) : (
                          <FaImage className="h-5 w-5 text-gray-400" /> // Placeholder icon
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {billboard.title}
                      </div>
                      {/* Optional: Add description snippet or make title clickable to view details */}
                      {/* <div className="text-xs text-gray-500 truncate w-40">{billboard.description}</div> */}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center">
                        <FaMapMarkerAlt
                          className="mr-1.5 text-gray-400"
                          size={12}
                        />
                        {billboard.location}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {billboard.city || "N/A"}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-800">
                      {formatPrice(billboard.price)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span
                        className={`px-2.5 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(billboard.status)}`}
                      >
                        {billboard.status || "Unknown"}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleEdit(billboard)}
                        className="text-indigo-600 hover:text-indigo-900 mr-3 transition duration-150 ease-in-out"
                        aria-label={`Edit ${billboard.title}`}
                      >
                        <FaEdit size={16} />
                      </button>
                      <button
                        onClick={() => handleDeleteConfirm(billboard._id)}
                        className="text-red-600 hover:text-red-800 transition duration-150 ease-in-out"
                        aria-label={`Delete ${billboard.title}`}
                      >
                        <FaTrashAlt size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {loading &&
              billboards.length > 0 && ( // Show loading indicator at bottom during refresh
                <tfoot>
                  <tr>
                    <td
                      colSpan={7}
                      className="px-6 py-3 text-center text-sm text-gray-500"
                    >
                      <div className="inline-flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-blue-500 mr-2"></div>
                        Refreshing data...
                      </div>
                    </td>
                  </tr>
                </tfoot>
              )}
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="bg-white px-4 py-3 flex items-center justify-center border-t border-gray-200 sm:px-6 mt-6 rounded-b-xl shadow-lg">
          <nav
            className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px"
            aria-label="Pagination"
          >
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <button
                key={page}
                onClick={() => handlePageChange(page)}
                aria-current={currentPage === page ? "page" : undefined}
                className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                  currentPage === page
                    ? "z-10 bg-indigo-50 border-indigo-500 text-indigo-600"
                    : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50"
                } ${page === 1 ? "rounded-l-md" : ""} ${page === totalPages ? "rounded-r-md" : ""}`}
              >
                {page}
              </button>
            ))}
          </nav>
        </div>
      )}

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-99999 p-4 transition-opacity duration-300 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto transform transition-all duration-300 my-8">
            {/* Modal header with improved styling */}
            <div className="sticky top-0 z-99999 bg-white p-5 border-b border-gray-200 flex justify-between items-center shadow-sm">
              <h3 className="text-lg font-semibold leading-6 text-gray-900">
                {isEditing ? "Edit Billboard" : "Add New Billboard"}
              </h3>
              <button
                onClick={() => {
                  setShowForm(false);
                  setIsEditing(false);
                }}
                className="text-gray-500 hover:text-gray-700 focus:outline-none p-1.5 rounded-full hover:bg-gray-100 transition-colors"
                aria-label="Close modal"
              >
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
            {/* Form Content - removed mt-24 margin */}
            <div className="p-4 sm:p-6">
              <BillboardForm
                initialData={billboardData}
                isEditing={isEditing}
                onSubmit={handleBillboardSubmit}
                onCancel={() => {
                  setShowForm(false);
                  setIsEditing(false);
                }}
                submitting={submitting}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BillboardPage;
