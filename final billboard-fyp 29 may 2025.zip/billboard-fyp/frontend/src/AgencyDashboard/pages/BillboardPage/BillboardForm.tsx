// frontend/components/billboard/BillboardForm.tsx
import React, { useState } from "react";
import { BillboardFormData } from "./types";
import { toast } from "react-hot-toast";
import {
  FaImage,
  FaMapMarkerAlt,
  FaDollarSign,
  FaRulerCombined,
  FaPhone,
  FaCity,
  FaMapPin,
  FaCheckCircle,
  FaTimesCircle,
  FaInfoCircle,
  FaHeading,
} from "react-icons/fa"; // Optional: Add icons for better visual cues

interface BillboardFormProps {
  initialData: BillboardFormData;
  isEditing: boolean;
  onSubmit: (data: BillboardFormData) => void;
  onCancel: () => void;
  submitting: boolean;
}

const BillboardForm: React.FC<BillboardFormProps> = ({
  initialData,
  isEditing,
  onSubmit,
  onCancel,
  submitting,
}) => {
  const [formData, setFormData] = useState<BillboardFormData>({
    title: initialData.title || "",
    description: initialData.description || "",
    status: initialData.status || "active",
    location: initialData.location || "",
    city: initialData.city || "",
    area: initialData.area || "",
    price: initialData.price || "",
    contact: initialData.contact || "",
    size: initialData.size || "",
    imageUrl: initialData.imageUrl || "",
    id: initialData.id || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // --- Validation Logic (Unchanged) ---
    const requiredFields: (keyof Omit<BillboardFormData, "id" | "status">)[] = [
      "title",
      "description",
      "location",
      "city",
      "area",
      "price",
      "contact",
      "size",
      "imageUrl",
    ];
    const missingFields = requiredFields.filter(
      (field) => !formData[field]?.toString().trim() // Ensure check works for numbers too
    );

    if (missingFields.length > 0) {
      toast.error(
        `Please fill in all required fields: ${missingFields.join(", ")}`,
        { duration: 4000 } // Slightly longer duration for readability
      );
      return;
    }

    // Validate price is a valid number and greater than zero
    const priceValue = Number(formData.price);
    if (isNaN(priceValue)) {
      toast.error("Price must be a valid number");
      return;
    }

    if (priceValue <= 0) {
      toast.error("Price must be greater than zero");
      return;
    }
    // --- End Validation Logic ---

    onSubmit(formData);
  };

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Reusable input field classes with improved spacing
  const inputBaseClasses =
    "block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out sm:text-sm";
  const labelBaseClasses = "block text-sm font-medium text-gray-700 mb-2";

  return (
    // When used in a modal, we don't need the extra padding and shadow
    <form onSubmit={handleSubmit} className="w-full space-y-6 relative z-20">
      {/* Grid layout with improved spacing */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-8">
        {/* Title Field */}
        <div>
          <label htmlFor="title" className={labelBaseClasses}>
            <FaHeading className="inline mr-1.5 text-gray-500" />
            Title <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            placeholder="e.g., Prime Location Billboard near City Center"
            className={inputBaseClasses}
          />
        </div>

        {/* Location Field */}
        <div>
          <label htmlFor="location" className={labelBaseClasses}>
            <FaMapMarkerAlt className="inline mr-1.5 text-gray-500" />
            Specific Location / Address <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="location"
            name="location"
            value={formData.location}
            onChange={handleChange}
            required
            placeholder="e.g., 123 Main Street, Crossroads"
            className={inputBaseClasses}
          />
        </div>

        {/* City Field */}
        <div>
          <label htmlFor="city" className={labelBaseClasses}>
            <FaCity className="inline mr-1.5 text-gray-500" />
            City <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="city"
            name="city"
            value={formData.city}
            onChange={handleChange}
            required
            placeholder="e.g., Metropolis"
            className={inputBaseClasses}
          />
        </div>

        {/* Area Field */}
        <div>
          <label htmlFor="area" className={labelBaseClasses}>
            <FaMapPin className="inline mr-1.5 text-gray-500" />
            Area / Neighborhood <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="area"
            name="area"
            value={formData.area}
            onChange={handleChange}
            required
            placeholder="e.g., Downtown Financial District"
            className={inputBaseClasses}
          />
        </div>

        {/* Price Field */}
        <div>
          <label htmlFor="price" className={labelBaseClasses}>
            <FaDollarSign className="inline mr-1.5 text-gray-500" />
            Price (per day/unit) <span className="text-red-500">*</span>
          </label>
          <input
            type="text" // Keep as text for flexibility, validation handled in JS
            id="price"
            name="price"
            value={formData.price}
            onChange={handleChange}
            required
            placeholder="e.g., 1500"
            className={inputBaseClasses}
          />
        </div>

        {/* Contact Field */}
        <div>
          <label htmlFor="contact" className={labelBaseClasses}>
            <FaPhone className="inline mr-1.5 text-gray-500" />
            Contact Information <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="contact"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            required
            placeholder="e.g., 555-1234 or contact@example.com"
            className={inputBaseClasses}
          />
        </div>

        {/* Size Field */}
        <div>
          <label htmlFor="size" className={labelBaseClasses}>
            <FaRulerCombined className="inline mr-1.5 text-gray-500" />
            Size (e.g., WxH) <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="size"
            name="size"
            value={formData.size}
            onChange={handleChange}
            required
            placeholder="e.g., 14ft x 48ft"
            className={inputBaseClasses}
          />
        </div>

        {/* Status Field */}
        <div>
          <label htmlFor="status" className={labelBaseClasses}>
            {/* Use appropriate icons based on status */}
            {formData.status === "active" ? (
              <FaCheckCircle className="inline mr-1.5 text-green-500" />
            ) : (
              <FaTimesCircle className="inline mr-1.5 text-red-500" />
            )}
            Status
          </label>
          <select
            id="status"
            name="status"
            value={formData.status}
            onChange={handleChange}
            className={`${inputBaseClasses} pr-10`} // Added padding-right for select arrow
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>

        {/* Description Field - Spanning both columns */}
        <div className="md:col-span-2">
          <label htmlFor="description" className={labelBaseClasses}>
            <FaInfoCircle className="inline mr-1.5 text-gray-500" />
            Description <span className="text-red-500">*</span>
          </label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={5}
            required
            placeholder="Provide detailed information about the billboard, visibility, audience, etc."
            className={`${inputBaseClasses} min-h-[120px] resize-y`} // Added min-height and resize capability
          />
        </div>

        {/* Image URL Field - Spanning both columns */}
        <div className="md:col-span-2">
          <label htmlFor="imageUrl" className={labelBaseClasses}>
            <FaImage className="inline mr-1.5 text-gray-500" />
            Image URL <span className="text-red-500">*</span>
          </label>
          <input
            type="url" // Use type="url" for better semantics and potential browser validation
            id="imageUrl"
            name="imageUrl"
            value={formData.imageUrl}
            onChange={handleChange}
            required
            placeholder="https://example.com/image.jpg"
            className={inputBaseClasses}
          />
          {/* Image Preview with improved styling */}
          {formData.imageUrl && (
            <div className="mt-4">
              <p className="text-sm text-gray-600 mb-2 flex items-center">
                <FaImage className="mr-1.5 text-gray-500" /> Image Preview:
              </p>
              <div className="border border-gray-200 rounded-lg p-2 bg-gray-50">
                <img
                  src={formData.imageUrl}
                  alt="Billboard Preview"
                  className="max-h-48 w-auto mx-auto rounded-lg object-contain"
                  onError={(e) => {
                    e.currentTarget.style.display = "none";
                    if (e.currentTarget.parentElement) {
                      e.currentTarget.parentElement.innerHTML =
                        '<div class="p-4 text-center text-red-500">Image failed to load</div>';
                    }
                  }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons - Grouped at the bottom with improved spacing */}
      <div className="pt-6 flex justify-end space-x-4 border-t mt-8">
        {/* Buttons with better spacing */}
        <button
          type="button"
          onClick={onCancel}
          disabled={submitting} // Disable cancel while submitting too
          className="inline-flex justify-center py-2.5 px-6 border border-gray-300 rounded-lg shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 transition duration-150 ease-in-out disabled:opacity-60"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={submitting}
          className="inline-flex justify-center items-center py-2.5 px-6 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-60 disabled:cursor-not-allowed transition duration-150 ease-in-out"
        >
          {submitting ? (
            <>
              <svg
                className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" // Slightly larger spinner
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              {isEditing ? "Updating..." : "Saving..."}
            </>
          ) : isEditing ? (
            "Update Billboard"
          ) : (
            "Add Billboard"
          )}
        </button>
      </div>
    </form>
  );
};

export default BillboardForm;
