// frontend/components/billboard/types.tsx
export interface Billboard {
  _id: string;
  title: string;
  description?: string;
  location: string;
  city?: string;
  area?: string;
  price: string;
  contact?: string;
  size?: string;
  status: "active" | "inactive";
  imageUrl?: string;
  userId: string;
}

export interface BillboardResponse {
  status: number;
  data: Billboard[];
  totalPages: number;
  page: number;
  limit: number;
}

export interface BillboardFormData {
  id?: string;
  title: string;
  description: string;
  location: string;
  city: string;
  area: string;
  price: string;
  contact: string;
  size: string;
  status: "active" | "inactive";
  imageUrl: string;
}

export interface BillboardsTableProps {
  onEdit?: (billboard: Billboard) => void;
}
