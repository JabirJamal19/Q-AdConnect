// frontend/components/billboard/useBillboardTable.ts
import { useState, useEffect, useCallback } from "react";
import axiosInstance from "../../../axiosInstance";
import { toast } from "react-hot-toast";
import { Billboard, BillboardResponse } from "./types";
import { useAuthStore } from "../../../stores/authStore";

export const useBillboardTable = () => {
  const [billboards, setBillboards] = useState<Billboard[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const { token } = useAuthStore();

  const fetchBillboards = useCallback(async () => {
    if (!token) {
      setError("Authentication required");
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const response = await axiosInstance.get<BillboardResponse>(
        `/api/billboard/list?page=${currentPage}&limit=10`
      );

      if (response.data.status === 1) {
        setBillboards(response.data.data);
        setTotalPages(response.data.totalPages);
        setError("");
      } else {
        setError("Failed to load billboards");
        setBillboards([]);
      }
    } catch (err: any) {
      console.error("Error fetching billboards:", err);
      setError(err.response?.data?.message || "Failed to load billboards");
      setBillboards([]);
    } finally {
      setLoading(false);
    }
  }, [currentPage, token]);

  useEffect(() => {
    fetchBillboards();
  }, [fetchBillboards]);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleDelete = async (id: string) => {
    try {
      await axiosInstance.delete(`/api/billboard/delete/${id}`);

      // Remove the billboard from the list immediately
      setBillboards((prevBillboards) =>
        prevBillboards.filter((billboard) => billboard._id !== id)
      );

      toast.success("Billboard deleted successfully");
    } catch (error: any) {
      toast.error(
        error.response?.data?.message || "Failed to delete billboard"
      );
    }
  };

  const addBillboardToList = (newBillboard: Billboard) => {
    setBillboards((prevBillboards) => [newBillboard, ...prevBillboards]);
  };

  return {
    billboards,
    loading,
    error,
    currentPage,
    totalPages,
    handleDelete,
    handlePageChange,
    refreshData: fetchBillboards,
    addBillboardToList,
  };
};
