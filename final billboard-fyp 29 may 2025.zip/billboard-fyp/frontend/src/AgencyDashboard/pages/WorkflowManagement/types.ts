// WorkflowManagement/types.ts
export type BookingStatus =
  | "pending"
  | "approved"
  | "rejected"
  | "paid"
  | "payment_verified"
  | "payment_rejected"
  | "payment_rejected_resubmit"
  | "content_pending"
  | "content_approved"
  | "content_rejected"
  | "content_rejected_resubmit"
  | "live"
  | "completed"
  | "cancelled";

export type PaymentStatus = "pending" | "succeeded" | "failed";

export interface Billboard {
  _id: string;
  title: string;
  location: string;
  imageUrl?: string;
}

export interface Customer {
  _id: string;
  name: string;
  email: string;
}

export interface PaymentDetails {
  customerName?: string;
  phoneNumber?: string;
  paymentMethod?: string;
  uploadedAt?: string;
}

export interface Booking {
  _id: string;
  billboardId: Billboard;
  customerId: Customer;
  startDate: string;
  endDate: string;
  duration: number;
  totalAmount: number;
  adImageUrls: string[];
  status: BookingStatus;
  paymentStatus: PaymentStatus;
  rejectionReason?: string;
  feedbackMessage?: string;
  createdAt: string;
  updatedAt: string;
  paymentProofUrl?: string;
  paymentMethod?: string;
  customerPhone?: string;
  paymentDetails?: PaymentDetails;
}

export interface BookingsApiResponse {
  status: number;
  message: string;
  data: Booking[];
  totalPages: number;
  page: number;
}

export interface ActionResponse {
  status: number;
  message: string;
  data?: {
    booking: Booking;
  };
}

export interface WorkflowStepProps {
  onRefresh?: () => void;
}
