import React, { useState, useEffect, useCallback } from "react";
import { useAuthStore } from "../../../stores/authStore";
import axios from "../../../axiosInstance";
import { toast } from "react-hot-toast";
import {
  FaSync,
  FaCheck,
  FaTimes,
  FaMoneyBillWave,
  FaEye,
  FaChevronLeft,
  FaChevronRight,
  FaExclamationTriangle,
} from "react-icons/fa";
import { Booking, BookingsApiResponse, WorkflowStepProps } from "./types";

const PaymentVerificationComponent: React.FC<WorkflowStepProps> = ({ onRefresh }) => {
  const { token } = useAuthStore();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [processingAction, setProcessingAction] = useState(false);

  // Fetch bookings with payment status "succeeded" but not yet verified
  const fetchBookings = useCallback(
    async (page: number) => {
      if (!token) return;

      setLoading(true);
      setError(null);

      try {
        const response = await axios.get<BookingsApiResponse>(
          `/api/booking/agency-view?page=${page}&limit=10&status=paid&paymentStatus=succeeded`,
          { headers: { Authorization: `Bearer ${token}` } }
        );

        if (response.data && response.data.status === 1) {
          setBookings(response.data.data);
          setTotalPages(response.data.totalPages || 1);
          setCurrentPage(response.data.page || 1);
        } else {
          throw new Error(response.data.message || "Failed to fetch bookings");
        }
      } catch (err: any) {
        console.error("Error fetching bookings:", err);
        setError(
          err.response?.data?.message ||
            err.message ||
            "Failed to fetch bookings"
        );
        toast.error("Failed to fetch bookings");
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  // Load bookings on mount
  useEffect(() => {
    fetchBookings(currentPage);
  }, [fetchBookings, currentPage]);

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "PKR",
    }).format(amount);
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages && page !== currentPage) {
      setCurrentPage(page);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  // Handle verify payment
  const handleVerifyPayment = async (bookingId: string) => {
    if (!token || processingAction) return;

    setProcessingAction(true);

    try {
      const response = await axios.put(
        `/api/booking/agency-action/${bookingId}`,
        {
          action: "verify_payment",
          feedbackMessage: feedbackMessage,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data.status === 1) {
        toast.success("Payment verified successfully");
        // Update local state
        setBookings((prevBookings) =>
          prevBookings.filter((booking) => booking._id !== bookingId)
        );
        // Reset feedback message
        setFeedbackMessage("");
        // Close modal if open
        setIsPreviewModalOpen(false);
        // Call onRefresh if provided
        if (onRefresh) onRefresh();
      } else {
        throw new Error(response.data.message || "Failed to verify payment");
      }
    } catch (err: any) {
      console.error("Error verifying payment:", err);
      toast.error(
        err.response?.data?.message ||
          err.message ||
          "Failed to verify payment"
      );
    } finally {
      setProcessingAction(false);
    }
  };

  // State for resubmission option
  const [allowResubmission, setAllowResubmission] = useState(true);

  // Handle reject payment
  const handleRejectPayment = async () => {
    if (!selectedBooking || !rejectionReason || !token || processingAction)
      return;

    setProcessingAction(true);

    try {
      const response = await axios.put(
        `/api/booking/agency-action/${selectedBooking._id}`,
        {
          action: allowResubmission ? "reject_payment_resubmit" : "reject_payment",
          rejectionReason,
          feedbackMessage: feedbackMessage,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data.status === 1) {
        toast.success(allowResubmission
          ? "Payment rejected with resubmission option"
          : "Payment rejected");
        // Update local state
        setBookings((prevBookings) =>
          prevBookings.filter((booking) => booking._id !== selectedBooking._id)
        );
        // Close modal
        setIsRejectModalOpen(false);
        setRejectionReason("");
        setFeedbackMessage("");
        setSelectedBooking(null);
        setAllowResubmission(true); // Reset for next time
        // Call onRefresh if provided
        if (onRefresh) onRefresh();
      } else {
        throw new Error(response.data.message || "Failed to reject payment");
      }
    } catch (err: any) {
      console.error("Error rejecting payment:", err);
      toast.error(
        err.response?.data?.message ||
          err.message ||
          "Failed to reject payment"
      );
    } finally {
      setProcessingAction(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center">
          <FaMoneyBillWave className="mr-2 text-green-600" />
          Payment Verification
        </h2>
        <p className="text-gray-600 mt-1">
          Verify customer payments after content has been approved
        </p>
      </div>

      {/* Filters and Actions */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <button
            onClick={() => fetchBookings(currentPage)}
            disabled={loading}
            className="bg-blue-100 hover:bg-blue-200 text-blue-700 p-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            title="Refresh Bookings"
          >
            <FaSync
              className={`${loading ? "animate-spin" : ""} h-5 w-5`}
            />
          </button>
        </div>
      </div>

      {/* Bookings List */}
      {loading && bookings.length === 0 ? (
        <div className="py-12 text-center">
          <FaSync className="animate-spin text-4xl mx-auto mb-4 text-blue-500" />
          <p className="text-gray-500 font-medium">Loading payments...</p>
        </div>
      ) : error ? (
        <div className="py-12 text-center">
          <FaExclamationTriangle className="text-4xl mx-auto mb-4 text-red-500" />
          <p className="text-red-500 font-medium">{error}</p>
          <button
            onClick={() => fetchBookings(currentPage)}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      ) : bookings.length === 0 ? (
        <div className="py-12 text-center border rounded-lg bg-gray-50">
          <FaMoneyBillWave className="text-4xl mx-auto mb-4 text-gray-400" />
          <p className="text-gray-500 font-medium">
            No payments pending verification
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Billboard
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Payment Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {bookings.map((booking) => (
                <tr key={booking._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {booking.billboardId.title}
                    </div>
                    <div className="text-sm text-gray-500">
                      {booking.billboardId.location}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {booking.customerId.name}
                    </div>
                    <div className="text-sm text-gray-500">
                      {booking.customerId.email}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {formatCurrency(booking.totalAmount)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                      Pending Verification
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(booking.createdAt)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex space-x-2 justify-end">
                      <button
                        onClick={() => {
                          setSelectedBooking(booking);
                          setIsPreviewModalOpen(true);
                        }}
                        className="text-blue-600 hover:text-blue-900 flex items-center"
                      >
                        <FaEye className="mr-1" />
                        View Details
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {!loading && !error && bookings.length > 0 && (
        <div className="flex justify-between items-center mt-6">
          <div className="text-sm text-gray-500">
            Page {currentPage} of {totalPages}
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1 || loading}
              className="p-2 rounded-md bg-white border border-gray-300 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              aria-label="Previous Page"
            >
              <FaChevronLeft className="w-4 h-4 text-gray-600" />
            </button>
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages || loading}
              className="p-2 rounded-md bg-white border border-gray-300 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              aria-label="Next Page"
            >
              <FaChevronRight className="w-4 h-4 text-gray-600" />
            </button>
          </div>
        </div>
      )}

      {/* Payment Details Modal */}
      {isPreviewModalOpen && selectedBooking && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[9999] p-4 backdrop-blur-sm">
          <div className="bg-white rounded-lg max-w-5xl w-[95%] max-h-[95vh] overflow-hidden flex flex-col shadow-2xl border border-gray-200">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="text-lg font-medium">
                Payment Verification for {selectedBooking.billboardId?.title}
              </h3>
              <button
                onClick={() => setIsPreviewModalOpen(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <FaTimes />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-4 bg-gray-50">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-4 rounded-lg shadow">
                  <h4 className="font-medium text-gray-800 mb-3">Booking Details</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Billboard:</span>
                      <span className="font-medium">{selectedBooking.billboardId.title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Location:</span>
                      <span>{selectedBooking.billboardId.location}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Booking Period:</span>
                      <span>
                        {formatDate(selectedBooking.startDate)} - {formatDate(selectedBooking.endDate)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Duration:</span>
                      <span>{selectedBooking.duration} days</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Amount:</span>
                      <span className="font-medium text-green-600">
                        {formatCurrency(selectedBooking.totalAmount)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                  <h4 className="font-medium text-gray-800 mb-3">Customer Details</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Name:</span>
                      <span className="font-medium">{selectedBooking.customerId.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Email:</span>
                      <span>{selectedBooking.customerId.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Payment Method:</span>
                      <span className="capitalize">{selectedBooking.paymentMethod || "Not specified"}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Proof */}
              <div className="mt-6 bg-white p-4 rounded-lg shadow">
                <h4 className="font-medium text-gray-800 mb-3">Payment Proof</h4>
                {selectedBooking.paymentProofUrl ? (
                  <div className="flex flex-col items-center">
                    <img
                      src={selectedBooking.paymentProofUrl}
                      alt="Payment Proof"
                      className="max-w-full max-h-96 object-contain border rounded"
                    />
                    <div className="mt-4 text-sm text-gray-600">
                      <p><strong>Payment Method:</strong> {selectedBooking.paymentMethod ? selectedBooking.paymentMethod.charAt(0).toUpperCase() + selectedBooking.paymentMethod.slice(1) : 'Not specified'}</p>
                      {selectedBooking.customerPhone && (
                        <p><strong>Customer Phone:</strong> {selectedBooking.customerPhone}</p>
                      )}
                      {selectedBooking.paymentDetails && (
                        <>
                          {selectedBooking.paymentDetails.customerName && (
                            <p><strong>Customer Name:</strong> {selectedBooking.paymentDetails.customerName}</p>
                          )}
                          {selectedBooking.paymentDetails.uploadedAt && (
                            <p><strong>Uploaded:</strong> {new Date(selectedBooking.paymentDetails.uploadedAt).toLocaleString()}</p>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 bg-gray-50 rounded border border-dashed">
                    <p className="text-gray-500">No payment proof uploaded</p>
                  </div>
                )}
              </div>
            </div>

            {/* Feedback message input */}
            <div className="p-4 border-t">
              <p className="mb-2 text-gray-700">
                Add a feedback message for the customer (optional):
              </p>
              <textarea
                value={feedbackMessage}
                onChange={(e) => setFeedbackMessage(e.target.value)}
                placeholder="Enter feedback for the customer..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                rows={3}
              />
            </div>

            {/* Action buttons */}
            <div className="p-4 border-t flex justify-end space-x-2">
              <button
                onClick={() => {
                  setIsPreviewModalOpen(false);
                  setIsRejectModalOpen(true);
                }}
                className="px-4 py-2 border border-red-300 text-red-700 rounded-md hover:bg-red-50"
                disabled={processingAction}
              >
                Reject Payment
              </button>
              <button
                onClick={() => handleVerifyPayment(selectedBooking._id)}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                disabled={processingAction}
              >
                {processingAction ? (
                  <span className="flex items-center">
                    <FaSync className="animate-spin mr-2" /> Processing...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <FaCheck className="mr-2" /> Verify Payment
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {isRejectModalOpen && selectedBooking && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[9999] p-4 backdrop-blur-sm">
          <div className="bg-white rounded-lg max-w-md w-[95%] overflow-hidden shadow-2xl border border-gray-200">
            <div className="p-4 border-b">
              <h3 className="text-lg font-medium">Reject Payment</h3>
            </div>
            <div className="p-4">
              <p className="mb-4 text-gray-700">
                Please provide a reason for rejecting this payment. This will be
                visible to the customer.
              </p>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Enter rejection reason..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                rows={4}
                required
              />

              {/* Resubmission option */}
              <div className="mt-4 flex items-center">
                <input
                  type="checkbox"
                  id="allowResubmission"
                  checked={allowResubmission}
                  onChange={(e) => setAllowResubmission(e.target.checked)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <label htmlFor="allowResubmission" className="ml-2 block text-sm text-gray-700">
                  Allow customer to resubmit payment proof
                </label>
              </div>

              <div className="mt-2 text-xs text-gray-500">
                {allowResubmission
                  ? "Customer will be able to resubmit new payment proof after addressing the issues mentioned above."
                  : "Customer will NOT be able to resubmit payment proof for this booking."}
              </div>
            </div>
            <div className="p-4 border-t flex justify-end space-x-2">
              <button
                onClick={() => setIsRejectModalOpen(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                disabled={processingAction}
              >
                Cancel
              </button>
              <button
                onClick={handleRejectPayment}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                disabled={!rejectionReason.trim() || processingAction}
              >
                {processingAction ? (
                  <span className="flex items-center">
                    <FaSync className="animate-spin mr-2" /> Processing...
                  </span>
                ) : (
                  "Confirm Rejection"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentVerificationComponent;
