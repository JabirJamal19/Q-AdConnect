import React, { useState, useCallback } from "react";
import { Tab } from "@headlessui/react";
import {
  FaMoneyBillWave,
  FaImages,
  FaBroadcastTower,
  FaArrowRight,
  FaExclamationTriangle,
  FaCheckCircle
} from "react-icons/fa";
import PaymentVerificationComponent from "./PaymentVerificationComponent";
import ContentReviewComponent from "./ContentReviewComponent";
import BillboardActivationComponent from "./BillboardActivationComponent";

function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(" ");
}

const WorkflowManagementPage: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [refreshKey, setRefreshKey] = useState(0);

  // Function to refresh components
  const handleRefresh = useCallback(() => {
    setRefreshKey(prev => prev + 1);
  }, []);

  // Function to move to the next workflow step
  const handleNextStep = useCallback(() => {
    setSelectedIndex(prev => Math.min(prev + 1, 2));
  }, []);

  // Tabs configuration
  const tabs = [
    {
      name: "Content Review",
      icon: <FaImages />,
      component: <ContentReviewComponent key={refreshKey} onRefresh={handleRefresh} />,
      description: "Review and approve billboard content from customers",
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      hoverBgColor: "hover:bg-blue-200",
    },
    {
      name: "Payment Verification",
      icon: <FaMoneyBillWave />,
      component: <PaymentVerificationComponent key={refreshKey} onRefresh={handleRefresh} />,
      description: "Verify customer payments after content approval",
      color: "text-green-600",
      bgColor: "bg-green-100",
      hoverBgColor: "hover:bg-green-200",
    },
    {
      name: "Billboard Activation",
      icon: <FaBroadcastTower />,
      component: <BillboardActivationComponent key={refreshKey} onRefresh={handleRefresh} />,
      description: "Set approved content live on billboards",
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      hoverBgColor: "hover:bg-purple-200",
    },
  ];

  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Booking Workflow Management</h1>
        <p className="text-gray-600 mt-2">
          Manage the complete booking workflow from content review to setting billboards live
        </p>
      </div>

      {/* Workflow Steps Visualization */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
          <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-4 mb-4 md:mb-0">
            {tabs.map((tab, index) => (
              <div key={index} className="flex items-center">
                <div
                  className={`flex items-center ${
                    index <= selectedIndex
                      ? `${tab.bgColor} ${tab.color}`
                      : "bg-gray-100 text-gray-400"
                  } p-2 rounded-full`}
                >
                  <div className="w-8 h-8 flex items-center justify-center rounded-full">
                    {tab.icon}
                  </div>
                </div>
                <span
                  className={`ml-2 font-medium ${
                    index <= selectedIndex ? "text-gray-800" : "text-gray-400"
                  }`}
                >
                  {tab.name}
                </span>

                {index < tabs.length - 1 && (
                  <div className="hidden md:block mx-2">
                    <FaArrowRight className={index < selectedIndex ? "text-gray-800" : "text-gray-300"} />
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="flex space-x-2">
            <button
              onClick={handleNextStep}
              disabled={selectedIndex >= tabs.length - 1}
              className={`px-4 py-2 rounded-md flex items-center space-x-1 ${
                selectedIndex >= tabs.length - 1
                  ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                  : "bg-blue-600 text-white hover:bg-blue-700"
              }`}
            >
              <span>Next Step</span>
              <FaArrowRight />
            </button>
          </div>
        </div>
      </div>

      {/* Workflow Guidance */}
      <div className="mb-6 p-4 border border-blue-200 rounded-lg bg-blue-50">
        <div className="flex items-start">
          <div className="flex-shrink-0 mt-0.5">
            <FaExclamationTriangle className="h-5 w-5 text-blue-600" />
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">Workflow Guidance</h3>
            <div className="mt-2 text-sm text-blue-700">
              <p>
                Follow these steps in sequence to ensure proper booking processing:
              </p>
              <ol className="list-decimal pl-5 mt-1 space-y-1">
                <li>Review and approve billboard content from customers</li>
                <li>Verify customer payments after content is approved</li>
                <li>Set approved content live on billboards as the final step</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <Tab.Group selectedIndex={selectedIndex} onChange={setSelectedIndex}>
        <Tab.List className="flex space-x-1 rounded-xl bg-gray-200 p-1">
          {tabs.map((tab, index) => (
            <Tab
              key={index}
              className={({ selected }) =>
                classNames(
                  "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
                  "ring-white ring-opacity-60 ring-offset-2 ring-offset-blue-400 focus:outline-none focus:ring-2",
                  selected
                    ? `${tab.bgColor} ${tab.color} shadow`
                    : "text-gray-600 hover:bg-white/[0.12] hover:text-gray-700"
                )
              }
            >
              <div className="flex items-center justify-center space-x-2">
                <span>{tab.icon}</span>
                <span>{tab.name}</span>
              </div>
            </Tab>
          ))}
        </Tab.List>
        <Tab.Panels className="mt-6">
          {tabs.map((tab, index) => (
            <Tab.Panel
              key={index}
              className={classNames(
                "rounded-xl bg-white p-3",
                "ring-white ring-opacity-60 ring-offset-2 ring-offset-blue-400 focus:outline-none focus:ring-2"
              )}
            >
              {tab.component}
            </Tab.Panel>
          ))}
        </Tab.Panels>
      </Tab.Group>

      {/* Workflow Completion Status */}
      <div className="mt-8 p-4 border border-gray-200 rounded-lg bg-gray-50">
        <div className="flex items-center">
          <FaCheckCircle className="h-5 w-5 text-green-500" />
          <span className="ml-2 text-gray-700">
            Complete all steps to ensure proper booking processing and billboard activation.
          </span>
        </div>
      </div>
    </div>
  );
};

export default WorkflowManagementPage;
