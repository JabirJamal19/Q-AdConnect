import React, { useState, useEffect, useCallback } from "react";
import { useAuthStore } from "../../../stores/authStore";
import axios from "../../../axiosInstance";
import { toast } from "react-hot-toast";
import {
  FaSync,
  FaCheck,
  FaTimes,
  FaCalendarCheck,
  FaEye,
  FaChevronLeft,
  FaChevronRight,
  FaExclamationTriangle,
  FaArrowLeft,
  FaArrowRight,
  FaBroadcastTower,
} from "react-icons/fa";
import { Booking, BookingsApiResponse, WorkflowStepProps } from "./types";

const BillboardActivationComponent: React.FC<WorkflowStepProps> = ({ onRefresh }) => {
  const { token } = useAuthStore();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [processingAction, setProcessingAction] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);

  // Fetch bookings with content approved or payment verified status
  const fetchBookings = useCallback(
    async (page: number) => {
      if (!token) return;

      setLoading(true);
      setError(null);

      try {
        const response = await axios.get<BookingsApiResponse>(
          `/api/booking/agency-view?page=${page}&limit=10&status=content_approved,payment_verified`,
          { headers: { Authorization: `Bearer ${token}` } }
        );

        if (response.data && response.data.status === 1) {
          // Validate that adImageUrls exists in each booking
          const validatedBookings = response.data.data.map(
            (booking: Booking) => {
              if (!booking.adImageUrls || !Array.isArray(booking.adImageUrls)) {
                console.warn(
                  `Booking ${booking._id} has invalid adImageUrls:`,
                  booking.adImageUrls
                );
                // Provide a default empty array if adImageUrls is missing or invalid
                return { ...booking, adImageUrls: [] };
              }
              return booking;
            }
          );

          setBookings(validatedBookings);
          setTotalPages(response.data.totalPages || 1);
          setCurrentPage(response.data.page || 1);
        } else {
          throw new Error(response.data.message || "Failed to fetch bookings");
        }
      } catch (err: any) {
        console.error("Error fetching bookings:", err);
        setError(
          err.response?.data?.message ||
            err.message ||
            "Failed to fetch bookings"
        );
        toast.error("Failed to fetch bookings");
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  // Load bookings on mount
  useEffect(() => {
    fetchBookings(currentPage);
  }, [fetchBookings, currentPage]);

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages && page !== currentPage) {
      setCurrentPage(page);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  // Handle set billboard live
  const handleSetLive = async (bookingId: string) => {
    if (!token || processingAction) return;

    setProcessingAction(true);

    try {
      const response = await axios.put(
        `/api/booking/agency-action/${bookingId}`,
        {
          action: "set_live",
          feedbackMessage: feedbackMessage,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data.status === 1) {
        toast.success("Billboard set to live successfully");
        // Update local state
        setBookings((prevBookings) =>
          prevBookings.filter((booking) => booking._id !== bookingId)
        );
        // Reset feedback message
        setFeedbackMessage("");
        // Close modals if open
        setIsPreviewModalOpen(false);
        setIsConfirmModalOpen(false);
        // Call onRefresh if provided
        if (onRefresh) onRefresh();
      } else {
        throw new Error(
          response.data.message || "Failed to set billboard live"
        );
      }
    } catch (err: any) {
      console.error("Error setting billboard live:", err);
      toast.error(
        err.response?.data?.message ||
          err.message ||
          "Failed to set billboard live"
      );
    } finally {
      setProcessingAction(false);
    }
  };

  // Navigate through images in the preview modal
  const handleNextImage = () => {
    if (selectedBooking && currentImageIndex < selectedBooking.adImageUrls.length - 1) {
      setCurrentImageIndex(currentImageIndex + 1);
    }
  };

  const handlePrevImage = () => {
    if (currentImageIndex > 0) {
      setCurrentImageIndex(currentImageIndex - 1);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center">
          <FaBroadcastTower className="mr-2 text-purple-600" />
          Billboard Activation
        </h2>
        <p className="text-gray-600 mt-1">
          Set approved content live on billboards
        </p>
      </div>

      {/* Filters and Actions */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <button
            onClick={() => fetchBookings(currentPage)}
            disabled={loading}
            className="bg-blue-100 hover:bg-blue-200 text-blue-700 p-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            title="Refresh Bookings"
          >
            <FaSync
              className={`${loading ? "animate-spin" : ""} h-5 w-5`}
            />
          </button>
        </div>
      </div>

      {/* Bookings List */}
      {loading && bookings.length === 0 ? (
        <div className="py-12 text-center">
          <FaSync className="animate-spin text-4xl mx-auto mb-4 text-blue-500" />
          <p className="text-gray-500 font-medium">Loading approved content...</p>
        </div>
      ) : error ? (
        <div className="py-12 text-center">
          <FaExclamationTriangle className="text-4xl mx-auto mb-4 text-red-500" />
          <p className="text-red-500 font-medium">{error}</p>
          <button
            onClick={() => fetchBookings(currentPage)}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      ) : bookings.length === 0 ? (
        <div className="py-12 text-center border rounded-lg bg-gray-50">
          <FaCalendarCheck className="text-4xl mx-auto mb-4 text-gray-400" />
          <p className="text-gray-500 font-medium">
            No approved content ready to go live
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Billboard
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Booking Period
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Content
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {bookings.map((booking) => (
                <tr key={booking._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {booking.billboardId.title}
                    </div>
                    <div className="text-sm text-gray-500">
                      {booking.billboardId.location}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {booking.customerId.name}
                    </div>
                    <div className="text-sm text-gray-500">
                      {booking.customerId.email}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {formatDate(booking.startDate)} - {formatDate(booking.endDate)}
                    </div>
                    <div className="text-sm text-gray-500">
                      {booking.duration} days
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                      Content Approved
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <button
                        onClick={() => {
                          setSelectedBooking(booking);
                          setCurrentImageIndex(0);
                          setIsPreviewModalOpen(true);
                        }}
                        className="text-blue-600 hover:text-blue-900 flex items-center"
                      >
                        <FaEye className="mr-1" />
                        View Content
                      </button>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex space-x-2 justify-end">
                      <button
                        onClick={() => {
                          setSelectedBooking(booking);
                          setIsConfirmModalOpen(true);
                        }}
                        disabled={processingAction}
                        className="text-purple-600 hover:text-purple-900 flex items-center"
                      >
                        <FaBroadcastTower className="mr-1" />
                        Set Live
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {!loading && !error && bookings.length > 0 && (
        <div className="flex justify-between items-center mt-6">
          <div className="text-sm text-gray-500">
            Page {currentPage} of {totalPages}
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1 || loading}
              className="p-2 rounded-md bg-white border border-gray-300 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              aria-label="Previous Page"
            >
              <FaChevronLeft className="w-4 h-4 text-gray-600" />
            </button>
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages || loading}
              className="p-2 rounded-md bg-white border border-gray-300 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              aria-label="Next Page"
            >
              <FaChevronRight className="w-4 h-4 text-gray-600" />
            </button>
          </div>
        </div>
      )}

      {/* Content Preview Modal */}
      {isPreviewModalOpen && selectedBooking && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[9999] p-4 backdrop-blur-sm">
          <div className="bg-white rounded-lg max-w-5xl w-[95%] max-h-[95vh] overflow-hidden flex flex-col shadow-2xl border border-gray-200">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="text-lg font-medium">
                Approved Content for {selectedBooking.billboardId?.title}
              </h3>
              <button
                onClick={() => setIsPreviewModalOpen(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <FaTimes />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-4 bg-gray-50">
              {selectedBooking.adImageUrls && selectedBooking.adImageUrls.length > 0 ? (
                <div className="flex flex-col items-center">
                  <div className="relative w-full max-w-3xl">
                    {selectedBooking.adImageUrls && selectedBooking.adImageUrls.length > 0 ? (
                      <img
                        src={selectedBooking.adImageUrls[currentImageIndex]}
                        alt={`Ad content ${currentImageIndex + 1}`}
                        className="max-w-full max-h-[60vh] object-contain mx-auto border rounded-lg shadow-md"
                        onError={(e) => {
                          console.error("Error loading image:", e);
                          e.currentTarget.src = "/images/placeholder-image.png";
                          e.currentTarget.alt = "Image failed to load";
                        }}
                      />
                    ) : (
                      <div className="flex items-center justify-center h-[60vh] bg-gray-100 border rounded-lg">
                        <p className="text-gray-500">No image available</p>
                      </div>
                    )}

                    {/* Image navigation controls */}
                    {selectedBooking.adImageUrls && selectedBooking.adImageUrls.length > 1 && (
                      <div className="absolute inset-x-0 top-1/2 transform -translate-y-1/2 flex justify-between px-4">
                        <button
                          onClick={handlePrevImage}
                          disabled={currentImageIndex === 0}
                          className="p-2 rounded-full bg-black bg-opacity-50 text-white disabled:opacity-30 disabled:cursor-not-allowed"
                        >
                          <FaArrowLeft />
                        </button>
                        <button
                          onClick={handleNextImage}
                          disabled={currentImageIndex === selectedBooking.adImageUrls.length - 1}
                          className="p-2 rounded-full bg-black bg-opacity-50 text-white disabled:opacity-30 disabled:cursor-not-allowed"
                        >
                          <FaArrowRight />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Image counter */}
                  {selectedBooking.adImageUrls && selectedBooking.adImageUrls.length > 1 && (
                    <div className="mt-4 text-center">
                      <p className="text-gray-600">
                        Image {currentImageIndex + 1} of {selectedBooking.adImageUrls.length}
                      </p>
                    </div>
                  )}

                  {/* Thumbnails for multiple images */}
                  {selectedBooking.adImageUrls && selectedBooking.adImageUrls.length > 1 && (
                    <div className="mt-4 flex flex-wrap justify-center gap-2">
                      {selectedBooking.adImageUrls.map((url, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={`w-16 h-16 border-2 rounded overflow-hidden ${
                            index === currentImageIndex
                              ? "border-blue-500"
                              : "border-gray-200"
                          }`}
                        >
                          <img
                            src={url}
                            alt={`Thumbnail ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-100 rounded-lg">
                  <FaExclamationTriangle className="text-4xl mx-auto mb-4 text-yellow-500" />
                  <p className="text-gray-600">No ad images available for this booking.</p>
                </div>
              )}
            </div>

            {/* Feedback message input */}
            <div className="p-4 border-t">
              <p className="mb-2 text-gray-700">
                Add a message for when the billboard goes live (optional):
              </p>
              <textarea
                value={feedbackMessage}
                onChange={(e) => setFeedbackMessage(e.target.value)}
                placeholder="Enter message about the billboard going live..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                rows={3}
              />
            </div>

            {/* Action buttons */}
            <div className="p-4 border-t flex justify-end space-x-2">
              <button
                onClick={() => {
                  setIsPreviewModalOpen(false);
                  setIsConfirmModalOpen(true);
                }}
                className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
                disabled={processingAction}
              >
                {processingAction ? (
                  <span className="flex items-center">
                    <FaSync className="animate-spin mr-2" /> Processing...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <FaBroadcastTower className="mr-2" /> Set Billboard Live
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Set Live Modal */}
      {isConfirmModalOpen && selectedBooking && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[9999] p-4 backdrop-blur-sm">
          <div className="bg-white rounded-lg max-w-md w-[95%] overflow-hidden shadow-2xl border border-gray-200">
            <div className="p-4 border-b">
              <h3 className="text-lg font-medium">Confirm Billboard Activation</h3>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-center mb-4 text-purple-600">
                <FaBroadcastTower className="text-5xl" />
              </div>
              <p className="mb-4 text-gray-700 text-center">
                Are you sure you want to set this billboard live?
              </p>
              <div className="bg-gray-50 p-3 rounded-lg mb-4">
                <p className="font-medium text-gray-800">{selectedBooking.billboardId.title}</p>
                <p className="text-sm text-gray-600">{selectedBooking.billboardId.location}</p>
                <p className="text-sm text-gray-600 mt-1">
                  {formatDate(selectedBooking.startDate)} - {formatDate(selectedBooking.endDate)}
                </p>
              </div>
              <p className="text-sm text-gray-500">
                This will make the approved content visible on the physical billboard.
              </p>
            </div>
            <div className="p-4 border-t flex justify-end space-x-2">
              <button
                onClick={() => setIsConfirmModalOpen(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                disabled={processingAction}
              >
                Cancel
              </button>
              <button
                onClick={() => handleSetLive(selectedBooking._id)}
                className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700"
                disabled={processingAction}
              >
                {processingAction ? (
                  <span className="flex items-center">
                    <FaSync className="animate-spin mr-2" /> Processing...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <FaBroadcastTower className="mr-2" /> Confirm Activation
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BillboardActivationComponent;
