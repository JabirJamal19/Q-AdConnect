import React, { useState } from "react";
import axios from "../../../axiosInstance";
import { useNavigate } from "react-router-dom";

const UpdatePassword: React.FC = () => {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleUpdatePassword = async () => {
    setMessage("");
    setError("");

    const token = localStorage.getItem("token"); // Get token

    try {
      const response = await axios.post(
        "/api/auth/update-password",
        {
          password: currentPassword,
          newpassword: newPassword,
          confirmpassword: confirmPassword,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`, // Send token
          },
        }
      );

      setMessage(response.data.message);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      console.log("Password updated successfully", response.data);

      // Log out the user by removing the token
      localStorage.removeItem("token");

      // Redirect to login page
      navigate("/auth");
    } catch (err: any) {
      if (axios.isAxiosError(err)) {
        setError(err.response?.data || err.message);
      } else {
        setError("Unexpected error occurred.");
      }
    }
  };

  return (
    <div className="rounded border p-6 shadow-md dark:border-gray-700 dark:bg-gray-800">
      <h2 className="mb-4 text-lg font-semibold text-gray-800 dark:text-white">
        Update Password
      </h2>
      {message && <div className="mb-4 text-green-600">{message}</div>}
      {error && <div className="mb-4 text-red-600">{error}</div>}

      <div className="mb-4">
        <label
          htmlFor="currentPassword"
          className="block text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          Current Password
        </label>
        <input
          type="password"
          id="currentPassword"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          className="mt-1 w-full rounded border p-2 dark:bg-gray-700 dark:text-white"
        />
      </div>

      <div className="mb-4">
        <label
          htmlFor="newPassword"
          className="block text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          New Password
        </label>
        <input
          type="password"
          id="newPassword"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className="mt-1 w-full rounded border p-2 dark:bg-gray-700 dark:text-white"
        />
      </div>

      <div className="mb-4">
        <label
          htmlFor="confirmPassword"
          className="block text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          Confirm Password
        </label>
        <input
          type="password"
          id="confirmPassword"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="mt-1 w-full rounded border p-2 dark:bg-gray-700 dark:text-white"
        />
      </div>

      <button
        className="rounded bg-primary py-2 px-6 font-medium text-white hover:bg-opacity-90"
        onClick={handleUpdatePassword}
      >
        Update Password
      </button>
    </div>
  );
};

export default UpdatePassword;
