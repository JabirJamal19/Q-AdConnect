import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ResetPassword: React.FC = () => {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSendOtp = async () => {
    setError("");
    setMessage("");
    try {
      const response = await axios.post("/api/auth/reset-password", { email });
      setMessage(response.data.message);
    } catch (err: any) {
      setError(err.response?.data?.message || "Error sending OTP");
    }
  };

  const handleVerifyOtpAndResetPassword = async () => {
    if (!email || !otp || !newPassword) {
        setError("All fields are required!");
        return;
    }

    try {
        const response = await axios.post("/api/auth/verify-resetpassword-otp", {
            email,
            otp,
            newPassword,
        });
        setMessage(response.data.message);

        // Only redirect if the password is reset successfully
        if (response.status === 200) {
            setTimeout(() => {
                navigate("/auth/signin");
            }, 2000);
        }
    } catch (err: any) {
        setError(err.response?.data?.message || "Error resetting password");
    }
};


  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <h2 className="text-2xl font-bold text-center mb-6">Reset Password</h2>
        {message && <div className="text-green-600 text-center mb-4">{message}</div>}
        {error && <div className="text-red-600 text-center mb-4">{error}</div>}

        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          className="w-full mb-4 p-3 border rounded"
        />
        <button onClick={handleSendOtp} className="w-full mb-4 p-3 bg-indigo-600 text-white rounded">
          Send OTP
        </button>

        <input
          type="text"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          placeholder="Enter OTP"
          className="w-full mb-4 p-3 border rounded"
        />
        <input
          type="password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          placeholder="Enter new password"
          className="w-full mb-4 p-3 border rounded"
        />
        <button
          onClick={handleVerifyOtpAndResetPassword}
          className="w-full p-3 bg-green-600 text-white rounded"
        >
          Reset Password
        </button>
      </div>
    </div>
  );
};

export default ResetPassword;
