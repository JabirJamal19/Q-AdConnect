// import React, { useState } from "react";
// import axios from "../../../axiosInstance";
// import toast from "react-hot-toast";
// import { useNavigate } from "react-router-dom";
// import { useAuthStore } from "../../../stores/authStore";

// const AdminSignIn: React.FC = () => {
//   const { isAuthenticated, token } = useAuthStore();
//   const navigate = useNavigate();
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const handleSubmit = async (event: React.FormEvent) => {
//     event.preventDefault();

//     try {
//       const response = await axios.post("/api/auth/login", {
//         email: email,
//         password: password,
//         role: "admin",
//       });

//       const { user, token } = response.data;

//       // Ensure user object has all required fields
//       if (!user._id || !user.role) {
//         throw new Error("Invalid user data received");
//       }

//       // Store token and complete user details in the auth store
//       localStorage.setItem("token", token);
//       useAuthStore.getState().login(token, user);

//       toast.success("Admin Login successful");
//       navigate("/dashboard");
//     } catch (error: any) {
//       const errorMsg =
//         error.response?.data?.message ||
//         "Login failed. Please check your credentials.";
//       toast.error(errorMsg);
//     }
//   };

//   return (
//     <div className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
//       <div className="flex flex-wrap items-center justify-center p-2">
//         <div className="w-full border-stroke dark:border-strokedark xl:w-1/2 xl:border">
//           <div className="w-full p-4 sm:p-12.5 xl:p-17.5">
//             <h2 className="mb-9 text-2xl font-bold text-black dark:text-white sm:text-title-xl2">
//               Admin Login
//             </h2>

//             <form onSubmit={handleSubmit}>
//               <div className="mb-4">
//                 <label className="mb-2.5 block font-medium text-black dark:text-white">
//                   Email
//                 </label>
//                 <div className="relative">
//                   <input
//                     type="email"
//                     placeholder="Enter your email"
//                     value={email}
//                     onChange={(e) => setEmail(e.target.value)}
//                     className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
//                   />
//                 </div>
//               </div>

//               <div className="mb-6">
//                 <label className="mb-2.5 block font-medium text-black dark:text-white">
//                   Password
//                 </label>
//                 <div className="relative">
//                   <input
//                     type="password"
//                     placeholder="Enter your password"
//                     value={password}
//                     onChange={(e) => setPassword(e.target.value)}
//                     className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
//                   />
//                 </div>
//               </div>

//               <div className="mb-5">
//                 <input
//                   type="submit"
//                   value="Sign In"
//                   className="w-full cursor-pointer rounded-lg border border-primary bg-primary p-4 text-white transition hover:bg-opacity-90"
//                 />
//               </div>
//             </form>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AdminSignIn;
