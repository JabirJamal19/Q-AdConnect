import React, { useState } from "react";
import axios from "../../../axiosInstance";
import { useAuthStore } from "../../../stores/authStore";
import toast from "react-hot-toast";
import { useNavigate, useLocation } from "react-router-dom";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

type UserRole = "customer" | "agency" | "admin";

interface SignInState {
  email: string;
  password: string;
  role: UserRole;
}

const SignIn: React.FC = () => {
  // Initialize state with values from tempLoginInfo if available
  const getTempLoginInfo = () => {
    try {
      const tempInfo = sessionStorage.getItem("tempLoginInfo");
      if (tempInfo) {
        const { email, role } = JSON.parse(tempInfo);
        // Clear the temp info after using it
        sessionStorage.removeItem("tempLoginInfo");
        return { email, password: "", role: role as UserRole };
      }
    } catch (error) {
      console.error("Error parsing temp login info:", error);
    }
    return { email: "", password: "", role: "customer" as UserRole };
  };

  const [state, setState] = useState<SignInState>(getTempLoginInfo());
  const [loading, setLoading] = useState<boolean>(false);
  const [comingFromPasswordChange, setComingFromPasswordChange] =
    useState<boolean>(!!sessionStorage.getItem("tempLoginInfo"));
  const navigate = useNavigate();
  const location = useLocation();

  // ******** Forget Password ********
  const handleRedirect = () => {
    navigate("/auth/reset-password");
  };

  // ******** Role Change ********
  const handleRoleChange = (role: UserRole) => {
    setState((prevState) => ({ ...prevState, role }));
    toast.success(`Role changed to ${role.toUpperCase()}.`);
  };

  // ******** Handle Input Change ********
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setState((prevState) => ({ ...prevState, [name]: value }));
  };

  // Show notification if coming from password change
  React.useEffect(() => {
    if (comingFromPasswordChange) {
      toast.success("Please enter your new password to log in", {
        duration: 5000,
      });
      setComingFromPasswordChange(false);
    }
  }, [comingFromPasswordChange]);

  // ******** Login ********
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validate inputs before sending request
      if (!state.email || !state.email.trim()) {
        toast.error("Email is required");
        setLoading(false);
        return;
      }

      if (!state.password) {
        toast.error("Password is required");
        setLoading(false);
        return;
      }

      console.log("Login attempt with:", {
        email: state.email,
        role: state.role,
      });

      // Direct API call with error handling
      const response = await axios.post("/api/auth/login", {
        email: state.email.trim(),
        password: state.password,
        role: state.role,
      });

      console.log("Login response:", {
        status: response.data.status,
        message: response.data.message,
        hasToken: !!response.data.token,
        hasUser: !!response.data.user,
        userRole: response.data.user?.role,
      });

      if (
        response.data.status === 1 &&
        response.data.token &&
        response.data.user
      ) {
        const { token, user } = response.data;

        // Validate user object
        if (!user._id || !user.role) {
          console.error("Invalid user object received:", user);
          toast.error("Invalid user data received from server");
          setLoading(false);
          return;
        }

        // Clear any existing auth data
        localStorage.removeItem("token");
        localStorage.removeItem("user");

        // Store new auth data
        localStorage.setItem("token", token);
        localStorage.setItem("user", JSON.stringify(user));

        // Log what we stored
        console.log("Stored in localStorage:", {
          token: "TOKEN_EXISTS",
          user: { id: user._id, role: user.role, name: user.name },
        });

        // Update auth store
        useAuthStore.getState().login(token, user);

        // Success message
        toast.success(`Successfully logged in as ${user.name} (${user.role})`);

        // Reset form
        resetForm();

        // Add a small delay to ensure state is updated before navigation
        setTimeout(() => {
          // DIRECT NAVIGATION BASED ON ROLE
          if (user.role === "customer") {
            console.log("Customer login - redirecting to /");
            navigate("/");
          } else if (user.role === "agency" || user.role === "admin") {
            console.log(`${user.role} login - redirecting to /dashboard`);
            navigate("/dashboard");
          }
        }, 100);
      } else {
        // Handle error response
        const errorMessage =
          response.data.message || "Login failed. Please try again.";
        console.error("Login failed:", errorMessage);
        toast.error(errorMessage);

        // If coming from password change and login fails, provide more helpful message
        if (
          comingFromPasswordChange &&
          errorMessage.includes("Invalid Password")
        ) {
          toast.error(
            "There might be a delay in updating your password. Please try again in a few moments.",
            { duration: 5000 }
          );
        }
      }
    } catch (error: any) {
      console.error("Login error:", error);

      // Handle different types of errors
      if (error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        const errorMessage =
          error.response.data?.message ||
          `Error ${error.response.status}: Login failed`;
        console.error("Server error response:", error.response.data);
        toast.error(errorMessage);

        // Special handling for agency approval status
        if (state.role === "agency" && error.response.status === 403) {
          if (error.response.data?.message?.includes("pending approval")) {
            toast.error("Your agency account is pending approval from admin", {
              duration: 5000,
            });
          } else if (error.response.data?.message?.includes("rejected")) {
            toast.error("Your agency account has been rejected", {
              duration: 5000,
            });
          }
        }
      } else if (error.request) {
        // The request was made but no response was received
        console.error("No response received:", error.request);
        toast.error(
          "No response from server. Please check your internet connection."
        );
      } else {
        // Something happened in setting up the request that triggered an Error
        console.error("Request setup error:", error.message);
        toast.error("An unexpected error occurred. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  // ******** Handle Agency Approval ********
  const handleAgencyApproval = (user: any) => {
    if (user.approvalStatus === "pending") {
      toast.error("Your account is pending approval from admin.");
      return;
    }
    if (user.approvalStatus === "rejected") {
      toast.error(
        "Your account has been rejected. You may reapply after 1 month."
      );
      return;
    }
  };

  // ******** Handle Error ********
  const handleLoginError = (error: any) => {
    if (error.response) {
      toast.error(error.response?.data?.message || "Login failed");
    } else {
      toast.error("An unexpected error occurred");
    }
  };

  // ******** Reset Form ********
  const resetForm = () => {
    setState({ email: "", password: "", role: "customer" });
  };
  return (
    <div className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
      <div className="flex flex-wrap items-center">
        <div className="hidden w-full xl:flex xl:justify-center xl:items-center xl:w-1/2 min-h-screen">
          <div className="py-10 px-6 text-center">
            {/* Animated Logo with Glow & Hover Effect */}
            <motion.div
              initial={{ opacity: 0, y: -30, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
              whileHover={{ scale: 1.1 }}
              className="mb-6 flex justify-center"
            >
              <img
                src="/qadconnect.png"
                alt="Logo"
                className="h-28 w-28 drop-shadow-lg transition-all duration-300 hover:drop-shadow-2xl hover:brightness-110 rounded-xl"
              />
            </motion.div>

            {/* Animated Image with Smooth Entrance */}
            <motion.img
              src="https://flux-image.com/_next/image?url=https%3A%2F%2Fai.flux-image.com%2Fflux%2F614a9871-d8cd-4edc-9af9-6392f2f48ec2.jpg&w=3840&q=75"
              alt="Icon"
              width="350"
              height="350"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              className="rounded-lg shadow-xl border border-gray-200 hover:shadow-2xl transition-all duration-300"
            />
          </div>
        </div>

        <div className="w-full border-stroke dark:border-strokedark xl:w-1/2 xl:border-l-2">
          <div className="w-full p-4 sm:p-12.5 xl:p-17.5">
            <h2 className="mb-9 text-2xl font-bold text-black dark:text-white sm:text-title-xl2">
              Sign In to Q_AdConnect
            </h2>

            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label className="mb-2.5 block font-medium text-black dark:text-white">
                  Email
                </label>
                <div className="relative">
                  <input
                    type="email"
                    placeholder="Enter your email"
                    value={state.email}
                    onChange={(e) =>
                      setState({ ...state, email: e.target.value })
                    }
                    className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  />
                </div>
              </div>

              <div className="mb-6">
                <label className="mb-2.5 block font-medium text-black dark:text-white">
                  Password
                </label>
                <div className="relative">
                  <input
                    type="password"
                    placeholder="6+ Characters, 1 Capital letter"
                    value={state.password}
                    onChange={(e) =>
                      setState({ ...state, password: e.target.value })
                    }
                    className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary focus-visible:shadow-none dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
                  />
                </div>
              </div>

              <div className="mb-6">
                <label className="mb-2.5 block font-medium text-black dark:text-white">
                  Login As
                </label>
                <div className="flex items-center">
                  <label className="mr-4">
                    <input
                      type="radio"
                      name="role"
                      value="customer"
                      checked={state.role === "customer"}
                      onChange={() => handleRoleChange("customer")}
                      className="mr-2"
                    />
                    Customer
                  </label>
                  <label className="mr-4">
                    <input
                      type="radio"
                      name="role"
                      value="agency"
                      checked={state.role === "agency"}
                      onChange={() => handleRoleChange("agency")}
                      className="mr-2"
                    />
                    Agency
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="role"
                      value="admin"
                      checked={state.role === "admin"}
                      onChange={() => handleRoleChange("admin")}
                      className="mr-2"
                    />
                    Admin
                  </label>
                </div>
              </div>

              <div className="mb-5">
                <input
                  type="submit"
                  value="Sign In"
                  className="w-full cursor-pointer rounded-lg border border-primary bg-primary p-4 text-white transition hover:bg-opacity-90"
                />
              </div>
              <div className="flex justify-center items-center mt-4">
                <button
                  onClick={handleRedirect}
                  className="text-blue-500 hover:text-blue-700 text-sm"
                >
                  Forgot your password?
                </button>
              </div>
              <div className="mt-6 text-center">
                <p>
                  Don’t have any account?{" "}
                  <Link to="/auth/signup" className="text-primary">
                    Sign Up
                  </Link>
                </p>
              </div>
              {/* Test links removed */}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
