import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import axios from "../../../axiosInstance";
import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { AiOutlineCalendar } from "react-icons/ai";
import Swal from "sweetalert2";
import { motion } from "framer-motion";

const CustomerForm: React.FC<{
  name: string;
  email: string;
  password: string;
  setName: React.Dispatch<React.SetStateAction<string>>;
  setEmail: React.Dispatch<React.SetStateAction<string>>;
  setPassword: React.Dispatch<React.SetStateAction<string>>;
}> = ({ name, email, password, setName, setEmail, setPassword }) => (
  <>
    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Name
      </label>
      <input
        type="text"
        placeholder="Enter your full name"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
    </div>

    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Email
      </label>
      <input
        type="email"
        placeholder="Enter your email"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
    </div>

    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Password
      </label>
      <input
        type="password"
        placeholder="Enter your password"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
    </div>
  </>
);

const AgencyForm: React.FC<{
  agencyName: string;
  ntnNumber: string;
  email: string;
  password: string;

  address: string;
  city: string;
  agencyImage: File | null;
  agencyDoc: File[] | null;
  setEmail: React.Dispatch<React.SetStateAction<string>>;
  setPassword: React.Dispatch<React.SetStateAction<string>>;
  setAgencyName: React.Dispatch<React.SetStateAction<string>>;
  setNtnNumber: React.Dispatch<React.SetStateAction<string>>;
  setAddress: React.Dispatch<React.SetStateAction<string>>;
  setCity: React.Dispatch<React.SetStateAction<string>>;
  handleFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleMultipleFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}> = ({
  agencyName,
  ntnNumber,
  address,
  city,
  agencyImage,
  agencyDoc,
  setAgencyName,
  setNtnNumber,
  setAddress,
  setCity,
  handleFileChange,
  handleMultipleFileChange,
  setPassword,
  setEmail,
  email,
  password,
}) => (
  <>
    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Agency Name
      </label>
      <input
        type="text"
        placeholder="Enter your agency name"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={agencyName}
        onChange={(e) => setAgencyName(e.target.value)}
      />
    </div>

    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Email
      </label>
      <input
        type="email"
        placeholder="Enter your email"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
    </div>

    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Password
      </label>
      <input
        type="password"
        placeholder="Enter your password"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
    </div>

    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        License Number
      </label>
      <input
        type="text"
        placeholder="Enter your license number"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={ntnNumber}
        onChange={(e) => setNtnNumber(e.target.value)}
      />
    </div>

    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Address
      </label>
      <input
        type="text"
        placeholder="Enter your address"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />
    </div>

    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        City
      </label>
      <input
        type="text"
        placeholder="Enter your city"
        className="w-full rounded-lg border border-stroke bg-transparent py-4 pl-6 pr-10 text-black outline-none focus:border-primary dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
    </div>
    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Agency Profile Image
      </label>
      <input
        type="file"
        accept="image/*"
        className="w-full"
        onChange={handleFileChange}
      />
    </div>

    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Agency Documents
      </label>
      <input
        type="file"
        accept=".doc,.docx,.pdf,image/*"
        className="w-full"
        multiple
        onChange={handleMultipleFileChange}
      />
    </div>
    <div className="mb-4">
      <label className="mb-2.5 block font-medium text-black dark:text-white">
        Add Card Number
      </label>
      <div className="border border-primary rounded-lg p-4">
        <CardElement />
      </div>
    </div>
  </>
);

const SignUp: React.FC = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"customer" | "agency" | "admin">("customer");
  const [ntnNumber, setNtnNumber] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [agencyImage, setAgencyImage] = useState<File | null>(null);
  const [agencyDoc, setAgencyDoc] = useState<File[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [priceId, setPriceId] = useState<any>("price_1PiD0dEhtIH6ECKALsZBUoSa");
  const [subscription, setSubscription] = useState<"monthly" | "yearly">(
    "monthly"
  );

  const stripe = useStripe();
  const elements = useElements();

  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => {
      toast.success("Welcome to Q_AdConnect! Create your account now");
    }, 1000);
  }, []);

  const handleRoleChange = (newRole: "customer" | "agency" | "admin") => {
    setRole(newRole);
    toast.success(`Role switched to ${newRole.toUpperCase()}`);
  };

  const handleSubscriptionChange = (newSubscription: "monthly" | "yearly") => {
    setSubscription(newSubscription);
    toast.success(`Subscription set to ${newSubscription.toUpperCase()}`);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setAgencyImage(e.target.files[0]);
    }
  };

  const handleMultipleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setAgencyDoc(Array.from(e.target.files));
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Validate required fields
    const missingFields = [];
    if (!name) missingFields.push("Name");
    if (!email) missingFields.push("Email");
    if (!password) missingFields.push("Password");
    if (role === "agency") {
      if (!name) missingFields.push("Agency Name");
      if (!ntnNumber) missingFields.push("NTN Number");
      if (!address) missingFields.push("Address");
      if (!city) missingFields.push("City");
    }

    if (missingFields.length > 0) {
      toast.error(
        `Please fill in all required fields: ${missingFields.join(", ")}.`
      );
      return;
    }

    // Validate agency-specific fields
    if (role === "agency") {
      if (!agencyImage) {
        toast.error("Agency image is required.");
        return;
      }

      if (!agencyDoc || agencyDoc.length === 0 || agencyDoc.length > 5) {
        toast.error("Please upload between 1 to 5 agency documents.");
        return;
      }

      // Ensure stripe and elements are available
      if (!stripe || !elements) {
        toast.error("Stripe is not properly initialized.");
        return;
      }

      const cardElement = elements.getElement(CardElement);
      if (!cardElement) {
        toast.error("Card element not found.");
        return;
      }

      const { paymentMethod, error }: any = await stripe.createPaymentMethod({
        type: "card",
        card: cardElement,
      });

      if (error) {
        console.error(error);
        toast.error(error?.message);
        return;
      }

      // Prepare form data for agency
      const formData = new FormData();
      formData.append("name", name);
      formData.append("email", email);
      formData.append("password", password);
      formData.append("role", role);
      formData.append("subscription", subscription);
      formData.append("priceId", priceId);
      formData.append("paymentMethodId", paymentMethod.id);
      formData.append("ntnNumber", ntnNumber);
      formData.append("address", address);
      formData.append("city", city);
      formData.append("agencyName", name);
      formData.append("amount", "500");

      if (agencyImage) formData.append("agencyImage", agencyImage);
      if (agencyDoc) {
        agencyDoc.forEach((doc) => {
          formData.append("agencyDoc", doc);
        });
      }

      // Submit form data
      try {
        setLoading(true);
        const response = await axios.post("/api/auth/signup", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });

        if (response.data.status === 1) {
          Swal.fire({
            title: "Account created and Subscription successfully",
            text: "Please wait for admin approval.",
            icon: "success",
            draggable: true,
          }).then(() => {
            navigate("/auth/signin");
          });
        } else {
          toast.error(response.data?.message);
        }
      } catch (error: any) {
        toast.error(error?.message || error.response?.data?.message);
      } finally {
        setLoading(false);
      }
    } else {
      // Prepare form data for non-agency roles
      const formData = new FormData();
      formData.append("name", name);
      formData.append("email", email);
      formData.append("password", password);
      formData.append("role", role);
      formData.append("subscription", subscription);

      // Submit form data
      try {
        setLoading(true);
        const response = await axios.post("/api/auth/signup", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });

        if (response.data.status === 1) {
          Swal.fire({
            title: "Account created successfully!",
            icon: "success",
            draggable: true,
          }).then(() => {
            navigate("/auth/signin");
          });
        } else {
          toast.error(response.data?.message);
        }
      } catch (error: any) {
        toast.error(error?.message || error.response?.data?.message);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
      <div className="flex flex-wrap items-center">
        <div className="hidden w-full xl:flex xl:justify-center xl:items-center xl:w-1/2 min-h-screen">
          <div className="py-10 px-6 text-center">
            {/* Animated Logo with Glow & Hover Effect */}
            <motion.div
              initial={{ opacity: 0, y: -30, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
              whileHover={{ scale: 1.1 }}
              className="mb-6 flex justify-center"
            >
              <img
                src="/qadconnect.png"
                alt="Logo"
                className="h-28 w-28 drop-shadow-lg transition-all duration-300 hover:drop-shadow-2xl hover:brightness-110 rounded-xl"
              />
            </motion.div>

            {/* Animated Image with Smooth Entrance */}
            <motion.img
              src="https://flux-image.com/_next/image?url=https%3A%2F%2Fai.flux-image.com%2Fflux%2F614a9871-d8cd-4edc-9af9-6392f2f48ec2.jpg&w=3840&q=75"
              alt="Icon"
              width="350"
              height="350"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              className="rounded-lg shadow-xl border border-gray-200 hover:shadow-2xl transition-all duration-300"
            />
          </div>
        </div>

        <div className="w-full border-stroke dark:border-strokedark xl:w-1/2 xl:border-l-2">
          <div className="w-full p-4 sm:p-12.5 xl:p-17.5">
            <h2 className="mb-9 text-2xl font-bold text-black dark:text-white sm:text-title-xl2">
              Sign Up to Q_AdConnect
            </h2>

            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <label className="mb-2.5 block font-medium text-black dark:text-white">
                  Sign Up As
                </label>
                <div className="flex items-center">
                  <label className="mr-4">
                    <input
                      type="radio"
                      name="role"
                      value="customer"
                      checked={role === "customer"}
                      onChange={() => handleRoleChange("customer")}
                      className="mr-2"
                    />
                    Customer
                  </label>
                  <label className="mr-4">
                    <input
                      type="radio"
                      name="role"
                      value="agency"
                      checked={role === "agency"}
                      onChange={() => handleRoleChange("agency")}
                      className="mr-2"
                    />
                    Agency
                  </label>
                </div>
              </div>

              {role === "agency" && (
                <div className="mb-6">
                  <label className="mb-2.5 block font-medium text-black dark:text-white">
                    Subscription Plan
                  </label>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center p-4 border rounded-lg shadow-md hover:shadow-lg transition-shadow">
                      <input
                        type="radio"
                        name="subscription"
                        value="monthly"
                        checked={subscription === "monthly"}
                        onChange={() => handleSubscriptionChange("monthly")}
                        className="mr-2"
                      />
                      <div className="flex items-center">
                        <span className="text-primary mr-2">
                          <AiOutlineCalendar />
                        </span>
                        <span>Monthly (PRK 1000)</span>
                      </div>
                    </div>
                    <div className="flex items-center p-4 border rounded-lg shadow-md hover:shadow-lg transition-shadow">
                      <input
                        type="radio"
                        name="subscription"
                        value="yearly"
                        checked={subscription === "yearly"}
                        onChange={() => handleSubscriptionChange("yearly")}
                        className="mr-2"
                      />
                      <div className="flex items-center">
                        <span className="text-primary mr-2">
                          <AiOutlineCalendar />
                        </span>
                        <span>Yearly (PRK 20,000)</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {role === "customer" && (
                <CustomerForm
                  name={name}
                  email={email}
                  password={password}
                  setName={setName}
                  setEmail={setEmail}
                  setPassword={setPassword}
                />
              )}

              {role === "agency" && (
                <AgencyForm
                  agencyName={name}
                  ntnNumber={ntnNumber}
                  address={address}
                  email={email}
                  password={password}
                  setEmail={setEmail}
                  setPassword={setPassword}
                  city={city}
                  agencyImage={agencyImage}
                  agencyDoc={agencyDoc}
                  setAgencyName={setName}
                  setNtnNumber={setNtnNumber}
                  setAddress={setAddress}
                  setCity={setCity}
                  handleFileChange={handleFileChange}
                  handleMultipleFileChange={handleMultipleFileChange}
                />
              )}

              <div className="mb-5">
                <input
                  type="submit"
                  value={loading ? "Creating account..." : "Create account"}
                  className={`w-full cursor-pointer rounded-lg border border-primary bg-primary p-4 text-white transition hover:bg-opacity-90 ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
                  disabled={loading}
                />
              </div>

              <div className="mt-6 text-center">
                <p>
                  Already have an account?{" "}
                  <Link to="/auth/signin" className="text-primary">
                    Sign in
                  </Link>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
