import React, { useState, useEffect, useCallback } from "react";
import { useAuthStore } from "../../../stores/authStore";
import axios from "../../../axiosInstance";
import { toast } from "react-hot-toast";
import { motion } from "framer-motion";
import Breadcrumb from "../../components/Breadcrumbs/Breadcrumb";
import {
  FaUser,
  FaEnvelope,
  FaMapMarkerAlt,
  FaCity,
  FaIdCard,
  FaBuilding,
  FaEdit,
  FaCamera,
  FaChartLine,
  FaBullhorn,
  FaCalendarAlt,
  FaMoneyBillWave,
  FaCheckCircle,
  FaHourglassHalf,
  FaTimesCircle,
  FaFileAlt,
  FaPhone,
  FaChevronRight,
  FaSync,
} from "react-icons/fa";

// Define types
interface Billboard {
  _id: string;
  title: string;
  description: string;
  location: string;
  city: string;
  area: string;
  price: number;
  status: string;
  imageUrl: string;
}

interface Booking {
  _id: string;
  billboardId: {
    _id: string;
    title: string;
    location: string;
    imageUrl: string;
  };
  customerId: {
    _id: string;
    name: string;
    email: string;
  };
  startDate: string;
  endDate: string;
  totalAmount: number;
  status: string;
  adImageUrls: string[];
  createdAt: string;
}

interface AgencyStats {
  totalBillboards: number;
  activeBillboards: number;
  totalBookings: number;
  pendingBookings: number;
  totalRevenue: number;
  recentBookings: Booking[];
}

// We're using user.subscriptionPlan and user.subscriptionStatus directly from the user object

const AgencyProfilePage: React.FC = () => {
  const { user, token, setAuth } = useAuthStore();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<AgencyStats>({
    totalBillboards: 0,
    activeBillboards: 0,
    totalBookings: 0,
    pendingBookings: 0,
    totalRevenue: 0,
    recentBookings: [],
  });
  const [billboards, setBillboards] = useState<Billboard[]>([]);
  // We're using user.subscriptionPlan and user.subscriptionStatus directly
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [profileForm, setProfileForm] = useState({
    name: user?.name || "",
    agencyName: user?.agencyName || "",
    bio: user?.bio || "",
    phone: user?.phone || "",
    address: user?.address || "",
    city: user?.city || "",
    ntnNumber: user?.ntnNumber || "",
  });
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(
    null
  );
  const [coverImage, setCoverImage] = useState<File | null>(null);
  const [coverImagePreview, setCoverImagePreview] = useState<string | null>(
    null
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sectionLoading, setSectionLoading] = useState({
    billboards: false,
    bookings: false,
    subscription: false,
  });

  // Get base URL for images
  const getBaseUrl = () => {
    return import.meta.env.VITE_API_URL || "http://localhost:4000";
  };

  // Get agency image URL
  const getAgencyImageUrl = () => {
    if (profileImagePreview) return profileImagePreview;
    if (user?.agencyImage) {
      // Check if the path already includes the base URL
      if (user.agencyImage.startsWith("http")) {
        return user.agencyImage;
      }
      // Try both paths to ensure compatibility
      return `${getBaseUrl()}/files/${user.agencyImage}`;
    }
    return "/images/user/user-01.png";
  };

  // Get cover image URL
  const getCoverImageUrl = () => {
    if (coverImagePreview) return coverImagePreview;
    if (user?.coverImage) {
      // Check if the path already includes the base URL
      if (user.coverImage.startsWith("http")) {
        return user.coverImage;
      }
      // Try both paths to ensure compatibility
      return `${getBaseUrl()}/files/${user.coverImage}`;
    }
    return null; // Will use gradient background if no cover image
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-PK", {
      style: "currency",
      currency: "PKR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // Fetch agency data
  const fetchAgencyData = useCallback(
    async (showRefreshIndicator = false) => {
      if (!user || !token) return;

      try {
        if (showRefreshIndicator) {
          setRefreshing(true);
        } else {
          setLoading(true);
        }

        // Fetch latest user data
        const userResponse = await axios.get("/api/user/me", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (userResponse.data.status === 1 && userResponse.data.user) {
          // Update user in auth store to ensure we have the latest data
          setAuth(userResponse.data.user, token);
        }

        // Fetch billboards
        setSectionLoading((prev) => ({ ...prev, billboards: true }));
        let allBillboards = [];
        try {
          const billboardsResponse = await axios.get("/api/billboard/list", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
            timeout: 15000, // 15 seconds timeout
          });
          allBillboards = billboardsResponse.data.data || [];
        } catch (billboardError) {
          console.error("Error fetching billboards:", billboardError);
        }

        // Fetch bookings
        setSectionLoading((prev) => ({ ...prev, bookings: true }));
        let allBookings = [];
        try {
          const bookingsResponse = await axios.get("/api/booking/agency-view", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
            timeout: 15000, // 15 seconds timeout
          });
          allBookings = bookingsResponse.data.data || [];
        } catch (bookingError) {
          console.error("Error fetching bookings:", bookingError);
        }

        // Use subscription data from user object
        setSectionLoading((prev) => ({ ...prev, subscription: true }));
        // We don't have a subscription endpoint, so we'll use the data from the user object

        // Set billboards in state
        setBillboards(allBillboards.slice(0, 4));

        // Calculate revenue
        const revenue = allBookings.reduce(
          (total: number, booking: any) => total + (booking.totalAmount || 0),
          0
        );

        // Set stats
        setStats({
          totalBillboards: allBillboards.length,
          activeBillboards: allBillboards.filter(
            (b: any) => b.status === "active"
          ).length,
          totalBookings: allBookings.length,
          pendingBookings: allBookings.filter(
            (b: any) => b.status === "content_pending"
          ).length,
          totalRevenue: revenue,
          recentBookings: allBookings.slice(0, 3),
        });
      } catch (error: any) {
        console.error("Error fetching agency data:", error);

        // Provide more specific error messages based on the error type
        if (error.code === "ECONNABORTED") {
          toast.error(
            "Request timed out. Please check your connection and try again."
          );
        } else if (error.response?.status === 404) {
          toast.error(
            "Some data could not be found. Profile may be incomplete."
          );
        } else {
          toast.error(
            "Failed to load agency data: " + (error.message || "Unknown error")
          );
        }

        // Set default values for stats if they couldn't be loaded
        setStats({
          totalBillboards: 0,
          activeBillboards: 0,
          totalBookings: 0,
          pendingBookings: 0,
          totalRevenue: 0,
          recentBookings: [],
        });

        setBillboards([]);
      } finally {
        // Make sure to reset all loading states
        setLoading(false);
        setRefreshing(false);
        setSectionLoading({
          billboards: false,
          bookings: false,
          subscription: false,
        });
      }
    },
    [user, token, setAuth]
  );

  // Update profile form when user data changes
  useEffect(() => {
    if (user) {
      setProfileForm({
        name: user.name || "",
        agencyName: user.agencyName || "",
        bio: user.bio || "",
        phone: user.phone || "",
        address: user.address || "",
        city: user.city || "",
        ntnNumber: user.ntnNumber || "",
      });

      if (user.agencyImage) {
        setProfileImagePreview(`${getBaseUrl()}/files/${user.agencyImage}`);
      }

      if (user.coverImage) {
        setCoverImagePreview(`${getBaseUrl()}/files/${user.coverImage}`);
      }
    }
  }, [user]);

  // Initial data fetch - use a ref to prevent multiple calls
  const dataFetchedRef = React.useRef(false);

  useEffect(() => {
    if (token && user?.role === "agency" && !dataFetchedRef.current) {
      dataFetchedRef.current = true;
      fetchAgencyData();
    }
  }, [token, user, fetchAgencyData]);

  // Handle profile image change
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setProfileImage(file);
      setProfileImagePreview(URL.createObjectURL(file));
    }
  };

  // Handle cover image change
  const handleCoverImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setCoverImage(file);
      setCoverImagePreview(URL.createObjectURL(file));
    }
  };

  // Handle profile form change
  const handleProfileChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setProfileForm((prev) => ({ ...prev, [name]: value }));
  };

  // Handle profile update
  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !token) return;

    try {
      setIsSubmitting(true);
      const formData = new FormData();

      // Append form fields
      Object.entries(profileForm).forEach(([key, value]) => {
        formData.append(key, value);
      });

      // Append profile image if changed
      if (profileImage) {
        formData.append("agencyImage", profileImage);
      }

      // Append cover image if changed
      if (coverImage) {
        formData.append("coverImage", coverImage);
      }

      // Update profile - use the correct endpoint
      const response = await axios.put(
        `/api/user/update/${user._id}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data.status === 1) {
        toast.success("Profile updated successfully");
        setIsEditModalOpen(false);

        // Update user in auth store
        setAuth(response.data.user, token);
      } else {
        throw new Error(response.data.message || "Failed to update profile");
      }
    } catch (error: any) {
      console.error("Error updating profile:", error);
      toast.error(
        error.response?.data?.message ||
          error.message ||
          "Failed to update profile"
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle refresh data
  const handleRefresh = () => {
    dataFetchedRef.current = false; // Reset the ref so we can fetch again
    fetchAgencyData(true);
  };

  // Loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <>
      <Breadcrumb pageName="Agency Profile" />

      {/* Refresh Button */}
      <div className="flex justify-end mb-4">
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className="flex items-center gap-2 px-4 py-2 bg-white rounded-md border border-stroke shadow-sm hover:bg-gray-50 transition-colors"
        >
          {refreshing ? (
            <FaSync className="animate-spin text-indigo-600" />
          ) : (
            <FaSync className="text-indigo-600" />
          )}
          <span>{refreshing ? "Refreshing..." : "Refresh Data"}</span>
        </button>
      </div>

      {/* Profile Header */}
      <div className="overflow-hidden rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
        <div className="relative h-40 md:h-60 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500">
          {/* Cover Image */}
          {getCoverImageUrl() && (
            <img
              src={getCoverImageUrl() || ""}
              alt="Cover"
              className="w-full h-full object-cover"
            />
          )}

          {/* Edit Cover Button */}
          <label className="absolute top-4 right-4 bg-white bg-opacity-20 backdrop-blur-sm p-2 rounded-full text-white hover:bg-opacity-30 transition-all cursor-pointer">
            <FaCamera />
            <input
              type="file"
              className="hidden"
              accept="image/*"
              onChange={handleCoverImageChange}
            />
          </label>

          {/* Animated Particles */}
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(10)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute rounded-full bg-white bg-opacity-20"
                style={{
                  width: Math.random() * 40 + 10,
                  height: Math.random() * 40 + 10,
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={{
                  x: [0, Math.random() * 100 - 50],
                  y: [0, Math.random() * 100 - 50],
                  opacity: [0.3, 0.8, 0.3],
                }}
                transition={{
                  duration: 5 + Math.random() * 5,
                  repeat: Infinity,
                  repeatType: "reverse",
                }}
              />
            ))}
          </div>
        </div>

        <div className="px-4 pb-6 text-center lg:pb-8 xl:pb-11.5">
          <div className="relative z-30 mx-auto -mt-16 h-32 w-32 rounded-full bg-white p-1 shadow-lg">
            <div className="relative h-full w-full rounded-full overflow-hidden">
              <img
                src={getAgencyImageUrl()}
                alt={user?.name}
                className="h-full w-full object-cover"
                onError={(e) => {
                  e.currentTarget.src = "/images/user/user-01.png";
                }}
              />
              <label className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 opacity-0 hover:opacity-100 cursor-pointer transition-opacity">
                <FaCamera className="text-white text-xl" />
                <input
                  type="file"
                  className="hidden"
                  accept="image/*"
                  onChange={handleImageChange}
                />
              </label>
            </div>
          </div>

          <div className="mt-4">
            <h3 className="mb-1.5 text-2xl font-semibold text-black dark:text-white">
              {user?.agencyName || user?.name}
            </h3>
            <p className="font-medium text-indigo-500">{user?.role}</p>

            {user?.approvalStatus && (
              <div className="mt-2 flex justify-center">
                <span
                  className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium
                  ${
                    user.approvalStatus === "approved"
                      ? "bg-green-100 text-green-800"
                      : user.approvalStatus === "pending"
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-red-100 text-red-800"
                  }`}
                >
                  {user.approvalStatus === "approved" ? (
                    <>
                      <FaCheckCircle className="mr-1" /> Approved
                    </>
                  ) : user.approvalStatus === "pending" ? (
                    <>
                      <FaHourglassHalf className="mr-1" /> Pending Approval
                    </>
                  ) : (
                    <>
                      <FaTimesCircle className="mr-1" /> Rejected
                    </>
                  )}
                </span>
              </div>
            )}

            <div className="mx-auto mt-4 max-w-xl">
              <p className="text-gray-500">
                {user?.bio ||
                  "No bio available. Click Edit Profile to add your agency description."}
              </p>
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3.5 px-3">
              <button
                onClick={() => setIsEditModalOpen(true)}
                className="inline-flex items-center justify-center gap-2.5 rounded-full bg-indigo-600 px-6 py-3 text-center font-medium text-white hover:bg-opacity-90 lg:px-8 xl:px-10"
              >
                <FaEdit />
                Edit Profile
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="mt-7.5 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="rounded-sm border border-stroke bg-white px-7.5 py-6 shadow-default dark:border-strokedark dark:bg-boxdark"
        >
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-medium">Total Billboards</span>
              <h4 className="text-title-md font-bold text-black dark:text-white mt-1">
                {stats.totalBillboards}
              </h4>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-indigo-100">
              <FaBullhorn className="text-indigo-600 text-xl" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <span className="text-sm font-medium text-green-500">
              {stats.activeBillboards} Active
            </span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="rounded-sm border border-stroke bg-white px-7.5 py-6 shadow-default dark:border-strokedark dark:bg-boxdark"
        >
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-medium">Total Bookings</span>
              <h4 className="text-title-md font-bold text-black dark:text-white mt-1">
                {stats.totalBookings}
              </h4>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-purple-100">
              <FaCalendarAlt className="text-purple-600 text-xl" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <span className="text-sm font-medium text-amber-500">
              {stats.pendingBookings} Pending
            </span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="rounded-sm border border-stroke bg-white px-7.5 py-6 shadow-default dark:border-strokedark dark:bg-boxdark"
        >
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-medium">Subscription</span>
              <h4 className="text-title-md font-bold text-black dark:text-white mt-1">
                {user?.subscriptionPlan || "Standard"}
              </h4>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
              <FaChartLine className="text-blue-600 text-xl" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <span
              className={`text-sm font-medium ${
                user?.subscriptionStatus === "active"
                  ? "text-green-500"
                  : user?.subscriptionStatus === "pending"
                    ? "text-amber-500"
                    : "text-red-500"
              }`}
            >
              {user?.subscriptionStatus || "Inactive"}
              {user?.subscriptionStatus === "active" ? " (Active)" : ""}
            </span>
          </div>
        </motion.div>
      </div>

      {/* Agency Info & Recent Bookings */}
      <div className="mt-7.5 grid grid-cols-1 gap-5 xl:grid-cols-3">
        {/* Agency Info */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
          className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark xl:col-span-1"
        >
          <div className="border-b border-stroke px-7 py-4 dark:border-strokedark">
            <h3 className="font-medium text-black dark:text-white">
              Agency Information
            </h3>
          </div>
          <div className="p-7">
            <div className="mb-5 flex items-center gap-5">
              <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                <FaBuilding className="text-indigo-600" />
              </div>
              <div>
                <h5 className="text-sm font-medium text-gray-500">
                  Agency Name
                </h5>
                <p className="text-base font-medium text-black dark:text-white">
                  {user?.agencyName || "Not specified"}
                </p>
              </div>
            </div>

            <div className="mb-5 flex items-center gap-5">
              <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                <FaUser className="text-indigo-600" />
              </div>
              <div>
                <h5 className="text-sm font-medium text-gray-500">
                  Owner Name
                </h5>
                <p className="text-base font-medium text-black dark:text-white">
                  {user?.name}
                </p>
              </div>
            </div>

            <div className="mb-5 flex items-center gap-5">
              <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                <FaEnvelope className="text-indigo-600" />
              </div>
              <div>
                <h5 className="text-sm font-medium text-gray-500">Email</h5>
                <p className="text-base font-medium text-black dark:text-white">
                  {user?.email}
                </p>
              </div>
            </div>

            <div className="mb-5 flex items-center gap-5">
              <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                <FaPhone className="text-indigo-600" />
              </div>
              <div>
                <h5 className="text-sm font-medium text-gray-500">Phone</h5>
                <p className="text-base font-medium text-black dark:text-white">
                  {user?.phone || "Not specified"}
                </p>
              </div>
            </div>

            <div className="mb-5 flex items-center gap-5">
              <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                <FaIdCard className="text-indigo-600" />
              </div>
              <div>
                <h5 className="text-sm font-medium text-gray-500">
                  NTN Number
                </h5>
                <p className="text-base font-medium text-black dark:text-white">
                  {user?.ntnNumber || "Not specified"}
                </p>
              </div>
            </div>

            <div className="mb-5 flex items-center gap-5">
              <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                <FaMapMarkerAlt className="text-indigo-600" />
              </div>
              <div>
                <h5 className="text-sm font-medium text-gray-500">Address</h5>
                <p className="text-base font-medium text-black dark:text-white">
                  {user?.address || "Not specified"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-5">
              <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                <FaCity className="text-indigo-600" />
              </div>
              <div>
                <h5 className="text-sm font-medium text-gray-500">City</h5>
                <p className="text-base font-medium text-black dark:text-white">
                  {user?.city || "Not specified"}
                </p>
              </div>
            </div>

            {user?.agencyDoc && user.agencyDoc.length > 0 && (
              <div className="mt-8">
                <h5 className="mb-3 text-sm font-medium text-gray-500">
                  Agency Documents
                </h5>
                <div className="flex flex-wrap gap-3">
                  {user.agencyDoc?.map((doc: string, index: number) => (
                    <a
                      key={index}
                      href={`${getBaseUrl()}/files/${doc}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 rounded-md bg-gray-100 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-200"
                    >
                      <FaFileAlt />
                      Document {index + 1}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Recent Bookings */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
          className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark xl:col-span-2"
        >
          <div className="border-b border-stroke px-7 py-4 dark:border-strokedark">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-black dark:text-white">
                Recent Bookings
              </h3>
              {sectionLoading.bookings && (
                <div className="animate-spin h-5 w-5 border-t-2 border-b-2 border-indigo-500 rounded-full"></div>
              )}
            </div>
          </div>
          <div className="p-7">
            {stats.recentBookings && stats.recentBookings.length > 0 ? (
              <div className="flex flex-col gap-5">
                {stats.recentBookings.map((booking) => (
                  <div
                    key={booking._id}
                    className="rounded-sm border border-stroke bg-gray-50 p-4 dark:border-strokedark dark:bg-boxdark"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <h5 className="text-base font-medium text-black dark:text-white">
                          {booking.billboardId?.title || "Billboard"}
                        </h5>
                        <p className="text-sm text-gray-500">
                          {booking.billboardId?.location || "Unknown location"}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-black dark:text-white">
                          {formatCurrency(booking.totalAmount || 0)}
                        </p>
                        <span
                          className={`text-xs ${
                            booking.status === "active"
                              ? "text-green-500"
                              : booking.status === "content_pending"
                                ? "text-amber-500"
                                : booking.status === "content_rejected"
                                  ? "text-red-500"
                                  : "text-blue-500"
                          }`}
                        >
                          {booking.status.replace("_", " ")}
                        </span>
                      </div>
                    </div>
                    <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
                      <span>
                        {formatDate(booking.startDate)} -{" "}
                        {formatDate(booking.endDate)}
                      </span>
                      <span>
                        Customer: {booking.customerId?.name || "Unknown"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <div className="mb-3 h-14 w-14 rounded-full bg-gray-100 flex items-center justify-center">
                  <FaCalendarAlt className="text-gray-400 text-xl" />
                </div>
                <h5 className="mb-1 text-base font-medium text-gray-700">
                  No Recent Bookings
                </h5>
                <p className="text-sm text-gray-500">
                  Your recent bookings will appear here
                </p>
              </div>
            )}

            {stats.recentBookings && stats.recentBookings.length > 0 && (
              <div className="mt-5 text-center">
                <a
                  href="/dashboard/agency-bookings"
                  className="inline-flex items-center text-sm font-medium text-indigo-600 hover:underline"
                >
                  View All Bookings
                  <FaChevronRight className="ml-1 text-xs" />
                </a>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Featured Billboards */}
      <div className="mt-7.5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark"
        >
          <div className="border-b border-stroke px-7 py-4 dark:border-strokedark">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-black dark:text-white">
                Your Billboards
              </h3>
              {sectionLoading.billboards && (
                <div className="animate-spin h-5 w-5 border-t-2 border-b-2 border-indigo-500 rounded-full"></div>
              )}
            </div>
          </div>
          <div className="p-7">
            {billboards && billboards.length > 0 ? (
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                {billboards.map((billboard) => (
                  <div
                    key={billboard._id}
                    className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-all hover:shadow-md"
                  >
                    <div className="relative h-40 overflow-hidden">
                      <img
                        src={
                          billboard.imageUrl.startsWith("http")
                            ? billboard.imageUrl
                            : `${getBaseUrl()}/${billboard.imageUrl}`
                        }
                        alt={billboard.title}
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src =
                            "/images/billboard-placeholder.jpg";
                        }}
                      />
                      <div className="absolute top-2 right-2">
                        <span
                          className={`inline-block rounded-full px-2 py-1 text-xs font-medium ${
                            billboard.status === "active"
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {billboard.status}
                        </span>
                      </div>
                    </div>
                    <div className="p-4">
                      <h5 className="mb-1 text-base font-medium text-black dark:text-white truncate">
                        {billboard.title}
                      </h5>
                      <p className="mb-2 text-sm text-gray-500 truncate">
                        {billboard.location}, {billboard.city}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-base font-medium text-black dark:text-white">
                          {formatCurrency(billboard.price || 0)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <div className="mb-3 h-14 w-14 rounded-full bg-gray-100 flex items-center justify-center">
                  <FaBullhorn className="text-gray-400 text-xl" />
                </div>
                <h5 className="mb-1 text-base font-medium text-gray-700">
                  No Billboards
                </h5>
                <p className="text-sm text-gray-500">
                  You haven't added any billboards yet
                </p>
                <a
                  href="/dashboard/billboards/add"
                  className="mt-4 inline-flex items-center justify-center gap-2 rounded-md bg-indigo-600 px-4 py-2 text-center text-sm font-medium text-white hover:bg-opacity-90"
                >
                  <FaBullhorn className="text-sm" />
                  Add Your First Billboard
                </a>
              </div>
            )}

            {billboards && billboards.length > 0 && (
              <div className="mt-7 text-center">
                <a
                  href="/dashboard/billboard"
                  className="inline-flex items-center justify-center gap-2.5 rounded-md bg-indigo-600 px-6 py-3 text-center font-medium text-white hover:bg-opacity-90"
                >
                  View All Billboards
                </a>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black bg-opacity-70 backdrop-blur-sm p-4 overflow-y-auto">
          <div
            className="relative w-full max-w-xl rounded-lg bg-white shadow-2xl dark:bg-boxdark my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 z-10 bg-white dark:bg-boxdark rounded-t-lg border-b border-stroke dark:border-strokedark">
              <div className="flex items-center justify-between p-4 md:p-6">
                <h3 className="text-xl font-semibold text-black dark:text-white">
                  Edit Agency Profile
                </h3>
                <button
                  onClick={() => setIsEditModalOpen(false)}
                  className="text-gray-500 hover:text-gray-700 transition-colors"
                  aria-label="Close modal"
                >
                  <svg
                    className="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M6 18L18 6M6 6l12 12"
                    ></path>
                  </svg>
                </button>
              </div>
            </div>

            <div className="max-h-[calc(100vh-150px)] overflow-y-auto p-4 md:p-6">
              <form onSubmit={handleProfileUpdate}>
                {/* Profile Image */}
                <div className="mb-6 flex flex-col items-center">
                  <div className="relative group flex-shrink-0">
                    <div className="w-32 h-32 md:w-36 md:h-36 rounded-full overflow-hidden border-2 border-indigo-100">
                      <img
                        src={profileImagePreview || getAgencyImageUrl()}
                        alt="Profile"
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src = "/images/user/user-01.png";
                        }}
                      />
                      <label className="absolute inset-0 flex cursor-pointer items-center justify-center bg-black bg-opacity-40 opacity-0 transition-opacity hover:opacity-100">
                        <FaCamera className="text-white" />
                        <input
                          type="file"
                          className="hidden"
                          accept="image/*"
                          onChange={handleImageChange}
                        />
                      </label>
                    </div>
                  </div>
                  <p className="mt-2 text-sm text-gray-500">
                    Click to change profile image
                  </p>
                </div>

                {/* Cover Image */}
                <div className="mb-6">
                  <label className="mb-2.5 block text-sm font-medium text-black dark:text-white">
                    Cover Image
                  </label>
                  <div className="relative h-32 w-full rounded-lg border-2 border-dashed border-gray-300 bg-gray-50 overflow-hidden">
                    {coverImagePreview ? (
                      <img
                        src={coverImagePreview}
                        alt="Cover Preview"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center">
                        <p className="text-sm text-gray-500">
                          Click to upload cover image
                        </p>
                      </div>
                    )}
                    <label className="absolute inset-0 flex cursor-pointer items-center justify-center bg-black bg-opacity-0 transition-opacity hover:bg-opacity-30">
                      <FaCamera className="text-white opacity-0 transition-opacity group-hover:opacity-100" />
                      <input
                        type="file"
                        className="hidden"
                        accept="image/*"
                        onChange={handleCoverImageChange}
                      />
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  {/* Name */}
                  <div className="mb-4">
                    <label
                      htmlFor="name"
                      className="mb-2.5 block text-sm font-medium text-black dark:text-white"
                    >
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={profileForm.name}
                      onChange={handleProfileChange}
                      required
                      className="w-full rounded-lg border border-stroke bg-transparent py-3 px-4 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-form-strokedark dark:bg-form-input dark:focus:border-primary"
                    />
                  </div>

                  {/* Agency Name */}
                  <div className="mb-4">
                    <label
                      htmlFor="agencyName"
                      className="mb-2.5 block text-sm font-medium text-black dark:text-white"
                    >
                      Agency Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="agencyName"
                      name="agencyName"
                      value={profileForm.agencyName}
                      onChange={handleProfileChange}
                      required
                      className="w-full rounded-lg border border-stroke bg-transparent py-3 px-4 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-form-strokedark dark:bg-form-input dark:focus:border-primary"
                    />
                  </div>

                  {/* Phone */}
                  <div className="mb-4">
                    <label
                      htmlFor="phone"
                      className="mb-2.5 block text-sm font-medium text-black dark:text-white"
                    >
                      Phone Number
                    </label>
                    <input
                      type="text"
                      id="phone"
                      name="phone"
                      value={profileForm.phone}
                      onChange={handleProfileChange}
                      placeholder="e.g., +92 300 1234567"
                      className="w-full rounded-lg border border-stroke bg-transparent py-3 px-4 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-form-strokedark dark:bg-form-input dark:focus:border-primary"
                    />
                  </div>

                  {/* NTN Number */}
                  <div className="mb-4">
                    <label
                      htmlFor="ntnNumber"
                      className="mb-2.5 block text-sm font-medium text-black dark:text-white"
                    >
                      NTN Number
                    </label>
                    <input
                      type="text"
                      id="ntnNumber"
                      name="ntnNumber"
                      value={profileForm.ntnNumber}
                      onChange={handleProfileChange}
                      placeholder="Enter NTN number"
                      className="w-full rounded-lg border border-stroke bg-transparent py-3 px-4 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-form-strokedark dark:bg-form-input dark:focus:border-primary"
                    />
                  </div>

                  {/* City */}
                  <div className="mb-4">
                    <label
                      htmlFor="city"
                      className="mb-2.5 block text-sm font-medium text-black dark:text-white"
                    >
                      City
                    </label>
                    <input
                      type="text"
                      id="city"
                      name="city"
                      value={profileForm.city}
                      onChange={handleProfileChange}
                      placeholder="e.g., Lahore, Karachi"
                      className="w-full rounded-lg border border-stroke bg-transparent py-3 px-4 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-form-strokedark dark:bg-form-input dark:focus:border-primary"
                    />
                  </div>

                  {/* Address */}
                  <div className="mb-4 sm:col-span-2">
                    <label
                      htmlFor="address"
                      className="mb-2.5 block text-sm font-medium text-black dark:text-white"
                    >
                      Address
                    </label>
                    <input
                      type="text"
                      id="address"
                      name="address"
                      value={profileForm.address}
                      onChange={handleProfileChange}
                      placeholder="Enter your full address"
                      className="w-full rounded-lg border border-stroke bg-transparent py-3 px-4 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-form-strokedark dark:bg-form-input dark:focus:border-primary"
                    />
                  </div>

                  {/* Bio */}
                  <div className="mb-4 sm:col-span-2">
                    <label
                      htmlFor="bio"
                      className="mb-2.5 block text-sm font-medium text-black dark:text-white"
                    >
                      Agency Bio
                    </label>
                    <textarea
                      id="bio"
                      name="bio"
                      rows={4}
                      value={profileForm.bio}
                      onChange={handleProfileChange}
                      className="w-full rounded-lg border border-stroke bg-transparent py-3 px-4 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-form-strokedark dark:bg-form-input dark:focus:border-primary"
                      placeholder="Tell us about your agency, services, and expertise..."
                    ></textarea>
                    <p className="mt-1 text-xs text-gray-500">
                      A good bio helps customers understand your agency better.
                    </p>
                  </div>
                </div>
              </form>
            </div>

            <div className="sticky bottom-0 z-10 bg-white dark:bg-boxdark rounded-b-lg border-t border-stroke dark:border-strokedark p-4 md:p-6">
              <div className="flex flex-col-reverse sm:flex-row items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="w-full sm:w-auto rounded-lg border border-stroke px-6 py-2.5 text-sm font-medium text-black hover:bg-gray-100 dark:border-strokedark dark:text-white dark:hover:bg-meta-4 transition-colors"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  onClick={handleProfileUpdate}
                  className="w-full sm:w-auto rounded-lg bg-indigo-600 px-6 py-2.5 text-sm font-medium text-white hover:bg-indigo-700 transition-colors flex items-center justify-center min-w-[120px]"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Saving...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AgencyProfilePage;
