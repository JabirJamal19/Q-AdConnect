export type ApprovalStatus = "pending" | "approved" | "rejected";
export type SubscriptionStatus = "active" | "inactive" | "pending";

export interface Agency {
  _id: string;
  name: string;
  email: string;
  role: "agency";
  agencyName?: string;
  ntnNumber?: string;
  address?: string;
  city?: string;
  approvalStatus: ApprovalStatus;
  agencyImage?: string;
  agencyDoc?: string[];
  status?: "active" | "inactive";
  stripeCustomerId?: string;
  subscriptionPlan?: string;
  amount?: string;
  subscriptionStatus?: SubscriptionStatus;
  createdAt?: string;
  updatedAt?: string;
}

export interface AgencySection {
  title: string;
  agencies: Agency[];
  bgColor: string;
  textColor: string;
}
