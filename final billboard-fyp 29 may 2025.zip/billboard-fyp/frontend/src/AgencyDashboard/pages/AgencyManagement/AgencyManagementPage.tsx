import React, { useEffect, useState, useMemo } from "react";
import axios from "../../../axiosInstance";
import { useAuthStore } from "../../../stores/authStore";
import toast from "react-hot-toast";
import { Agency, ApprovalStatus } from "./types";
import { AgencySection } from "./AgencySection";
import { EditAgencyForm } from "./EditAgencyForm";
import { Pagination } from "./Pagination";
import { STATUS_COLORS } from "./constants";

const AgencyManagementPage: React.FC = () => {
  // Page title
  const pageTitle = "Agency Management";
  const token = useAuthStore((state) => state.token);
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [editFormVisible, setEditFormVisible] = useState<boolean>(false);
  const [formData, setFormData] = useState<
    Partial<Agency> & { agencyImage?: File; agencyImageUrl?: string }
  >({});
  const [selectedAgency, setSelectedAgency] = useState<Agency | null>(null);
  const [agencyImage, setAgencyImage] = useState<File | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [statusFilter, setStatusFilter] = useState<ApprovalStatus | "all">(
    "all"
  );

  useEffect(() => {
    const fetchAgencies = async () => {
      try {
        setError(null);
        setLoading(true);
        if (!token) {
          setError("No token, authorization denied");
          setLoading(false);
          return;
        }

        console.log("Fetching agencies...");
        const response = await axios.get("/api/user/users?role=agency", {
          headers: { Authorization: `Bearer ${token}` },
        });
        console.log("API Response:", response.data);

        if (!response.data || !response.data.users) {
          throw new Error("Invalid API response format");
        }

        // Map the API response to match our Agency type
        const agencyData = response.data.users.map((user: any) => {
          // Log each user for debugging
          console.log("Processing user:", user);

          return {
            _id: user._id,
            name: user.name || "",
            email: user.email || "",
            role: user.role || "agency",
            agencyName: user.agencyName || user.name || "",
            ntnNumber: user.ntnNumber || "",
            address: user.address || "",
            city: user.city || "",
            approvalStatus: user.approvalStatus || "pending",
            agencyImage: user.agencyImage || null,
            agencyDoc: Array.isArray(user.agencyDoc) ? user.agencyDoc : [],
            status: user.status || "active",
            stripeCustomerId: user.stripeCustomerId || null,
            subscriptionPlan: user.subscriptionPlan || null,
            amount: user.amount || null,
            subscriptionStatus: user.subscriptionStatus || "pending",
            createdAt: user.createdAt || null,
            updatedAt: user.updatedAt || null,
          };
        });

        console.log("Processed agency data:", agencyData);
        setAgencies(agencyData);
        setLoading(false);
      } catch (err: any) {
        console.error("Error fetching agencies:", err);
        setError(
          err.response?.data?.message ||
            err.message ||
            "Failed to fetch agencies"
        );
        setLoading(false);
        toast.error(
          err.response?.data?.message ||
            err.message ||
            "Failed to fetch agencies"
        );
      }
    };

    fetchAgencies();
  }, [token]);

  const filteredAgencies = useMemo(() => {
    if (statusFilter === "all") return agencies;
    return agencies.filter((agency) => agency.approvalStatus === statusFilter);
  }, [agencies, statusFilter]);

  const ITEMS_PER_PAGE = 5; // Set items per page to 5

  const paginatedAgencies = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    return filteredAgencies.slice(startIndex, endIndex);
  }, [filteredAgencies, currentPage]);

  const totalPages = Math.ceil(filteredAgencies.length / ITEMS_PER_PAGE);

  const handleStatusUpdate = async (
    agencyId: string,
    status: ApprovalStatus
  ) => {
    try {
      console.log(`Updating agency ${agencyId} status to ${status}`);
      const response = await axios.put(
        `/api/user/update-approval/${agencyId}`,
        { approvalStatus: status },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      console.log("Status update response:", response.data);

      if (!response.data || !response.data.user) {
        throw new Error("Invalid API response format");
      }

      // Map the response to match our Agency type
      const updatedAgency = {
        ...response.data.user,
        approvalStatus: status, // Ensure the status is updated
      };

      setAgencies((prevAgencies) =>
        prevAgencies.map((agency) =>
          agency._id === agencyId ? updatedAgency : agency
        )
      );

      toast.success(`Agency ${status} successfully`);
    } catch (err: any) {
      console.error("Error updating status:", err);
      toast.error(
        err.response?.data?.message || err.message || "Failed to update status"
      );
    }
  };

  const handleDelete = async (agencyId: string) => {
    if (!window.confirm("Are you sure you want to delete this agency?")) return;

    try {
      console.log(`Deleting agency ${agencyId}`);
      const response = await axios.delete(`/api/user/delete/${agencyId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      console.log("Delete response:", response.data);

      if (!response.data || response.data.status !== 1) {
        throw new Error(response.data?.message || "Failed to delete agency");
      }

      setAgencies(agencies.filter((agency) => agency._id !== agencyId));
      toast.success("Agency deleted successfully");
    } catch (err: any) {
      console.error("Error deleting agency:", err);
      toast.error(
        err.response?.data?.message || err.message || "Failed to delete agency"
      );
    }
  };

  const handleEdit = (agency: Agency) => {
    setSelectedAgency(agency);
    // Convert the agency object to the correct type without the File property
    const { agencyImage, ...rest } = agency;
    setFormData({ ...rest, agencyImageUrl: agencyImage });
    setEditFormVisible(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    // Handle the special case for clearing the image
    if (name === "clearImage") {
      setFormData((prev) => {
        const newData = { ...prev };
        delete newData.agencyImage;
        delete newData.agencyImageUrl;
        return newData;
      });
      setAgencyImage(null);
      return;
    }

    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      setAgencyImage(file);
      // Store the file in a separate property to avoid type conflicts
      setFormData((prev) => ({
        ...prev,
        agencyImage: file as any, // Use type assertion to avoid TypeScript errors
      }));
    }
  };

  const handleUpdate = async () => {
    try {
      if (!selectedAgency) return;

      console.log("Updating agency with data:", formData);
      const formDataToSend = new FormData();

      // Add all form data fields except agencyImage and agencyImageUrl
      Object.entries(formData).forEach(([key, value]) => {
        if (
          key !== "agencyImage" &&
          key !== "agencyImageUrl" &&
          value !== undefined &&
          value !== null
        ) {
          console.log(`Adding form field: ${key} = ${value}`);
          formDataToSend.append(key, String(value));
        }
      });

      // Add the image file if it exists
      if (agencyImage) {
        console.log("Adding image file to form data");
        formDataToSend.append("agencyImage", agencyImage);
      }

      console.log("Sending update request for agency:", selectedAgency._id);
      const response = await axios.put(
        `/api/user/update/${selectedAgency._id}`,
        formDataToSend,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      console.log("Update response:", response.data);

      if (!response.data || !response.data.user) {
        throw new Error("Invalid API response format");
      }

      // Map the response to match our Agency type
      const updatedAgency = {
        _id: response.data.user._id,
        name: response.data.user.name || "",
        email: response.data.user.email || "",
        role: response.data.user.role || "agency",
        agencyName:
          response.data.user.agencyName || response.data.user.name || "",
        ntnNumber: response.data.user.ntnNumber || "",
        address: response.data.user.address || "",
        city: response.data.user.city || "",
        approvalStatus: response.data.user.approvalStatus || "pending",
        agencyImage: response.data.user.agencyImage || null,
        agencyDoc: Array.isArray(response.data.user.agencyDoc)
          ? response.data.user.agencyDoc
          : [],
        status: response.data.user.status || "active",
        stripeCustomerId: response.data.user.stripeCustomerId || null,
        subscriptionPlan: response.data.user.subscriptionPlan || null,
        amount: response.data.user.amount || null,
        subscriptionStatus: response.data.user.subscriptionStatus || "pending",
        createdAt: response.data.user.createdAt || null,
        updatedAt: response.data.user.updatedAt || null,
      };

      setAgencies((prevAgencies) =>
        prevAgencies.map((agency) =>
          agency._id === updatedAgency._id ? updatedAgency : agency
        )
      );

      setEditFormVisible(false);
      setSelectedAgency(null);
      setAgencyImage(null);
      setFormData({});
      toast.success("Agency updated successfully");
    } catch (err: any) {
      console.error("Error updating agency:", err);
      toast.error(
        err.response?.data?.message || err.message || "Failed to update agency"
      );
    }
  };

  if (loading)
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  if (error)
    return (
      <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">{error}</div>
    );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">{pageTitle}</h1>
          <div className="text-sm text-gray-500">
            Total Agencies: {filteredAgencies.length}
          </div>
        </div>

        {/* Modern Filter Buttons */}
        <div className="bg-white rounded-2xl shadow-sm p-1 mb-8">
          <div className="flex flex-wrap gap-2 p-2">
            <button
              onClick={() => {
                setStatusFilter("all");
                setCurrentPage(1);
              }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 transform hover:scale-102
                ${
                  statusFilter === "all"
                    ? "bg-gradient-to-r from-violet-500 to-violet-600 text-white shadow-lg shadow-violet-200"
                    : "bg-gray-50 text-gray-600 hover:bg-gray-100"
                }`}
            >
              <div className="flex items-center gap-2">
                <span>All Agencies</span>
                <span className="px-2 py-0.5 text-xs rounded-md bg-white/20">
                  {agencies.length}
                </span>
              </div>
            </button>
            <button
              onClick={() => {
                setStatusFilter("pending");
                setCurrentPage(1);
              }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 transform hover:scale-102
                ${
                  statusFilter === "pending"
                    ? "bg-gradient-to-r from-amber-400 to-amber-500 text-white shadow-lg shadow-amber-200"
                    : "bg-gray-50 text-gray-600 hover:bg-gray-100"
                }`}
            >
              <div className="flex items-center gap-2">
                <span>Pending</span>
                <span className="px-2 py-0.5 text-xs rounded-md bg-white/20">
                  {
                    agencies.filter((a) => a.approvalStatus === "pending")
                      .length
                  }
                </span>
              </div>
            </button>
            <button
              onClick={() => {
                setStatusFilter("approved");
                setCurrentPage(1);
              }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 transform hover:scale-102
                ${
                  statusFilter === "approved"
                    ? "bg-gradient-to-r from-emerald-500 to-emerald-600 text-white shadow-lg shadow-emerald-200"
                    : "bg-gray-50 text-gray-600 hover:bg-gray-100"
                }`}
            >
              <div className="flex items-center gap-2">
                <span>Approved</span>
                <span className="px-2 py-0.5 text-xs rounded-md bg-white/20">
                  {
                    agencies.filter((a) => a.approvalStatus === "approved")
                      .length
                  }
                </span>
              </div>
            </button>
            <button
              onClick={() => {
                setStatusFilter("rejected");
                setCurrentPage(1);
              }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 transform hover:scale-102
                ${
                  statusFilter === "rejected"
                    ? "bg-gradient-to-r from-rose-500 to-rose-600 text-white shadow-lg shadow-rose-200"
                    : "bg-gray-50 text-gray-600 hover:bg-gray-100"
                }`}
            >
              <div className="flex items-center gap-2">
                <span>Rejected</span>
                <span className="px-2 py-0.5 text-xs rounded-md bg-white/20">
                  {
                    agencies.filter((a) => a.approvalStatus === "rejected")
                      .length
                  }
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Agencies List */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {paginatedAgencies.length > 0 ? (
            <div className="divide-y divide-gray-100">
              {paginatedAgencies.map((agency) => (
                <div
                  key={agency._id}
                  className="p-6 transition-all duration-200 hover:bg-gray-50"
                >
                  <AgencySection
                    section={{
                      title: "",
                      agencies: [agency],
                      bgColor: STATUS_COLORS[agency.approvalStatus].bg,
                      textColor: STATUS_COLORS[agency.approvalStatus].text,
                    }}
                    onStatusUpdate={handleStatusUpdate}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16">
              <div className="text-gray-400 mb-2">
                <svg
                  className="w-16 h-16"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1.5}
                    d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                  />
                </svg>
              </div>
              <p className="text-lg font-medium text-gray-600">
                No agencies found
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Try adjusting your filters
              </p>
            </div>
          )}
        </div>

        {/* Pagination */}
        {paginatedAgencies.length > 0 && (
          <div className="mt-6 flex items-center justify-between bg-white rounded-xl shadow-sm p-4">
            <div className="text-sm text-gray-500">
              Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{" "}
              {Math.min(currentPage * ITEMS_PER_PAGE, filteredAgencies.length)}{" "}
              of {filteredAgencies.length} agencies
            </div>
            <div className="flex items-center gap-2">
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={(page) => {
                  setCurrentPage(page);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
              />
            </div>
          </div>
        )}

        {editFormVisible && (
          <EditAgencyForm
            formData={formData}
            onClose={() => {
              setEditFormVisible(false);
              setSelectedAgency(null);
            }}
            onChange={handleChange}
            onFileChange={handleFileChange}
            onUpdate={handleUpdate}
          />
        )}
      </div>
    </div>
  );
};

export default AgencyManagementPage;
