export const STATUS_COLORS = {
  pending: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    button: 'hover:bg-amber-100',
    border: 'border-amber-200',
    gradient: 'from-amber-500/20 to-amber-500/0',
    shadow: 'shadow-amber-200/50'
  },
  approved: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    button: 'hover:bg-emerald-100',
    border: 'border-emerald-200',
    gradient: 'from-emerald-500/20 to-emerald-500/0',
    shadow: 'shadow-emerald-200/50'
  },
  rejected: {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    button: 'hover:bg-rose-100',
    border: 'border-rose-200',
    gradient: 'from-rose-500/20 to-rose-500/0',
    shadow: 'shadow-rose-200/50'
  }
} as const;

export const ITEMS_PER_PAGE = 15;
export const ITEMS_PER_SECTION = 5;

export const CARD_ANIMATIONS = {
  enter: 'transition-all duration-300 ease-out',
  hover: 'hover:shadow-lg hover:translate-y-[-2px] hover:scale-[1.01]',
  active: 'active:scale-[0.99] active:translate-y-[0px]'
} as const;

export const BUTTON_STYLES = {
  base: 'inline-flex items-center justify-center gap-2 rounded-full font-medium transition-all duration-200',
  sizes: {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2 text-sm',
    lg: 'px-5 py-2.5 text-base'
  },
  variants: {
    primary: 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-600/50',
    secondary: 'bg-gray-100 text-gray-700 hover:bg-gray-200 focus:ring-gray-600/50',
    danger: 'bg-rose-600 text-white hover:bg-rose-700 focus:ring-rose-600/50'
  }
} as const;
