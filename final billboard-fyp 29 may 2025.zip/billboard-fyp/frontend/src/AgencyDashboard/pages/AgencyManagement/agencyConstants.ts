export const STATUS_COLORS = {
  pending: 'bg-yellow-100',
  approved: 'bg-green-100',
  rejected: 'bg-red-100',
} as const;

export const STATUS_TEXT_COLORS = {
  pending: 'text-yellow-800',
  approved: 'text-green-800',
  rejected: 'text-red-800',
} as const;

export const AGENCIES_PER_PAGE = 6;

export const BASE_API_URL = '/api/auth';
export const BASE_IMAGE_URL = 'http://localhost:4000/files';
