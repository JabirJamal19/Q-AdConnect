import React from 'react';
import { FaEdit, FaTrashAlt, FaEnvelope, FaMapMarkerAlt, FaIdCard, FaCheckCircle, FaTimesCircle, FaClock } from 'react-icons/fa';
import { Agency, ApprovalStatus } from './types';
import { STATUS_COLORS, CARD_ANIMATIONS, BUTTON_STYLES } from './constants';

interface AgencyCardProps {
  agency: Agency;
  onStatusUpdate: (id: string, status: ApprovalStatus) => Promise<void>;
  onEdit: (agency: Agency) => void;
  onDelete: (id: string) => Promise<void>;
  bgColor: string;
  textColor: string;
}

export const AgencyCard: React.FC<AgencyCardProps> = ({
  agency,
  onStatusUpdate,
  onEdit,
  onDelete,
}) => {
  const BASE_IMAGE_URL = `http://localhost:4000/files/${agency.agencyImage}`;
  const colors = STATUS_COLORS[agency.approvalStatus];

  const getStatusIcon = (status: ApprovalStatus) => {
    switch (status) {
      case 'approved':
        return <FaCheckCircle className="w-4 h-4" />;
      case 'rejected':
        return <FaTimesCircle className="w-4 h-4" />;
      default:
        return <FaClock className="w-4 h-4" />;
    }
  };

  const getStatusButtonStyle = (buttonStatus: ApprovalStatus) => {
    const isActive = agency.approvalStatus === buttonStatus;
    const btnColors = STATUS_COLORS[buttonStatus];
    return `
      ${BUTTON_STYLES.base} ${BUTTON_STYLES.sizes.sm}
      ${isActive 
        ? `${btnColors.bg} ${btnColors.text} ring-2 ${btnColors.border}` 
        : 'bg-white text-gray-600 hover:bg-gray-50'}
      focus:ring-2 focus:ring-offset-2 focus:ring-offset-white focus:${btnColors.border}
      shadow-sm hover:shadow-md
    `;
  };

  return (
    <div 
      className={`
        relative overflow-hidden rounded-2xl bg-white
        ${CARD_ANIMATIONS.enter} ${CARD_ANIMATIONS.hover} ${CARD_ANIMATIONS.active}
        shadow-md ${colors.shadow}
      `}
    >
      {/* Background gradient effect */}
      <div className={`absolute inset-0 bg-gradient-to-br ${colors.gradient} opacity-30`} />

      <div className="relative p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${colors.gradient} blur-sm`} />
              <img
                src={agency.logoUrl || BASE_IMAGE_URL}
                alt={agency.name}
                className="relative w-20 h-20 rounded-2xl object-cover border-2 border-white shadow-lg"
              />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors duration-200">
                {agency.name}
              </h3>
              <div className="flex items-center gap-2 mt-1">
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium ${colors.bg} ${colors.text}`}>
                  {getStatusIcon(agency.approvalStatus)}
                  {agency.approvalStatus.charAt(0).toUpperCase() + agency.approvalStatus.slice(1)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(agency)}
              className={`${BUTTON_STYLES.base} ${BUTTON_STYLES.sizes.sm} ${BUTTON_STYLES.variants.secondary}`}
              title="Edit agency"
            >
              <FaEdit className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(agency._id)}
              className={`${BUTTON_STYLES.base} ${BUTTON_STYLES.sizes.sm} ${BUTTON_STYLES.variants.danger}`}
              title="Delete agency"
            >
              <FaTrashAlt className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Agency Details */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="flex items-center gap-2 text-gray-600">
            <FaEnvelope className="w-4 h-4 text-gray-400 flex-shrink-0" />
            <span className="text-sm truncate">{agency.email}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <FaMapMarkerAlt className="w-4 h-4 text-gray-400 flex-shrink-0" />
            <span className="text-sm truncate">{agency.city}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <FaIdCard className="w-4 h-4 text-gray-400 flex-shrink-0" />
            <span className="text-sm truncate">NTN: {agency.ntnNumber}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <FaMapMarkerAlt className="w-4 h-4 text-gray-400 flex-shrink-0" />
            <span className="text-sm truncate">{agency.address}</span>
          </div>
        </div>

        {/* Status Buttons */}
        <div className="flex flex-wrap gap-2 pt-4 border-t border-gray-100">
          <button
            onClick={() => onStatusUpdate(agency._id, 'pending')}
            className={getStatusButtonStyle('pending')}
          >
            <FaClock className="w-3.5 h-3.5" />
            Pending
          </button>
          <button
            onClick={() => onStatusUpdate(agency._id, 'approved')}
            className={getStatusButtonStyle('approved')}
          >
            <FaCheckCircle className="w-3.5 h-3.5" />
            Approved
          </button>
          <button
            onClick={() => onStatusUpdate(agency._id, 'rejected')}
            className={getStatusButtonStyle('rejected')}
          >
            <FaTimesCircle className="w-3.5 h-3.5" />
            Rejected
          </button>
        </div>
      </div>
    </div>
  );
};
