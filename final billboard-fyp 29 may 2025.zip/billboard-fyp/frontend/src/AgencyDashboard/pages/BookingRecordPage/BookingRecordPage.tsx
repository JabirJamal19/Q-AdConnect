import React, { useState, useEffect, useCallback, Fragment, useMemo } from "react";
import axiosInstance from "../../../axiosInstance";
import { useAuthStore } from "../../../stores/authStore";
import { toast } from "react-hot-toast";
import {
  FaChevronDown,
  FaUserCircle,
  FaClipboardCheck,
  FaTimesCircle,
  FaSync,
  FaInfoCircle,
  FaEye,
  FaChevronLeft,
  FaChevronRight,
  FaExclamationTriangle,
  FaFilter,
  FaImages,
  FaCheckCircle,
  FaCalendarCheck,
  FaHourglassHalf,
  FaMoneyBillWave,
  FaTimes,
  FaMapMarkerAlt,
  FaDollarSign,
  FaClock,
  FaCommentDots,
  FaPaperPlane,
  FaFileExport,
  FaSearch,
  FaCalendarAlt,
  FaCreditCard,
  FaChartBar,
  FaHistory,
  FaDownload,
  FaSort,
  FaSortAmountDown,
  FaSortAmountUp,
  FaExchangeAlt,
  FaRegCreditCard,
  FaRegMoneyBillAlt,
  FaRegClock,
  FaRegCalendarCheck,
  FaRegCalendarTimes,
  FaRegCalendarAlt,
  FaRegChartBar,
} from "react-icons/fa";
import { motion, AnimatePresence } from "framer-motion";
import { FcMoneyTransfer } from "react-icons/fc";
import { Dialog, Transition, Menu, Tab } from "@headlessui/react";

// --- Interfaces (remain the same) ---
interface AgencyBooking {
  _id: string;
  billboardId: {
    _id: string;
    title: string;
    location: string;
    size?: string;
    type?: string;
  };
  customerId: {
    _id: string;
    name: string;
    email: string;
    phone?: string;
    company?: string;
  };
  startDate: string;
  endDate: string;
  duration: number;
  totalAmount: number;
  adImageUrls: string[];
  status:
    | "pending"
    | "approved"
    | "rejected"
    | "paid"
    | "completed"
    | "cancelled";
  paymentStatus: "pending" | "succeeded" | "failed";
  paymentMethod?: string;
  paymentDate?: string;
  paymentReference?: string;
  paymentProofUrl?: string;
  contentVerified?: boolean;
  contentVerificationDate?: string;
  rejectionReason?: string;
  createdAt: string;
  updatedAt?: string;
  history?: BookingHistoryEntry[];
}

interface BookingHistoryEntry {
  date: string;
  action: string;
  status: string;
  note?: string;
  user?: string;
}

interface BookingAnalytics {
  totalBookings: number;
  totalRevenue: number;
  pendingBookings: number;
  activeBookings: number;
  completedBookings: number;
  rejectedBookings: number;
  paymentMethodStats: {
    method: string;
    count: number;
    amount: number;
  }[];
  monthlyBookings: {
    month: string;
    count: number;
    revenue: number;
  }[];
}

interface AgencyBookingsApiResponse {
  status: number;
  message: string;
  data: AgencyBooking[];
  total: number;
  totalPages: number;
  page: number;
  analytics?: BookingAnalytics;
}

interface BookingDetailsProps {
  booking: AgencyBooking;
}

interface ImagePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  booking: AgencyBooking | null;
}

// --- Utility Functions (remain the same) ---
const formatDate = (dateString: string) =>
  new Date(dateString).toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });

const formatCurrency = (amount: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "PRK" }).format(
    amount
  );

const getStatusChip = (
  status: AgencyBooking["status"],
  paymentStatus: AgencyBooking["paymentStatus"],
  endDate?: string
): JSX.Element => {
  let bgColor = "bg-gray-100";
  let textColor = "text-gray-800";
  let ringColor = "ring-gray-500/10";
  let icon = <FaHourglassHalf className="h-3.5 w-3.5" />;
  let text = status.charAt(0).toUpperCase() + status.slice(1);

  const now = new Date();
  const isPastEndDate = endDate && new Date(endDate) < now;

  switch (status) {
    case "pending":
      bgColor = "bg-yellow-100";
      textColor = "text-yellow-800";
      ringColor = "ring-yellow-600/20";
      icon = <FaHourglassHalf className="h-3.5 w-3.5 animate-pulse" />;
      text = "Pending Review";
      break;
    case "approved":
      if (paymentStatus === "pending") {
        bgColor = "bg-blue-100";
        textColor = "text-blue-800";
        ringColor = "ring-blue-600/20";
        icon = <FaMoneyBillWave className="h-3.5 w-3.5" />;
        text = "Awaiting Payment";
      } else {
        bgColor = "bg-teal-100";
        textColor = "text-teal-800";
        ringColor = "ring-teal-600/20";
        icon = <FaCalendarCheck className="h-3.5 w-3.5" />;
        text = "Approved";
      }
      break;
    case "paid":
      if (isPastEndDate) {
        bgColor = "bg-indigo-100";
        textColor = "text-indigo-800";
        ringColor = "ring-indigo-600/20";
        icon = <FaCheckCircle className="h-3.5 w-3.5" />;
        text = "Completed";
      } else {
        bgColor = "bg-emerald-100";
        textColor = "text-emerald-800";
        ringColor = "ring-emerald-600/20";
        icon = <FaCheckCircle className="h-3.5 w-3.5" />;
        text = "Active";
      }
      break;
    case "rejected":
      bgColor = "bg-red-100";
      textColor = "text-red-800";
      ringColor = "ring-red-600/20";
      icon = <FaTimesCircle className="h-3.5 w-3.5" />;
      text = "Rejected";
      break;
    case "cancelled":
      bgColor = "bg-slate-100";
      textColor = "text-slate-700";
      ringColor = "ring-slate-600/20";
      icon = <FaTimes className="h-3.5 w-3.5" />;
      text = "Cancelled";
      break;
    case "completed":
      bgColor = "bg-indigo-100";
      textColor = "text-indigo-800";
      ringColor = "ring-indigo-600/20";
      icon = <FaCheckCircle className="h-3.5 w-3.5" />;
      text = "Completed";
      break;
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${bgColor} ${textColor} ring-1 ring-inset ${ringColor}`}
    >
      {icon}
      {text}
    </span>
  );
};

// --- Helper Components ---
// Enhanced Booking Details section for the modal with payment information
const BookingDetails: React.FC<BookingDetailsProps> = ({ booking }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6 bg-gradient-to-b from-gray-50 to-white rounded-lg text-sm border-t border-b border-gray-200">
      {/* Customer Details */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-indigo-100 text-indigo-600 rounded-full">
            <FaUserCircle className="w-5 h-5" />
          </div>
          <h4 className="font-semibold text-gray-800">Customer Details</h4>
        </div>
        <div className="pl-10 space-y-2">
          <p className="text-gray-700">
            <span className="font-medium text-gray-600">Name:</span>{" "}
            {booking.customerId?.name || "Unknown Customer"}
          </p>
          <p className="text-gray-700 break-words">
            <span className="font-medium text-gray-600">Email:</span>{" "}
            {booking.customerId?.email || "No email available"}
          </p>
          {booking.customerId?.phone && (
            <p className="text-gray-700">
              <span className="font-medium text-gray-600">Phone:</span>{" "}
              {booking.customerId.phone}
            </p>
          )}
          {booking.customerId?.company && (
            <p className="text-gray-700">
              <span className="font-medium text-gray-600">Company:</span>{" "}
              {booking.customerId.company}
            </p>
          )}
        </div>
      </div>

      {/* Booking Details */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-emerald-100 text-emerald-600 rounded-full">
            <FaClipboardCheck className="w-5 h-5" />
          </div>
          <h4 className="font-semibold text-gray-800">Booking Details</h4>
        </div>
        <div className="pl-10 space-y-2">
          <p className="text-gray-700 flex items-center gap-1">
            <FaClock className="text-gray-400" />
            <span className="font-medium text-gray-600">Dates:</span>{" "}
            {formatDate(booking.startDate)} - {formatDate(booking.endDate)} (
            {booking.duration} days)
          </p>
          <p className="text-gray-700 flex items-center gap-1">
            <FcMoneyTransfer />
            <span className="font-medium text-gray-600">Amount:</span>{" "}
            {formatCurrency(booking.totalAmount)}
          </p>
          <p className="text-gray-700 flex items-center gap-1">
            <FaMapMarkerAlt className="text-gray-400" />
            <span className="font-medium text-gray-600">Location:</span>{" "}
            {booking.billboardId?.location || "Unknown Location"}
          </p>
          {booking.billboardId?.size && (
            <p className="text-gray-700 flex items-center gap-1">
              <FaRegChartBar className="text-gray-400" />
              <span className="font-medium text-gray-600">Size:</span>{" "}
              {booking.billboardId.size}
            </p>
          )}
          {booking.billboardId?.type && (
            <p className="text-gray-700 flex items-center gap-1">
              <FaRegChartBar className="text-gray-400" />
              <span className="font-medium text-gray-600">Type:</span>{" "}
              {booking.billboardId.type}
            </p>
          )}
        </div>
      </div>

      {/* Payment Details */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-blue-100 text-blue-600 rounded-full">
            <FaRegCreditCard className="w-5 h-5" />
          </div>
          <h4 className="font-semibold text-gray-800">Payment Details</h4>
        </div>
        <div className="pl-10 space-y-2">
          <p className="text-gray-700 flex items-center gap-1">
            <FaRegClock className="text-gray-400" />
            <span className="font-medium text-gray-600">Status:</span>{" "}
            <span
              className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                booking.paymentStatus === "succeeded"
                  ? "bg-green-100 text-green-800"
                  : booking.paymentStatus === "failed"
                  ? "bg-red-100 text-red-800"
                  : "bg-yellow-100 text-yellow-800"
              }`}
            >
              {booking.paymentStatus.charAt(0).toUpperCase() +
                booking.paymentStatus.slice(1)}
            </span>
          </p>
          {booking.paymentMethod && (
            <p className="text-gray-700 flex items-center gap-1">
              <FaRegCreditCard className="text-gray-400" />
              <span className="font-medium text-gray-600">Method:</span>{" "}
              <span className="capitalize">{booking.paymentMethod}</span>
            </p>
          )}
          {booking.paymentDate && (
            <p className="text-gray-700 flex items-center gap-1">
              <FaRegCalendarAlt className="text-gray-400" />
              <span className="font-medium text-gray-600">Date:</span>{" "}
              {formatDate(booking.paymentDate)}
            </p>
          )}
          {booking.paymentReference && (
            <p className="text-gray-700 flex items-center gap-1">
              <FaRegMoneyBillAlt className="text-gray-400" />
              <span className="font-medium text-gray-600">Reference:</span>{" "}
              {booking.paymentReference}
            </p>
          )}
          {booking.paymentProofUrl && (
            <p className="text-gray-700 flex items-center gap-1">
              <FaRegMoneyBillAlt className="text-gray-400" />
              <span className="font-medium text-gray-600">Proof:</span>{" "}
              <a
                href={booking.paymentProofUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                View Receipt
              </a>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

// POLISHED: Enhanced Image Preview Modal with better styling and Framer Motion
const ImagePreviewModal: React.FC<ImagePreviewModalProps> = ({
  isOpen,
  onClose,
  booking,
}) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    if (isOpen) {
      setCurrentImageIndex(0);
    }
  }, [isOpen]);
  if (!booking) return null;
  const nextImage = () => {
    setCurrentImageIndex((prev) =>
      prev === booking.adImageUrls.length - 1 ? 0 : prev + 1
    );
  };
  const prevImage = () => {
    setCurrentImageIndex((prev) =>
      prev === 0 ? booking.adImageUrls.length - 1 : prev - 1
    );
  };

  return (
    <Transition show={isOpen} as={Fragment}>
      <Dialog onClose={onClose} className="relative z-[9999]">
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
            aria-hidden="true"
          />
        </Transition.Child>
        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className="w-full max-w-4xl transform rounded-2xl bg-white text-left align-middle shadow-2xl transition-all overflow-hidden">
                {/* Header */}
                <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 px-6 py-4 text-white">
                  <div className="flex items-center justify-between">
                    <Dialog.Title
                      as="h3"
                      className="text-lg font-semibold leading-6"
                    >
                      Review Advertisement Content
                    </Dialog.Title>
                    <button
                      type="button"
                      onClick={onClose}
                      className="rounded-full p-1 text-white/70 hover:text-white hover:bg-white/10 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75 transition-colors"
                      aria-label="Close modal"
                    >
                      <FaTimes className="h-5 w-5" />
                    </button>
                  </div>
                  <div className="mt-2">
                    <h4 className="text-base font-medium text-white/95">
                      {booking?.billboardId?.title || "Untitled Billboard"}
                    </h4>
                    <p className="text-sm text-white/80 flex items-center gap-1.5 mt-1">
                      <FaMapMarkerAlt />
                      {booking.billboardId?.location || "Unknown Location"}
                    </p>
                  </div>
                </div>
                {/* Booking Details Section */}
                <BookingDetails booking={booking} />
                {/* Image Viewer Section */}
                <div className="p-6 bg-gray-100">
                  <div className="relative aspect-[16/9] bg-gradient-to-b from-gray-700 to-gray-900 rounded-lg overflow-hidden shadow-inner">
                    {booking.adImageUrls.length > 1 && (
                      <>
                        <button
                          onClick={prevImage}
                          className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/40 hover:bg-black/60 text-white rounded-full transition-all z-10 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
                          aria-label="Previous image"
                        >
                          <FaChevronLeft className="h-5 w-5" />
                        </button>
                        <button
                          onClick={nextImage}
                          className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/40 hover:bg-black/60 text-white rounded-full transition-all z-10 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
                          aria-label="Next image"
                        >
                          <FaChevronRight className="h-5 w-5" />
                        </button>
                      </>
                    )}
                    <AnimatePresence mode="wait">
                      <motion.img
                        key={currentImageIndex}
                        src={booking.adImageUrls[currentImageIndex]}
                        alt={`Advertisement ${currentImageIndex + 1}`}
                        className="absolute inset-0 w-full h-full object-contain"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.3 }}
                      />
                    </AnimatePresence>
                    {booking.adImageUrls.length > 1 && (
                      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2 z-10">
                        {booking.adImageUrls.map((_, idx) => (
                          <button
                            key={idx}
                            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${idx === currentImageIndex ? "bg-white scale-125" : "bg-white/50 hover:bg-white/75"}`}
                            onClick={() => setCurrentImageIndex(idx)}
                            aria-label={`View image ${idx + 1}`}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                {/* Footer */}
                <div className="border-t border-gray-200 px-6 py-4 bg-gray-50">
                  <div className="flex items-center justify-between gap-4">
                    <div className="text-sm text-gray-500 flex items-center">
                      <FaImages className="mr-2 text-indigo-500" /> Viewing
                      Image {currentImageIndex + 1} of{" "}
                      {booking.adImageUrls.length}
                    </div>
                    <button
                      type="button"
                      onClick={onClose}
                      className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors"
                    >
                      <FaTimes className="mr-2 -ml-1 h-4 w-4" /> Close
                    </button>
                  </div>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
};

// --- Analytics Component ---
interface BookingAnalyticsProps {
  analytics: BookingAnalytics;
}

const BookingAnalyticsSummary: React.FC<BookingAnalyticsProps> = ({ analytics }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Total Bookings */}
      <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-indigo-500">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Total Bookings</p>
            <p className="text-2xl font-bold text-gray-800">{analytics.totalBookings}</p>
          </div>
          <div className="p-3 bg-indigo-100 rounded-full">
            <FaClipboardCheck className="h-6 w-6 text-indigo-600" />
          </div>
        </div>
      </div>

      {/* Total Revenue */}
      <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-emerald-500">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Total Revenue</p>
            <p className="text-2xl font-bold text-gray-800">{formatCurrency(analytics.totalRevenue)}</p>
          </div>
          <div className="p-3 bg-emerald-100 rounded-full">
            <FaDollarSign className="h-6 w-6 text-emerald-600" />
          </div>
        </div>
      </div>

      {/* Active Bookings */}
      <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-blue-500">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Active Campaigns</p>
            <p className="text-2xl font-bold text-gray-800">{analytics.activeBookings}</p>
          </div>
          <div className="p-3 bg-blue-100 rounded-full">
            <FaCalendarCheck className="h-6 w-6 text-blue-600" />
          </div>
        </div>
      </div>

      {/* Pending Bookings */}
      <div className="bg-white rounded-xl shadow-md p-4 border-l-4 border-yellow-500">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Pending Review</p>
            <p className="text-2xl font-bold text-gray-800">{analytics.pendingBookings}</p>
          </div>
          <div className="p-3 bg-yellow-100 rounded-full">
            <FaHourglassHalf className="h-6 w-6 text-yellow-600" />
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Export Utility ---
const exportBookingsToCSV = (bookings: AgencyBooking[]) => {
  if (!bookings || bookings.length === 0) {
    toast.error("No bookings to export");
    return;
  }

  // Define CSV headers
  const headers = [
    "Booking ID",
    "Customer Name",
    "Customer Email",
    "Billboard",
    "Location",
    "Start Date",
    "End Date",
    "Duration (days)",
    "Amount",
    "Status",
    "Payment Status",
    "Payment Method",
    "Payment Date",
    "Created At"
  ];

  // Convert bookings to CSV rows
  const rows = bookings.map(booking => [
    booking._id,
    booking.customerId?.name || "Unknown",
    booking.customerId?.email || "N/A",
    booking.billboardId?.title || "Unknown",
    booking.billboardId?.location || "Unknown",
    formatDate(booking.startDate),
    formatDate(booking.endDate),
    booking.duration.toString(),
    booking.totalAmount.toString(),
    booking.status,
    booking.paymentStatus,
    booking.paymentMethod || "N/A",
    booking.paymentDate ? formatDate(booking.paymentDate) : "N/A",
    formatDate(booking.createdAt)
  ]);

  // Combine headers and rows
  const csvContent = [
    headers.join(","),
    ...rows.map(row => row.join(","))
  ].join("\n");

  // Create a Blob and download link
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `bookings_export_${new Date().toISOString().slice(0, 10)}.csv`);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// --- Main Component ---
const BookingRecordPage: React.FC = () => {
  const { token } = useAuthStore();
  const [bookings, setBookings] = useState<AgencyBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  // State variables for the component
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterPaymentMethod, setFilterPaymentMethod] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [dateRange, setDateRange] = useState<{start: string, end: string} | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<AgencyBooking | null>(null);
  const [imagePreviewOpen, setImagePreviewOpen] = useState(false);
  const [analytics, setAnalytics] = useState<BookingAnalytics | null>(null);
  const [showAnalytics, setShowAnalytics] = useState<boolean>(true);
  const [sortField, setSortField] = useState<string>("createdAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [exportLoading, setExportLoading] = useState<boolean>(false);

  const bookingsPerPage = 10; // Or adjust as needed for card layout

  // --- Data Fetching and Actions ---
  const fetchAgencyBookings = useCallback(
    async (page: number, statusFilter: string) => {
      if (!token) return;
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: bookingsPerPage.toString(),
          sort: sortField,
          order: sortDirection,
          includeAnalytics: "true",
        });

        // Apply filters
        if (statusFilter !== "all") {
          params.append("status", statusFilter);
        }

        if (filterPaymentMethod !== "all") {
          params.append("paymentMethod", filterPaymentMethod);
        }

        if (searchTerm.trim()) {
          params.append("search", searchTerm.trim());
        }

        if (dateRange) {
          params.append("startDate", dateRange.start);
          params.append("endDate", dateRange.end);
        }

        const response = await axiosInstance.get<AgencyBookingsApiResponse>(
          `/api/booking/agency-view?${params.toString()}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );

        if (response.data && response.data.status === 1) {
          setBookings(response.data.data);
          setTotalPages(response.data.totalPages || 1);
          setCurrentPage(response.data.page || 1);

          // Set analytics if available
          if (response.data.analytics) {
            setAnalytics(response.data.analytics);
          } else {
            // Create basic analytics from the data we have
            const basicAnalytics: BookingAnalytics = {
              totalBookings: response.data.total || response.data.data.length,
              totalRevenue: response.data.data.reduce((sum, booking) => sum + booking.totalAmount, 0),
              pendingBookings: response.data.data.filter(b => b.status === "pending").length,
              activeBookings: response.data.data.filter(b => b.status === "paid" && new Date(b.endDate) >= new Date()).length,
              completedBookings: response.data.data.filter(b => b.status === "completed" || (b.status === "paid" && new Date(b.endDate) < new Date())).length,
              rejectedBookings: response.data.data.filter(b => b.status === "rejected").length,
              paymentMethodStats: [],
              monthlyBookings: []
            };
            setAnalytics(basicAnalytics);
          }
        } else {
          throw new Error(response.data.message || "Failed to load bookings");
        }
      } catch (err: any) {
        console.error("Fetch agency bookings error:", err);
        const message =
          err.response?.data?.message ||
          err.message ||
          "Could not fetch bookings.";
        setError(message);

        // Check if the request was cancelled
        const isCancel = err.name === "CanceledError" || err.code === "ECONNABORTED";
        if (!isCancel) {
          toast.error(message);
        }

        setBookings([]);
        setTotalPages(1);
        setCurrentPage(1);
        setAnalytics(null);
      } finally {
        setLoading(false);
      }
    },
    [
      token,
      bookingsPerPage,
      filterPaymentMethod,
      searchTerm,
      dateRange,
      sortField,
      sortDirection
    ]
  );

  useEffect(() => {
    fetchAgencyBookings(currentPage, filterStatus);
  }, [currentPage, filterStatus, fetchAgencyBookings]);

  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages && page !== currentPage) {
      setCurrentPage(page);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  // --- Render Logic ---
  return (
    <div className="min-h-full bg-gradient-to-b from-gray-50 via-gray-100 to-gray-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Section */}
        <div className="bg-gradient-to-r from-blue-500 to-blue-400 rounded-xl shadow-lg mb-8 p-6 text-white">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
                <FaClipboardCheck className="h-8 w-8 text-indigo-200 flex-shrink-0" />{" "}
                Booking Records
              </h1>
              <p className="mt-1.5 text-indigo-100/90">
                Track and manage all billboard booking information in one place.
              </p>
            </div>
            <div className="flex items-center gap-3 self-stretch md:self-center">
              <button
                onClick={() => setShowAnalytics(!showAnalytics)}
                className="bg-white/10 hover:bg-white/20 text-white p-2.5 rounded-lg transition-colors shadow-md flex-shrink-0"
                title={showAnalytics ? "Hide Analytics" : "Show Analytics"}
              >
                <FaChartBar className="h-4 w-4" />
              </button>
              <button
                onClick={() => {
                  setExportLoading(true);
                  setTimeout(() => {
                    exportBookingsToCSV(bookings);
                    setExportLoading(false);
                  }, 500);
                }}
                disabled={exportLoading || loading || bookings.length === 0}
                className="bg-white/10 hover:bg-white/20 text-white px-3 py-2.5 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-md flex-shrink-0 flex items-center gap-2"
                title="Export Bookings"
              >
                <FaDownload className={`${exportLoading ? "animate-pulse" : ""} h-4 w-4`} />
                <span className="text-sm font-medium">Export</span>
              </button>
              <button
                onClick={() => fetchAgencyBookings(currentPage, filterStatus)}
                disabled={loading}
                className="bg-white/10 hover:bg-white/20 text-white p-2.5 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-md flex-shrink-0"
                title="Refresh Bookings"
                aria-label="Refresh bookings list"
              >
                <FaSync
                  className={`${loading ? "animate-spin" : ""} h-4 w-4`}
                />
              </button>
            </div>
          </div>

          {/* Advanced Filters Section */}
          <div className="mt-6 pt-5 border-t border-white/20">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Status Filter */}
              <div className="relative">
                <label htmlFor="status-filter" className="block text-xs font-medium text-indigo-100 mb-1.5">
                  Status
                </label>
                <div className="relative">
                  <FaFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-indigo-400 pointer-events-none" />
                  <select
                    id="status-filter"
                    value={filterStatus}
                    onChange={(e) => {
                      setFilterStatus(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="pl-9 pr-8 py-2 w-full border-0 rounded-lg shadow-md appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:ring-offset-2 focus:ring-offset-indigo-700 text-sm font-medium text-indigo-900 bg-white disabled:opacity-70 transition"
                    disabled={loading}
                  >
                    <option value="all">All Statuses</option>
                    <option value="pending">Pending Review</option>
                    <option value="approved">Awaiting Payment</option>
                    <option value="paid">Active/Completed</option>
                    <option value="rejected">Rejected</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                  <FaChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-indigo-400 pointer-events-none h-4 w-4" />
                </div>
              </div>

              {/* Payment Method Filter */}
              <div className="relative">
                <label htmlFor="payment-method-filter" className="block text-xs font-medium text-indigo-100 mb-1.5">
                  Payment Method
                </label>
                <div className="relative">
                  <FaRegCreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 text-indigo-400 pointer-events-none" />
                  <select
                    id="payment-method-filter"
                    value={filterPaymentMethod}
                    onChange={(e) => {
                      setFilterPaymentMethod(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="pl-9 pr-8 py-2 w-full border-0 rounded-lg shadow-md appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:ring-offset-2 focus:ring-offset-indigo-700 text-sm font-medium text-indigo-900 bg-white disabled:opacity-70 transition"
                    disabled={loading}
                  >
                    <option value="all">All Payment Methods</option>
                    <option value="stripe">Stripe</option>
                    <option value="jazzcash">JazzCash</option>
                    <option value="easypaisa">EasyPaisa</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="cash">Cash</option>
                  </select>
                  <FaChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-indigo-400 pointer-events-none h-4 w-4" />
                </div>
              </div>

              {/* Search */}
              <div className="relative">
                <label htmlFor="search-term" className="block text-xs font-medium text-indigo-100 mb-1.5">
                  Search
                </label>
                <div className="relative">
                  <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-indigo-400 pointer-events-none" />
                  <input
                    type="text"
                    id="search-term"
                    placeholder="Customer, Billboard, ID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setCurrentPage(1);
                        fetchAgencyBookings(1, filterStatus);
                      }
                    }}
                    className="pl-9 pr-4 py-2 w-full border-0 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:ring-offset-2 focus:ring-offset-indigo-700 text-sm font-medium text-indigo-900 bg-white disabled:opacity-70 transition"
                    disabled={loading}
                  />
                  {searchTerm && (
                    <button
                      onClick={() => {
                        setSearchTerm('');
                        setCurrentPage(1);
                        fetchAgencyBookings(1, filterStatus);
                      }}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-indigo-400 hover:text-indigo-600"
                      aria-label="Clear search"
                    >
                      <FaTimes className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Sort */}
              <div className="relative">
                <label htmlFor="sort-field" className="block text-xs font-medium text-indigo-100 mb-1.5">
                  Sort By
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-grow">
                    <select
                      id="sort-field"
                      value={sortField}
                      onChange={(e) => {
                        setSortField(e.target.value);
                        setCurrentPage(1);
                        fetchAgencyBookings(1, filterStatus);
                      }}
                      className="pl-3 pr-8 py-2 w-full border-0 rounded-lg shadow-md appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:ring-offset-2 focus:ring-offset-indigo-700 text-sm font-medium text-indigo-900 bg-white disabled:opacity-70 transition"
                      disabled={loading}
                    >
                      <option value="createdAt">Date Created</option>
                      <option value="startDate">Start Date</option>
                      <option value="endDate">End Date</option>
                      <option value="totalAmount">Amount</option>
                      <option value="status">Status</option>
                    </select>
                    <FaChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-indigo-400 pointer-events-none h-4 w-4" />
                  </div>
                  <button
                    onClick={() => {
                      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
                      setCurrentPage(1);
                      fetchAgencyBookings(1, filterStatus);
                    }}
                    className="bg-white p-2 rounded-lg shadow-md text-indigo-600 hover:bg-indigo-50 transition-colors"
                    title={sortDirection === "asc" ? "Sort Descending" : "Sort Ascending"}
                  >
                    {sortDirection === "asc" ? (
                      <FaSortAmountUp className="h-4 w-4" />
                    ) : (
                      <FaSortAmountDown className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Analytics Summary */}
        {showAnalytics && analytics && (
          <BookingAnalyticsSummary analytics={analytics} />
        )}
        {/* Bookings List Area - Replaced Table with Div for Cards */}
        <div className="space-y-5">
          {" "}
          {/* Container for the cards */}
          {loading && bookings.length === 0 ? ( // Initial Loader
            <div className="py-24 text-center">
              <FaSync className="animate-spin text-4xl mx-auto mb-4 text-indigo-500" />
              <p className="text-gray-500 font-medium text-lg">
                Loading bookings...
              </p>
            </div>
          ) : error ? ( // Error State
            <div className="bg-white rounded-xl shadow-lg p-10 text-center">
              {" "}
              {/* Wrap error in a card */}
              <div className="mx-auto w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-5">
                <FaExclamationTriangle className="h-8 w-8" />
              </div>
              <h3 className="font-semibold text-xl text-gray-800 mb-2">
                Oops! Something went wrong.
              </h3>
              <p className="text-red-600 mb-6">{error}</p>
              <button
                onClick={() => fetchAgencyBookings(currentPage, filterStatus)}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                <FaSync className="mr-2 h-4 w-4" /> Retry Loading
              </button>
            </div>
          ) : bookings.length === 0 ? ( // Empty State
            <div className="bg-white rounded-xl shadow-lg py-24 text-center">
              {" "}
              {/* Wrap empty state in a card */}
              <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-5">
                <FaInfoCircle className="h-8 w-8 text-indigo-500" />
              </div>
              <h3 className="text-gray-800 font-semibold text-xl mb-1">
                No Bookings Found
              </h3>
              <p className="text-gray-500">
                {filterStatus === "all"
                  ? "There are currently no bookings."
                  : `No bookings match the status "${filterStatus}".`}
              </p>
            </div>
          ) : (
            // Booking Cards List
            <AnimatePresence>
              {bookings.map((booking) => (
                <motion.div
                  key={booking._id}
                  layout // Enable smooth layout transitions on filter/sort
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, transition: { duration: 0.2 } }}
                  transition={{ duration: 0.4, ease: "easeOut" }}
                  // Card Styling
                  className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200/80 transition-opacity duration-300"
                >
                  <div className="p-4 sm:p-6">
                    {/* Responsive Card Layout: Flex column on small, row on medium+ */}
                    <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                      {/* Section 1: Customer & Billboard (Takes available space) */}
                      <div className="flex-grow space-y-4 min-w-0">
                        {" "}
                        {/* min-w-0 prevents overflow issues with truncate */}
                        {/* Customer */}
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-sm ring-1 ring-white">
                            <FaUserCircle className="h-6 w-6" />
                          </div>
                          <div className="ml-3 min-w-0">
                            {" "}
                            {/* min-w-0 */}
                            <p
                              className="text-sm font-semibold text-gray-900 truncate"
                              title={
                                booking.customerId?.name || "Unknown Customer"
                              }
                            >
                              {booking.customerId?.name || "Unknown Customer"}
                            </p>
                            <p
                              className="text-xs text-gray-500 truncate"
                              title={
                                booking.customerId?.email ||
                                "No email available"
                              }
                            >
                              {booking.customerId?.email ||
                                "No email available"}
                            </p>
                          </div>
                        </div>
                        {/* Billboard */}
                        <div>
                          <h4
                            className="text-sm font-semibold text-gray-800 truncate"
                            title={
                              booking.billboardId?.title || "Untitled Billboard"
                            }
                          >
                            {booking?.billboardId?.title ||
                              "Untitled Billboard"}
                          </h4>
                          <p
                            className="text-xs text-gray-500 flex items-center gap-1 mt-0.5"
                            title={
                              booking.billboardId?.location ||
                              "Unknown Location"
                            }
                          >
                            <FaMapMarkerAlt className="h-3 w-3 text-gray-400 flex-shrink-0" />
                            <span className="truncate">
                              {booking.billboardId?.location ||
                                "Unknown Location"}
                            </span>
                          </p>
                        </div>
                      </div>

                      {/* Divider (visible on medium screens up) */}
                      <div className="hidden md:block h-auto w-px bg-gray-200 self-stretch mx-2"></div>

                      {/* Section 2: Dates & Payment Info (Fixed width on medium+) */}
                      <div className="flex-shrink-0 md:w-44 space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-gray-700">
                          <FaClock className="h-4 w-4 text-gray-400 flex-shrink-0" />
                          <div>
                            <span>{formatDate(booking.startDate)}</span>
                            <span className="text-gray-400 mx-1">-</span>
                            <span>{formatDate(booking.endDate)}</span>
                          </div>
                        </div>
                        <div className="text-xs text-gray-500 pl-6">
                          ({booking.duration} days)
                        </div>
                        <div className="flex items-center gap-2 font-medium text-emerald-600 pl-1 pt-1">
                          <FaDollarSign className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                          <span>{formatCurrency(booking.totalAmount)}</span>
                        </div>
                        {booking.paymentMethod && (
                          <div className="flex items-center gap-2 text-gray-600 pl-1">
                            <FaRegCreditCard className="h-4 w-4 text-gray-400 flex-shrink-0" />
                            <span className="text-xs capitalize">{booking.paymentMethod}</span>
                          </div>
                        )}
                      </div>

                      {/* Divider (visible on medium screens up) */}
                      <div className="hidden md:block h-auto w-px bg-gray-200 self-stretch mx-2"></div>

                      {/* Section 3: Status & Actions (Fixed width on medium+, aligned right) */}
                      <div className="flex-shrink-0 md:w-40 flex flex-col items-start md:items-end gap-2">
                        {/* Status */}
                        <div className="w-full flex md:justify-end">
                          {getStatusChip(
                            booking.status,
                            booking.paymentStatus,
                            booking.endDate
                          )}
                        </div>

                        {/* Payment Status */}
                        <div className="w-full flex md:justify-end">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                              booking.paymentStatus === "succeeded"
                                ? "bg-green-100 text-green-800 ring-1 ring-inset ring-green-600/20"
                                : booking.paymentStatus === "failed"
                                ? "bg-red-100 text-red-800 ring-1 ring-inset ring-red-600/20"
                                : "bg-yellow-100 text-yellow-800 ring-1 ring-inset ring-yellow-600/20"
                            }`}
                          >
                            <FaRegMoneyBillAlt className="h-3 w-3" />
                            {booking.paymentStatus.charAt(0).toUpperCase() + booking.paymentStatus.slice(1)}
                          </span>
                        </div>

                        {booking.status === "rejected" &&
                          booking.rejectionReason && (
                            <p
                              className="mt-1 text-xs text-red-600 italic text-left md:text-right w-full truncate"
                              title={`Rejection Reason: ${booking.rejectionReason}`}
                            >
                              Reason: {booking.rejectionReason}
                            </p>
                          )}

                        {/* Action Button */}
                        <div className="mt-2 md:mt-1 w-full flex md:justify-end gap-2">
                          <button
                            onClick={() => {
                              setSelectedBooking(booking);
                              setImagePreviewOpen(true);
                            }}
                            className="inline-flex items-center justify-center px-3 py-1.5 border border-indigo-300 rounded-md shadow-sm text-xs font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all"
                          >
                            <FaEye className="h-3.5 w-3.5 mr-1" />
                            View
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
          {/* Pagination Controls (adjust if needed for card layout) */}
          {!loading && !error && bookings.length > 0 && totalPages > 1 && (
            <div className="flex justify-between items-center px-1 py-4 mt-6">
              {" "}
              {/* Removed bg/border, simple spacing */}
              <span className="text-sm text-gray-600">
                Page {currentPage} of {totalPages}
              </span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1 || loading}
                  className="p-2 rounded-md bg-white border border-gray-300 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  aria-label="Previous Page"
                >
                  <FaChevronLeft className="w-4 h-4 text-gray-600" />
                </button>
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages || loading}
                  className="p-2 rounded-md bg-white border border-gray-300 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  aria-label="Next Page"
                >
                  <FaChevronRight className="w-4 h-4 text-gray-600" />
                </button>
              </div>
            </div>
          )}
        </div>{" "}
        {/* End Bookings List Area */}
      </div>

      {/* Image Preview Modal */}
      <ImagePreviewModal
        isOpen={imagePreviewOpen}
        onClose={() => {
          setImagePreviewOpen(false);
          setSelectedBooking(null);
        }}
        booking={selectedBooking}
      />
    </div>
  );
};

export default BookingRecordPage;
