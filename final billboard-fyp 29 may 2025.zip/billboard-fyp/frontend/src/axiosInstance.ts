import axios from "axios";
import { toast } from "react-hot-toast";
import { useAuthStore } from "./stores/authStore";

const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:4000",
  timeout: 30000,
  headers: {
    "Content-Type": "application/json",
  },
});

axiosInstance.interceptors.request.use(
  (config) => {
    // Skip authentication for public routes and auth routes
    if (
      config.url?.includes("/public/") ||
      config.url?.includes("/auth/login") ||
      config.url?.includes("/auth/signup")
    ) {
      return config;
    }

    // Get token from localStorage
    const token = localStorage.getItem("token");

    // Add Authorization header if token exists
    if (token && token.trim() !== "") {
      // Ensure token is properly formatted
      const formattedToken = token.startsWith("Bearer ")
        ? token
        : `Bearer ${token}`;
      config.headers.Authorization = formattedToken;
    }

    return config;
  },
  (error) => {
    console.error("Request interceptor error:", error);
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // Handle network errors
    if (error.code === "ERR_NETWORK") {
      toast.error(
        "Unable to connect to server. Please check your internet connection or try again later."
      );
      return Promise.reject(error);
    }

    // Skip auth error handling for auth routes (login/signup)
    const isAuthRoute = error.config?.url?.includes("/auth/");
    if (isAuthRoute) {
      return Promise.reject(error);
    }

    // Handle authentication errors
    if (error.response?.status === 401) {
      // Clear auth state
      useAuthStore.getState().logout();

      // Show toast notification
      toast.error("Your session has expired. Please log in again.");

      // Redirect to login page if not already there
      if (!window.location.pathname.startsWith("/auth/")) {
        window.location.href = "/auth/signin";
      }
    }
    // Handle forbidden errors (403) differently - don't log out
    else if (error.response?.status === 403) {
      // Show toast notification but don't log out
      toast.error(
        error.response.data?.message ||
          "You don't have permission to access this resource"
      );
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;
