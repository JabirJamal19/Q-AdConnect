import { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useAuthStore } from "./stores/authStore";
import NotificationChecker from "./QAdBillboardWebsite/components/Notifications/NotificationChecker";
import AuthLayout from "./layouts/AuthLayout";
import UserLayout from "./layouts/UserLayout";
import DefaultLayout from "./layouts/DefaultLayout";
import Loader from "./common/Loader/index";
import PageTitle from "./AgencyDashboard/components/PageTitle/PageTitle";
import SignIn from "./AgencyDashboard/pages/AuthenticationPage/SignIn";
import SignUp from "./AgencyDashboard/pages/AuthenticationPage/SignUp";
import UpdatePassword from "./AgencyDashboard/pages/AuthenticationPage/UpdatePassword";
import ResetPassword from "./AgencyDashboard/pages/AuthenticationPage/ResetPassword";
import ECommerce from "./AgencyDashboard/pages/Dashboard/ECommerce";
import ReportsPage from "./AgencyDashboard/pages/AdminReportPage/AdminReportPage";
import BillboardPage from "./AgencyDashboard/pages/BillboardPage/BillboardPage";
import UsersManagementPage from "./AgencyDashboard/pages/UsersManagementPage/UsersManagementPage";
import QAdBillboardWebsite from "./QAdBillboardWebsite/QAdBillboardWebsite";
import BillboardListPage from "./QAdBillboardWebsite/pages/BillboardListPage/BillboardListPage";
import BillboardDetail from "./QAdBillboardWebsite/pages/BillboardDetailPage/BillboardDetail";
import BookingandSubmissionPage from "./QAdBillboardWebsite/pages/BookingandSubmissionPage/BookingandSubmissionPage";
import PaymentPage from "./QAdBillboardWebsite/pages/PaymentPage/PaymentPage";
import UserProfile from "./QAdBillboardWebsite/pages/UserProfile/UserProfile";
import ReportPage from "./QAdBillboardWebsite/pages/UserReportPage/UserReportPage";
import UserBookingPage from "./QAdBillboardWebsite/pages/Userbooking/userBookingPage";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import BookingRecordPage from "./AgencyDashboard/pages/BookingRecordPage/BookingRecordPage";
import AgencyManagementPage from "./AgencyDashboard/pages/AgencyManagement/AgencyManagementPage";
import BookingReviewPage from "./AgencyDashboard/pages/WorkflowManagement/ContentReviewComponent";
import RevenueManagementPage from "./AgencyDashboard/pages/RevenueManagement/RevenueManagementPage";
import AdminRevenuePage from "./AgencyDashboard/pages/AdminRevenue/AdminRevenuePage";
import AgencyProfilePage from "./AgencyDashboard/pages/AgencyProfile/AgencyProfilePage";
import { WorkflowManagementPage } from "./AgencyDashboard/pages/WorkflowManagement";

const stripePromise = loadStripe(
  ""
).catch((err) => {
  console.warn(
    "Stripe initialization error (this is expected if using an ad blocker):",
    err
  );
  return null;
});

const DefaultRedirect = () => {
  const localToken = localStorage.getItem("token");
  const localUser = localStorage.getItem("user");
  let parsedUser = null;

  try {
    if (localUser) {
      parsedUser = JSON.parse(localUser);
    }
  } catch (e) {
    console.error("Error parsing user from localStorage:", e);
  }

  if (!localToken || !parsedUser) {
    return <Navigate to="/auth" replace />;
  }

  if (parsedUser.role === "customer") {
    return <Navigate to="/" replace />;
  }

  if (parsedUser.role === "agency" || parsedUser.role === "admin") {
    return <Navigate to="/dashboard" replace />;
  }
  return <Navigate to="/auth" replace />;
};

function App() {
  const PrivateRoute = ({ children }: { children: JSX.Element }) => {
    const localToken = localStorage.getItem("token");
    const localUser = localStorage.getItem("user");
    let parsedUser = null;

    try {
      if (localUser) {
        parsedUser = JSON.parse(localUser);
      }
    } catch (e) {
      console.error("Error parsing user from localStorage:", e);
    }

    if (!localToken || !parsedUser) {
      return <Navigate to="/auth" replace />;
    }

    if (parsedUser.role === "customer") {
      return <Navigate to="/" replace />;
    }

    if (parsedUser.role === "agency" || parsedUser.role === "admin") {
      return children;
    }
    return <Navigate to="/auth" replace />;
  };

  const [loading, setLoading] = useState<boolean>(true);
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userStr = localStorage.getItem("user");

    if (token && userStr) {
      try {
        const user = JSON.parse(userStr);
        useAuthStore.getState().setAuth(user, token);
      } catch (e) {
        console.error("Error parsing user from localStorage:", e);
      }
    }
  }, []);

  useEffect(() => {
    setTimeout(() => setLoading(false), 1000);
  }, []);

  return loading ? (
    <Loader />
  ) : (
    <Elements
      stripe={stripePromise}
      options={{
        loader: "auto",
      }}
    >
      <NotificationChecker />
      <Routes>
        <Route path="/" element={<UserLayout />}>
          <Route index element={<QAdBillboardWebsite />} />
          <Route path="billboard-list" element={<BillboardListPage />} />
          <Route path="billboards/:id" element={<BillboardDetail />} />
          <Route
            path="billboards/:id/book"
            element={<BookingandSubmissionPage />}
          />
          <Route path="bookings/:bookingId/payment" element={<PaymentPage />} />
          <Route path="payment/:bookingId" element={<PaymentPage />} />
          <Route path="profile" element={<UserProfile />} />
          <Route path="user-booking" element={<UserBookingPage />} />
          <Route path="report-page" element={<ReportPage />} />
        </Route>

        <Route path="auth" element={<AuthLayout />}>
          <Route index element={<SignIn />} />
          <Route path="signin" element={<SignIn />} />
          <Route path="signup" element={<SignUp />} />
          <Route path="update-password" element={<UpdatePassword />} />
          <Route path="reset-password" element={<ResetPassword />} />
        </Route>

        <Route
          path="dashboard"
          element={
            <PrivateRoute>
              <DefaultLayout />
            </PrivateRoute>
          }
        >
          <Route
            index
            element={
              <>
                <PageTitle title="Dashboard" />
                <ECommerce />
              </>
            }
          />
          <Route
            path="agency-profile"
            element={
              <>
                <PageTitle title="Agency Profile" />
                <AgencyProfilePage />
              </>
            }
          />
          <Route
            path="agencies"
            element={
              <>
                <PageTitle title="Agencies " />
                <AgencyManagementPage />
              </>
            }
          />
          <Route
            path="billboard"
            element={
              <>
                <PageTitle title="Billboard" />
                <BillboardPage />
              </>
            }
          />
          <Route
            path="content-review"
            element={
              <>
                <PageTitle title="Content Review" />
                <BookingReviewPage />
              </>
            }
          />
          <Route
            path="users"
            element={
              <>
                <PageTitle title="Agency Users Management" />
                <UsersManagementPage />
              </>
            }
          />
          <Route
            path="revenue"
            element={
              <>
                <PageTitle title="Revenue Management" />
                <RevenueManagementPage />
              </>
            }
          />
          <Route
            path="total-revenue"
            element={
              <>
                <PageTitle title="Total Revenue" />
                <AdminRevenuePage />
              </>
            }
          />

          <Route
            path="user-reports"
            element={
              <>
                <PageTitle title="Report" />
                <ReportsPage />
              </>
            }
          />
          <Route
            path="booking-records"
            element={
              <>
                <PageTitle title="Booking Records" />
                <BookingRecordPage />
              </>
            }
          />
          <Route
            path="workflow"
            element={
              <>
                <PageTitle title="Booking Workflow" />
                <WorkflowManagementPage />
              </>
            }
          />
        </Route>

        <Route path="*" element={<DefaultRedirect />} />
      </Routes>
    </Elements>
  );
}

export default App;
