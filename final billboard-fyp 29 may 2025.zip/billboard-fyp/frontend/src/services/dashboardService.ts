import axios from 'axios';

interface DashboardData {
  users: number;
  agency: number;
  billboards: number;
  status: number;
  message: string;
}

export const fetchDashboardData = async (): Promise<DashboardData> => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Authentication required');
    }

    const response = await axios.get('/api/dashboard', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    return response.data;
  } catch (error: any) {
    console.error('Error fetching dashboard data:', error);
    throw new Error(error.response?.data?.message || 'Failed to fetch dashboard data');
  }
};
