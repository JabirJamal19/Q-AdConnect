import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        target: process.env.VITE_API_URL || "http://localhost:4000",
        changeOrigin: true,
      },
      "/public": {
        target: process.env.VITE_API_URL || "http://localhost:4000",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/public/, "/public"),
        configure: (proxy, _options) => {
          // Limit error logging to avoid console spam
          let errorCount = 0;
          const maxErrors = 5;

          proxy.on("error", (err, _req, _res) => {
            if (errorCount < maxErrors) {
              console.log("proxy error", err);
              errorCount++;

              if (errorCount === maxErrors) {
                console.log(
                  "Suppressing further proxy errors to avoid console spam"
                );
              }
            }
          });

          // Only log non-200 responses
          proxy.on("proxyRes", (proxyRes, req, _res) => {
            if (proxyRes.statusCode !== 200) {
              console.log(
                "Non-200 Response from Target:",
                proxyRes.statusCode,
                req.url
              );
            }
          });
        },
      },
      "/files": {
        target: process.env.VITE_API_URL || "http://localhost:4000",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/files/, "/public/files"),
      },
    },
  },
  resolve: {
    dedupe: ["react", "react-dom", "react-icons"],
    alias: {
      // Use our custom components instead of flowbite-react
      "flowbite-react": "src/components/ui",
    },
  },
  optimizeDeps: {
    include: ["react-icons/hi2", "react-icons/fa", "react-icons/md"],
  },
  build: {
    commonjsOptions: {
      transformMixedEsModules: true,
    },
  },
});
