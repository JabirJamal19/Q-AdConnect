const mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate-v2");

const billboardSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    status: {
      type: String,
      enum: ["active", "inactive"],
      default: "active",
    },
    location: { type: String, required: true },
    city: { type: String, required: true },
    area: { type: String, required: true },
    price: { type: Number, required: true },
    contact: { type: String, required: true },
    size: { type: String, required: true },
    imageUrl: { type: String, required: true },
    agencyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Users",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

billboardSchema.plugin(mongoosePaginate);
const Billboard = mongoose.model("Billboard", billboardSchema);
module.exports = Billboard;
