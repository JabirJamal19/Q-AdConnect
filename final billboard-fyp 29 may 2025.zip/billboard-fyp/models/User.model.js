const mongoose = require("mongoose");
const { Schema } = mongoose;
const bcrypt = require("bcryptjs");

const ROLES = {
  ADMIN: "admin",
  AGENCY: "agency",
  CUSTOMER: "customer",
};

const usersSchema = new Schema(
  {
    name: {
      type: String,
      maxlength: 128,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      match: /^\S+@\S+\.\S+$/,
      required: true,
      trim: true,
      lowercase: true,
    },
    password: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      enum: Object.values(ROLES),
      required: true,
    },
    agencyName: {
      type: String,
    },
    ntnNumber: {
      type: String,
    },
    address: {
      type: String,
      trim: true,
    },
    city: {
      type: String,
      trim: true,
    },
    agencyImage: {
      type: String,
      trim: true,
    },
    agencyDoc: {
      type: [String],
      trim: true,
    },
    approvalStatus: {
      type: String,
      enum: ["pending", "approved", "rejected"],
      default: "pending",
    },
    profileUrl: {
      type: String,
    },
    coverImage: {
      type: String,
      trim: true,
    },
    bio: {
      type: String,
      trim: true,
    },
    phone: {
      type: String,
      trim: true,
    },
    status: {
      type: String,
      enum: ["active", "inactive"],
      default: "active",
    },
    otp: { type: Number, default: null },
    otpExpiry: { type: Date, default: null },
    reports: [
      {
        type: Schema.Types.ObjectId,
        ref: "Reports",
      },
    ],
    stripeCustomerId: { type: String, default: null },
    subscriptionPlan: { type: String, default: "Standard" },
    subscriptionId: { type: String, default: null },
    amount: { type: Number, default: 0 },
    subscriptionStatus: {
      type: String,
      enum: ["active", "inactive", "pending"],
      default: "pending",
    },
  },
  {
    timestamps: true,
  }
);

usersSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();

  try {
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

const Users = mongoose.model("Users", usersSchema);

module.exports = { Users, ROLES };
