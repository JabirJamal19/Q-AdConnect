const { Users, ROLES } = require("./User.model");
const SupportThread = require("./Support.model");
const Billboard = require("./Billboard.model");

module.exports = {
  Users,
  ROLES,
  SupportThread,
  Billboard,
};
