// models/booking.model.js
const mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate-v2");

const bookingSchema = new mongoose.Schema(
  {
    billboardId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Billboard",
      required: true,
    },
    customerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Users",
      required: true,
    },
    agencyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Users",
      required: true,
    },
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
      required: true,
    },
    duration: {
      type: Number,
      required: true,
    },
    totalAmount: {
      type: Number,
      required: true,
    },
    adImageUrls: [
      {
        type: String,
        required: true,
      },
    ],
    status: {
      type: String,
      enum: [
        "pending",
        "approved",
        "rejected",
        "paid",
        "payment_verified",
        "payment_rejected",
        "payment_rejected_resubmit",
        "completed",
        "cancelled",
        "content_pending",
        "content_approved",
        "content_rejected",
        "content_rejected_resubmit",
        "live",
      ],
      default: "pending",
    },
    paymentIntentId: {
      type: String,
    },
    paymentStatus: {
      type: String,
      enum: ["pending", "succeeded", "failed"],
      default: "pending",
    },
    paymentMethod: {
      type: String,
      enum: ["jazzcash", "easypais", "nayapay", "stripe", "other"],
    },
    paymentProofUrl: {
      type: String,
    },
    customerPhone: {
      type: String,
    },
    paymentDetails: {
      type: Object,
    },
    rejectionReason: {
      type: String,
    },
    feedbackMessage: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

bookingSchema.plugin(mongoosePaginate);

bookingSchema.index({ customerId: 1, status: 1 });
bookingSchema.index({ agencyId: 1, status: 1 });
bookingSchema.index({ billboardId: 1, status: 1, endDate: 1 });

module.exports =
  mongoose.models.Booking || mongoose.model("Booking", bookingSchema);
