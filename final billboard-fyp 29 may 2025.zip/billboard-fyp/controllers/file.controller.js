module.exports = {
  upload: async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      const urls = {
        agencyImage: req.files["agencyImage"]?.[0]?.filename,
        agencyDoc: req.files["agencyDoc"]?.[0]?.filename,
      };
      return res.status(200).send({ urls });
    } catch (err) {
      res
        .status(err.status || 500)
        .send(err.message || "Something went wrong!");
    }
  },
  uploadMultiple: async (req, res) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }
      const fileUrls = req.files.map((file) => file.filename);
      return res.status(200).send({ urls: fileUrls });
    } catch (err) {
      res
        .status(err.status || 500)
        .send(err.message || "Something went wrong!");
    }
  },
};
