const Billboard = require("../models/Billboard.model");
const { validateBillboard } = require("../validations/billboard.validation");

const billboardsController = {
  publicList: async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 10;
      const { city, location, priceMin, priceMax, size, search } = req.query;

      const query = {
        status: "active",
      };

      // Add filters if they exist
      if (city) query.city = new RegExp(city, "i");
      if (location) query.location = new RegExp(location, "i");
      if (size) query.size = size;
      if (priceMin || priceMax) {
        query.price = {};
        if (priceMin) query.price.$gte = parseInt(priceMin);
        if (priceMax) query.price.$lte = parseInt(priceMax);
      }
      if (search) {
        query.$or = [
          { title: new RegExp(search, "i") },
          { description: new RegExp(search, "i") },
        ];
      }

      const options = {
        page,
        limit,
        sort: { createdAt: -1 },
        select: "-__v -agencyId",
        populate: { path: "agencyId", select: "name" },
      };

      const result = await Billboard.paginate(query, options);

      res.json({
        status: 1,
        message: "Active billboards retrieved successfully",
        data: result.docs,
        total: result.totalDocs,
        totalPages: result.totalPages,
        page: result.page,
      });
    } catch (error) {
      console.error("Error in publicList:", error);
      res.status(500).json({
        status: 0,
        message: "Failed to retrieve billboards",
        error: error.message,
      });
    }
  },

  publicDetail: async (req, res) => {
    try {
      const billboard = await Billboard.findOne({
        _id: req.params.id,
       
      }).select("-__v -agencyId"); 

      if (!billboard) {
        return res.status(404).json({
          status: 0,
          message: "Billboard not found",
        });
      }
      res.json({
        status: 1,
        data: billboard,
      });
    } catch (error) {
      console.error("Error in publicDetail:", error);
     
      if (error.name === "CastError") {
        return res
          .status(400)
          .json({ status: 0, message: "Invalid Billboard ID format" });
      }
      res.status(500).json({
        status: 0,
        message: "Failed to retrieve billboard details",
        error: error.message,
      });
    }
  },

  
  list: async (req, res) => {
   
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 10;
      const agencyId = req.user._id; 

      const options = {
        page,
        limit,
        sort: { createdAt: -1 },
        select: "-__v", 
      };

      
      const result = await Billboard.paginate({ agencyId: agencyId }, options);

      res.json({
        status: 1,
        message: "Your billboards retrieved successfully",
        data: result.docs,
        total: result.totalDocs,
        totalPages: result.totalPages,
        page: result.page,
      });
    } catch (error) {
      console.error("Error in agency list:", error);
      res.status(500).json({
        status: 0,
        message: "Failed to retrieve your billboards",
        error: error.message,
      });
    }
  },

  detail: async (req, res) => {
    
    try {
      const billboard = await Billboard.findOne({
        _id: req.params.id,
        agencyId: req.user._id,
      });
      if (!billboard) {
        return res.status(404).json({
          status: 0,
          message: "Billboard not found or you don't have permission.",
        });
      }
      res.json({
        status: 1,
        data: billboard,
      });
    } catch (error) {
      console.error("Error in agency detail:", error);
      if (error.name === "CastError") {
        return res
          .status(400)
          .json({ status: 0, message: "Invalid Billboard ID format" });
      }
      res.status(500).json({
        status: 0,
        message: "Failed to retrieve billboard details",
        error: error.message,
      });
    }
  },

  create: async (req, res) => {
    try {
      console.log("Received billboard data:", req.body);
      console.log("User from request:", req.user);
      console.log("Auth header:", req.headers.authorization ? "Present" : "Missing");

     
      if (!req.user || !req.user._id) {
        console.error("User not authenticated or missing _id");
        return res.status(401).json({
          status: 0,
          message: "Authentication required. User not found or missing ID.",
        });
      }

     
      if (req.user.role !== 'agency') {
        console.error("User is not an agency:", req.user.role);
        return res.status(403).json({
          status: 0,
          message: "Only agencies can create billboards.",
        });
      }

      
      let price;
      try {
        price = Number(req.body.price);
        if (isNaN(price)) {
          return res.status(400).json({
            status: 0,
            message: "Price must be a valid number",
          });
        }
      } catch (err) {
        return res.status(400).json({
          status: 0,
          message: "Invalid price format",
        });
      }

    
      const billboardData = {
        ...req.body,
        price: price,
        agencyId: req.user._id, 
        status: req.body.status || "active", 
      };

      console.log("Processed billboard data:", billboardData);

  
      const { error } = validateBillboard(billboardData);
      if (error) {
        console.log("Validation error:", error.details);
        return res.status(400).json({
          status: 0,
          message: "Validation failed",
          errors: error.details.map((detail) => detail.message),
        });
      }

      const billboard = new Billboard(billboardData);

      await billboard.save();

      res.status(201).json({
        status: 1,
        message: "Billboard created successfully",
        data: billboard,
      });
    } catch (error) {
      console.error("Error creating billboard:", error);

      
      if (error.name === 'ValidationError' && error.errors) {
       
        const validationErrors = Object.values(error.errors).map(err => err.message);
        return res.status(400).json({
          status: 0,
          message: "Validation failed",
          errors: validationErrors
        });
      } else if (error.name === 'CastError') {
        
        return res.status(400).json({
          status: 0,
          message: `Invalid ${error.path}: ${error.value}`
        });
      } else {
        
        return res.status(400).json({
          status: 0,
          message: error.message || "Failed to create billboard",
        });
      }
    }
  },

  update: async (req, res) => {
    try {
      const updateData = { ...req.body };
   
      delete updateData.agencyId;

    
      if (updateData.price !== undefined) {
        const price = Number(updateData.price);
        if (isNaN(price)) {
          return res.status(400).json({
            status: 0,
            message: "Invalid price format. Price must be a number.",
          });
        }
        updateData.price = price;
      }

      const billboard = await Billboard.findOneAndUpdate(
        { _id: req.params.id, agencyId: req.user._id }, // En
        updateData,
        { new: true, runValidators: true } 
      );
      if (!billboard) {
        return res.status(404).json({
          status: 0,
          message: "Billboard not found or you don't have permission.",
        });
      }
      res.json({
        status: 1,
        message: "Billboard updated successfully",
        data: billboard,
      });
    } catch (error) {
      console.error("Error updating billboard:", error);
      if (error.name === "ValidationError") {
        return res.status(400).json({
          status: 0,
          message: "Validation failed",
          errors: error.errors,
        });
      }
      if (error.name === "CastError") {
        return res
          .status(400)
          .json({ status: 0, message: "Invalid Billboard ID format" });
      }
      res.status(500).json({
        status: 0,
        message: "Failed to update billboard",
        error: error.message,
      });
    }
  },

  deleteBillboard: async (req, res) => {
    try {
     

      const billboard = await Billboard.findOneAndDelete({
        _id: req.params.id,
        agencyId: req.user._id, // Ensure agency owns it
      });
      if (!billboard) {
        return res.status(404).json({
          status: 0,
          message: "Billboard not found or you don't have permission.",
        });
      }
     
      res.json({
        status: 1,
        message: "Billboard deleted successfully",
      });
    } catch (error) {
      console.error("Error deleting billboard:", error);
      if (error.name === "CastError") {
        return res
          .status(400)
          .json({ status: 0, message: "Invalid Billboard ID format" });
      }
      res.status(500).json({
        status: 0,
        message: "Failed to delete billboard",
        error: error.message,
      });
    }
  },
};

module.exports = billboardsController;
