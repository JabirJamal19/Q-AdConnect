const { Users } = require("../models/User.model");
const { sendEmailMessage } = require("../helper/email.helper");
const { STRIPE_SECRET_KEY } = require("../config/constant");
const Stripe = require("stripe");
const stripe = new Stripe(STRIPE_SECRET_KEY);
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

module.exports = {
  signup: async (req, res) => {
    try {
      console.log("Signup request received:", {
        body: req.body,
        files: req.files ? Object.keys(req.files) : "No files",
      });

      const requiredFields = ["name", "email", "password", "role"];
      const missingFields = requiredFields.filter((field) => !req.body[field]);

      if (missingFields.length > 0) {
        console.log("Missing required fields:", missingFields);
        return res.status(200).json({
          status: 0,
          message: `Required fields cannot be empty: ${missingFields.join(
            ", "
          )}`,
        });
      }

      const {
        name,
        email,
        password,
        role,
        agencyName,
        ntnNumber,
        address,
        city,
      } = req.body;

      if (role === "agency") {
        const agencyFields = ["ntnNumber", "address", "city"];
        const missingAgencyFields = agencyFields.filter(
          (field) => !req.body[field]
        );

        console.log("Agency validation:", {
          missingFields: missingAgencyFields,
          hasAgencyImage: !!req.files?.agencyImage,
          agencyImageLength: req.files?.agencyImage?.length,
        });

        // Check if agency image is provided
        if (missingAgencyFields.length > 0) {
          return res.status(200).json({
            status: 0,
            message: `Agency-specific fields cannot be empty: ${missingAgencyFields.join(
              ", "
            )}`,
          });
        }

        // Check if agency image is provided separately
        if (!req.files?.agencyImage) {
          console.log("Agency image is missing");
          return res.status(200).json({
            status: 0,
            message: "Agency image is required",
          });
        }
      }

      const existingUser = await Users.findOne({ email, role });
      if (existingUser) {
        return res.status(200).json({
          status: 0,
          message: "Email already exists",
        });
      }

      const approvalStatus = role === "agency" ? "pending" : "approved";
      const customer = await stripe.customers.create({ email });
      const userData = {
        name,
        email,
        password,
        role,
        agencyName: name,
        ntnNumber,
        address,
        city,
        approvalStatus,
        agencyImage: req.files?.agencyImage?.[0]?.filename,
        agencyDoc: req.files?.agencyDoc?.map((file) => file.filename),
        stripeCustomerId: customer.id,
        amount: 500,
      };

      let user = await Users.create(userData);
      if (role === "agency") {
        const { priceId, paymentMethodId } = req.body;

        await stripe.paymentMethods.attach(paymentMethodId, {
          customer: customer.id,
        });
        await stripe.customers.update(customer.id, {
          invoice_settings: { default_payment_method: paymentMethodId },
        });

        const subscription = await stripe.subscriptions.create({
          customer: customer.id,
          items: [{ price: priceId }],
          expand: ["latest_invoice.payment_intent"],
        });
      }

      user = user.toJSON();
      delete user.password;
      return res.status(200).json({ status: 1, user });
    } catch (err) {
      console.error("Signup error:", err);

      // Check if it's a Stripe error
      if (err.type && err.type.startsWith("Stripe")) {
        return res.status(400).json({
          status: 0,
          message: err.message || "Payment processing error",
          error: err.type,
        });
      }

      // Check if it's a validation error
      if (err.name === "ValidationError") {
        return res.status(400).json({
          status: 0,
          message: "Validation error",
          errors: Object.values(err.errors).map((e) => e.message),
        });
      }

      // Generic error response
      return res.status(err.status || 500).json({
        status: 0,
        message: err.message || "Something went wrong during signup!",
      });
    }
  },

  login: async (req, res) => {
    try {
      const { email, password, role } = req.body;

      // Enhanced validation with detailed error messages
      if (!email || !password) {
        console.log("Login failed: Missing email or password");
        return res
          .status(400)
          .json({ status: 0, message: "Email and password are required" });
      }

      if (typeof email !== "string" || email.trim() === "") {
        console.log("Login failed: Invalid email format");
        return res
          .status(400)
          .json({ status: 0, message: "Valid email is required" });
      }

      if (!role || typeof role !== "string" || role.trim() === "") {
        console.log("Login failed: Missing or invalid role");
        return res
          .status(400)
          .json({ status: 0, message: "Valid role is required" });
      }

      // Log the login attempt with role
      console.log(`Login attempt for ${email} with role ${role}`);

      // Find user and explicitly include password
      let user = await Users.findOne({ email, role }).select("+password");

      if (!user) {
        console.log(`User not found: ${email} with role ${role}`);
        return res
          .status(401)
          .json({ status: 0, message: "Invalid email or role" });
      }

      // Compare password using bcrypt
      console.log("Login attempt - Password verification for:", user.email);

      const passwordMatched = await bcrypt.compare(password, user.password);
      if (!passwordMatched) {
        console.log("Password match failed for user:", user.email);
        return res.status(401).json({ status: 0, message: "Invalid password" });
      }

      // Check agency approval status
      if (user.role === "agency") {
        console.log(
          `Agency login: ${user.email}, approval status: ${user.approvalStatus}`
        );

        if (user.approvalStatus === "pending") {
          return res.status(403).json({
            status: 0,
            message: "Your account is pending approval from admin!",
          });
        }
        if (user.approvalStatus === "rejected") {
          return res.status(403).json({
            status: 0,
            message:
              "Your account has been rejected. You may reapply after 1 month!",
          });
        }
      }

      // Convert to plain object and remove password
      user = user.toJSON();
      delete user.password;

      // Generate JWT token with proper payload structure
      const tokenPayload = {
        _id: user._id,
        email: user.email,
        role: user.role,
        name: user.name,
      };

      const token = jwt.sign(tokenPayload, process.env.JWT_SECRET, {
        expiresIn: "1d",
        algorithm: "HS256",
      });

      console.log(`Login successful: ${user.email} (${user.role})`);

      return res.status(200).json({
        status: 1,
        user,
        token,
        message: "Login successful",
      });
    } catch (err) {
      console.error("Login error:", err);
      return res.status(500).json({
        status: 0,
        message: err.message || "Something went wrong!",
      });
    }
  },

  sendResetPasswordOtp: async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({
          status: 0,
          message: "Email is required",
        });
      }
      // Generate and send OTP logic here
      // ... implementation ...
      res.status(200).json({
        status: 1,
        message: "OTP sent successfully",
      });
    } catch (err) {
      res.status(500).json({
        status: 0,
        message: err.message || "Failed to send OTP",
      });
    }
  },

  verifyOtpAndResetPassword: async (req, res) => {
    try {
      const { email, otp, newPassword } = req.body;
      if (!email || !otp || !newPassword) {
        return res.status(400).json({
          status: 0,
          message: "Email, OTP and new password are required",
        });
      }
      // Verify OTP and reset password logic here
      // ... implementation ...
      res.status(200).json({
        status: 1,
        message: "Password reset successfully",
      });
    } catch (err) {
      res.status(500).json({
        status: 0,
        message: err.message || "Failed to reset password",
      });
    }
  },

  updatePassword: async (req, res) => {
    try {
      const { password, newpassword, confirmpassword } = req.body;

      // Validate input
      if (!password || !newpassword || !confirmpassword) {
        return res.status(400).json({
          status: 0,
          message: "All fields are required",
        });
      }

      // Check if new password and confirm password match
      if (newpassword !== confirmpassword) {
        return res.status(400).json({
          status: 0,
          message: "New password and confirm password do not match",
        });
      }

      // Find user with password field included
      const user = await Users.findById(req.user._id).select("+password");
      if (!user) {
        return res.status(404).json({
          status: 0,
          message: "User not found",
        });
      }

      // Verify current password
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(400).json({
          status: 0,
          message: "Current password is incorrect",
        });
      }

      // Hash new password with salt
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash(newpassword, salt);

      // Log password update for debugging
      console.log("Password update for user:", user.email);
      console.log(
        "Old password hash (partial):",
        user.password.substring(0, 10) + "..."
      );
      console.log(
        "New password hash (partial):",
        hashedPassword.substring(0, 10) + "..."
      );

      // Update password directly in the database to bypass any middleware issues
      const result = await Users.updateOne(
        { _id: user._id },
        { $set: { password: hashedPassword } }
      );

      console.log("Password update result:", result);

      return res.status(200).json({
        status: 1,
        message: "Password updated successfully",
      });
    } catch (err) {
      console.error("Password update error:", err);
      return res.status(500).json({
        status: 0,
        message: err.message || "Failed to update password",
      });
    }
  },
};
