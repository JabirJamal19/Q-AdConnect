const { Users } = require("../models/User.model");
const bcrypt = require("bcryptjs");

module.exports = {
  getMe: async (req, res) => {
    try {
      const user = await Users.findById(req.user._id).select("-password");
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.status(200).json({
        status: 1,
        user,
        message: "User profile fetched successfully",
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  },

  updateProfile: async (req, res) => {
    try {
      console.log("Update profile request body:", req.body);
      console.log("Update profile request file:", req.file);

      const user = await Users.findById(req.user._id);
      if (!user) {
        return res.status(404).json({
          status: 0,
          message: "User not found!",
        });
      }

      user.name = req.body.name || user.name;
      provided;
      user.bio = req.body.bio !== undefined ? req.body.bio : user.bio;
      user.phone = req.body.phone !== undefined ? req.body.phone : user.phone;
      user.address =
        req.body.address !== undefined ? req.body.address : user.address;
      user.city = req.body.city !== undefined ? req.body.city : user.city;

      console.log("Updating user with data:", {
        name: user.name,
        bio: user.bio,
        phone: user.phone,
        address: user.address,
        city: user.city,
      });

      if (req.file) {
        user.profileUrl = `/public/profiles/${req.file.filename}`;
        console.log(`Profile image uploaded: ${req.file.filename}`);
      }

      try {
        await user.save();
        console.log("User saved successfully");
      } catch (saveError) {
        console.error("Error saving user:", saveError);
        throw saveError;
      }

      
      const updatedUser = await Users.findById(user._id).select("-password");
      console.log("Updated user data being returned:", updatedUser);

      return res.status(200).json({
        status: 1,
        user: updatedUser,
        message: "Profile updated successfully",
      });
    } catch (err) {
      console.error("Profile update error:", err);
      return res.status(500).json({
        status: 0,
        message: err.message || "Something went wrong!",
      });
    }
  },

  getUsers: async (req, res) => {
    try {
      const { role } = req.query;
      const filter = role ? { role } : {};
      const users = await Users.find(filter).select("-password");

      return res.status(200).json({
        status: 1,
        users,
        message: "Users fetched successfully",
      });
    } catch (err) {
      return res
        .status(500)
        .json({ message: err.message || "Something went wrong!" });
    }
  },

  update: async (req, res) => {
    try {
      const user = await Users.findById(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found!" });
      }

  
      if (req.files?.agencyImage?.length > 0) {
        user.agencyImage = req.files.agencyImage[0].filename;
      }

    
      if (req.files?.coverImage?.length > 0) {
        user.coverImage = req.files.coverImage[0].filename;
      }

      Object.assign(user, req.body);
      await user.save();

      const userResponse = user.toJSON();
      delete userResponse.password;

      return res.status(200).json({
        status: 1,
        user: userResponse,
        message: "User updated successfully",
      });
    } catch (err) {
      return res
        .status(500)
        .json({ message: err.message || "Something went wrong!" });
    }
  },

  delete: async (req, res) => {
    try {
      const user = await Users.findByIdAndDelete(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found!" });
      }

      return res.status(200).json({
        status: 1,
        message: "User deleted successfully",
        user,
      });
    } catch (err) {
      return res
        .status(500)
        .json({ message: err.message || "Something went wrong!" });
    }
  },

  updateApprovalStatus: async (req, res) => {
    try {
      const { approvalStatus } = req.body;
      if (!["approved", "rejected", "pending"].includes(approvalStatus)) {
        return res.status(400).json({ message: "Invalid status provided!" });
      }

      const user = await Users.findOneAndUpdate(
        { _id: req.params.id, role: "agency" },
        { approvalStatus },
        { new: true }
      );

      if (!user) {
        return res.status(404).json({ message: "Agency user not found!" });
      }

      return res.status(200).json({
        status: 1,
        message: "Approval status updated successfully",
        user,
      });
    } catch (err) {
      return res
        .status(500)
        .json({ message: err.message || "Something went wrong!" });
    }
  },

  submitReport: async (req, res) => {
    try {
      const { title, description } = req.body;
      if (!title || !description) {
        return res
          .status(400)
          .json({ message: "Title and description are required" });
      }

      const user = await Users.findById(req.user._id);
      user.reports.push({
        title,
        description,
        status: "pending",
        createdAt: new Date(),
      });

      await user.save();
      return res.status(200).json({
        status: 1,
        message: "Report submitted successfully",
      });
    } catch (error) {
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },

  getAllReports: async (req, res) => {
    try {
      const user = await Users.findById(req.user._id).select("reports");
      return res.status(200).json({
        status: 1,
        reports: user.reports,
        message: "Reports fetched successfully",
      });
    } catch (error) {
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },

  deleteReport: async (req, res) => {
    try {
      const user = await Users.findOne({ "reports._id": req.params.reportId });
      if (!user) {
        return res.status(404).json({ message: "Report not found" });
      }

      user.reports = user.reports.filter(
        (report) => report._id.toString() !== req.params.reportId
      );
      await user.save();

      return res.status(200).json({
        status: 1,
        message: "Report deleted successfully",
      });
    } catch (error) {
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },

  cleanupInvalidReports: async (req, res) => {
    try {
      const users = await Users.find({
        reports: { $exists: true, $not: { $size: 0 } },
      });

      for (const user of users) {
        const validReports = user.reports.filter(
          (report) => report.title && report.description && report.createdAt
        );

        if (validReports.length !== user.reports.length) {
          user.reports = validReports;
          await user.save();
        }
      }

      return res.status(200).json({
        status: 1,
        message: "Invalid reports cleaned up successfully",
      });
    } catch (error) {
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },
};
