const Booking = require("../models/Booking.model");
const Billboard = require("../models/Billboard.model");
const { Users } = require("../models/User.model");
const mongoose = require("mongoose");
const { STRIPE_SECRET_KEY } = require("../config/constant");
const Stripe = require("stripe");
const stripe = new Stripe(STRIPE_SECRET_KEY);
const { sendEmailMessage } = require("../helper/email.helper");



const calculateDuration = (startDate, endDate) => {
  const diffTime = endDate.getTime() - startDate.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
};

const bookingController = {
  getAgencyCustomerBookings: async (req, res) => {
    try {
      const customerId = req.params.customerId;
      const agencyId = req.user._id;

      const customer = await Users.findById(customerId).select("name email");
      if (!customer) {
        return res.status(404).json({
          status: 0,
          message: "Customer not found",
        });
      }

      const bookings = await Booking.find({
        customerId: customerId,
        agencyId: agencyId,
        paymentStatus: "succeeded",
      })
        .populate({
          path: "billboardId",
          select: "title location price",
        })
        .sort({ createdAt: -1 });

      const formattedBookings = bookings.map((booking) => ({
        bookingId: booking._id,
        billboardTitle: booking.billboardId
          ? booking.billboardId.title
          : "Unknown Billboard",
        billboardLocation: booking.billboardId
          ? booking.billboardId.location
          : "Unknown Location",
        startDate: booking.startDate,
        endDate: booking.endDate,
        duration: booking.duration,
        amount: booking.totalAmount,
        date: booking.createdAt,
        status: booking.status,
      }));

      res.json({
        status: 1,
        message: "Customer bookings retrieved successfully",
        data: {
          customer: {
            customerId: customer._id,
            customerName: customer.name,
            customerEmail: customer.email,
          },
          bookings: formattedBookings,
          totalSpent: bookings.reduce(
            (sum, booking) => sum + booking.totalAmount,
            0
          ),
          bookingsCount: bookings.length,
        },
      });
    } catch (error) {
      console.error("Error fetching customer bookings:", error);
      res.status(500).json({
        status: 0,
        message: "Failed to retrieve customer bookings",
        error: error.message,
      });
    }
  },

  getAgencyRevenue: async (req, res) => {
    try {
      const { startDate, endDate, period, agencyId: queryAgencyId } = req.query;

      const agencyId =
        req.user.role === "admin" && queryAgencyId
          ? queryAgencyId
          : req.user._id;

      let query = {
        agencyId: agencyId,
        paymentStatus: "succeeded",
      };

      if (startDate && endDate) {
        query.createdAt = {
          $gte: new Date(startDate),
          $lte: new Date(endDate),
        };
      }

      const bookings = await Booking.find(query)
        .populate({
          path: "customerId",
          select: "name email",
        })
        .populate({
          path: "billboardId",
          select: "title location",
        })
        .sort({ createdAt: -1 });

      const totalRevenue = bookings.reduce(
        (sum, booking) => sum + booking.totalAmount,
        0
      );

      const revenueByCustomer = {};
      bookings.forEach((booking) => {
        const customerId = booking.customerId
          ? booking.customerId._id.toString()
          : "unknown";
        const customerName = booking.customerId
          ? booking.customerId.name
          : "Unknown Customer";
        const customerEmail = booking.customerId
          ? booking.customerId.email
          : "No email";

        if (!revenueByCustomer[customerId]) {
          revenueByCustomer[customerId] = {
            customerId,
            customerName,
            customerEmail,
            totalSpent: 0,
            bookingsCount: 0,
            bookings: [],
          };
        }

        revenueByCustomer[customerId].totalSpent += booking.totalAmount;
        revenueByCustomer[customerId].bookingsCount += 1;
        revenueByCustomer[customerId].bookings.push({
          bookingId: booking._id,
          amount: booking.totalAmount,
          date: booking.createdAt,
          billboardTitle: booking.billboardId
            ? booking.billboardId.title
            : "Unknown Billboard",
          billboardLocation: booking.billboardId
            ? booking.billboardId.location
            : "Unknown Location",
          startDate: booking.startDate,
          endDate: booking.endDate,
          duration: booking.duration,
        });
      });



      const customerRevenueArray = Object.values(revenueByCustomer).sort(
        (a, b) => b.totalSpent - a.totalSpent
      );

      const monthlyRevenue = {

      };
      bookings.forEach((booking) => {
        const date = new Date(booking.createdAt);
        const monthYear = `${date.getFullYear()}-${String(
          date.getMonth() + 1
        ).padStart(2, "0")}`;

        if (!monthlyRevenue[monthYear]) {
          monthlyRevenue[monthYear] = 0;
        }

        monthlyRevenue[monthYear] += booking.totalAmount;
      });

      const monthlyRevenueArray = Object.entries(monthlyRevenue)
        .map(([month, amount]) => ({
          month,
          amount,
        }))
        .sort((a, b) => a.month.localeCompare(b.month));

      const billboardRevenue = {};
      bookings.forEach((booking) => {
        const billboardId = booking.billboardId
          ? booking.billboardId._id.toString()
          : "unknown";
        const billboardTitle = booking.billboardId
          ? booking.billboardId.title
          : "Unknown Billboard";
        const billboardLocation = booking.billboardId
          ? booking.billboardId.location
          : "Unknown Location";

        if (!billboardRevenue[billboardId]) {
          billboardRevenue[billboardId] = {
            billboardId,
            billboardTitle,
            billboardLocation,
            totalRevenue: 0,
            bookingsCount: 0,
          };
        }

        billboardRevenue[billboardId].totalRevenue += booking.totalAmount;
        billboardRevenue[billboardId].bookingsCount += 1;
      });

      const billboardRevenueArray = Object.values(billboardRevenue).sort(
        (a, b) => b.totalRevenue - a.totalRevenue
      );

      res.json({
        status: 1,
        message: "Revenue data retrieved successfully",
        data: {
          totalRevenue,
          totalBookings: bookings.length,
          customerRevenue: customerRevenueArray,
          monthlyRevenue: monthlyRevenueArray,
          topBillboards: billboardRevenueArray,
          recentBookings: bookings.slice(0, 10).map((booking) => ({
            bookingId: booking._id,
            customerName: booking.customerId
              ? booking.customerId.name
              : "Unknown Customer",
            billboardTitle: booking.billboardId
              ? booking.billboardId.title
              : "Unknown Billboard",
            amount: booking.totalAmount,
            date: booking.createdAt,
            duration: booking.duration,
          })),
        },
      });
    } catch (error) {
      console.error("Error fetching agency revenue:", error);
      res.status(500).json({
        status: 0,
        message: "Failed to retrieve revenue data",
        error: error.message,
      });
    }
  },
  createBooking: async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const { billboardId, startDate, endDate, totalAmount, duration } =
        req.body;
      const customerId = req.user._id;

      if (!billboardId || !startDate || !endDate) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "Missing required fields: billboardId, startDate, endDate",
        });
      }

      const billboard = await Billboard.findById(billboardId).session(session);
      if (!billboard) {
        await session.abortTransaction();
        session.endSession();
        return res.status(404).json({
          status: 0,
          message: "Billboard not found",
        });
      }

      const startDateObj = new Date(startDate);
      const endDateObj = new Date(endDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      if (isNaN(startDateObj.getTime()) || isNaN(endDateObj.getTime())) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "Invalid date format",
        });
      }

      if (startDateObj < today) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "Start date cannot be in the past",
        });
      }

      if (endDateObj < startDateObj) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "End date cannot be before start date",
        });
      }

      // Check for overlapping bookings
      const overlappingBooking = await Booking.findOne({
        billboardId,
        status: { $in: ["pending", "approved"] },
        $or: [
          {
            startDate: { $lte: endDateObj },
            endDate: { $gte: startDateObj },
          },
        ],
      }).session(session);

      if (overlappingBooking) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "Selected dates overlap with an existing booking",
        });
      }

      // Check for file uploads
      if (!req.files || req.files.length === 0) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "At least one advertisement file is required.",
        });
      }

      const adImageUrls = req.files.map(
        (file) => `/public/ads/${file.filename}`
      );
      console.log("Ad media files:", req.files);

      // Create Booking Record
      const newBooking = new Booking({
        billboardId,
        customerId,
        agencyId: billboard.agencyId,
        startDate: startDateObj,
        endDate: endDateObj,
        duration: parseInt(duration),
        totalAmount: parseFloat(totalAmount),
        adImageUrls,
        status: "pending",
        paymentStatus: "pending",
      });

      const savedBooking = await newBooking.save({ session });

      // Create Stripe Payment Intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(parseFloat(totalAmount) * 100),
        currency: "pkr",
        metadata: {
          bookingId: savedBooking._id.toString(),
          billboardId: billboardId,
        },
      });

      await session.commitTransaction();
      session.endSession();

      res.status(201).json({
        status: 1,
        message: "Booking initiated successfully. Please complete payment.",
        data: {
          booking: savedBooking,
          client_secret: paymentIntent.client_secret,
        },
      });
    } catch (error) {
      await session.abortTransaction();
      session.endSession();
      console.error("Error creating booking:", error);
      res.status(500).json({
        status: 0,
        message: "Failed to create booking",
        error: error.message,
      });
    }
  },

  getCustomerBookings: async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 10;
      const { status } = req.query; // Allow filtering by status
      const userRole = req.user.role;
      const userId = req.user._id;

      console.log(`Fetching bookings for user ${userId} with role ${userRole}`);

      // First, check for and update any expired bookings (only for customer role)
      if (userRole === "customer") {
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Set to midnight for accurate comparison

        // Find active bookings that have expired
        const expiredBookings = await Booking.find({
          customerId: userId,
          endDate: { $lt: today },
          status: { $in: ["live", "content_approved"] }, // Only check active bookings
        });

        // Update expired bookings to 'completed' status
        if (expiredBookings.length > 0) {
          console.log(
            `Found ${expiredBookings.length} expired bookings for customer ${userId}`
          );

          // Update all expired bookings to completed status
          await Booking.updateMany(
            {
              _id: { $in: expiredBookings.map((booking) => booking._id) },
            },
            {
              $set: { status: "completed" },
            }
          );
        }
      }

      // Build query based on user role
      let query = {};

      if (userRole === "customer") {
        // For customers, show only their own bookings
        query.customerId = userId;
      } else if (userRole === "agency") {
        // For agencies, show bookings for their billboards
        query.agencyId = userId;
      } else if (userRole === "admin") {
        // For admins, no additional filters - they can see all bookings
        // But we'll still respect any status filters
      }

      // Handle multiple status values separated by commas
      if (status && status !== "all") {
        if (status.includes(",")) {
          // If multiple statuses are provided, use $in operator
          const statusArray = status.split(",").map((s) => s.trim());
          query.status = { $in: statusArray };
        } else {
          // Single status
          query.status = status;
        }
      }

      console.log("Booking query:", JSON.stringify(query));

      const options = {
        page,
        limit,
        sort: { createdAt: -1 }, // Show most recent first
        populate: [
          {
            path: "billboardId",
            select: "title location price imageUrl",
          },
          {
            path: "customerId",
            select: "name email",
          },
          {
            path: "agencyId",
            select: "name email",
          },
        ],
        select: "-__v", // Exclude version field
      };

      const result = await Booking.paginate(query, options);

      res.json({
        status: 1,
        message: "Bookings retrieved successfully",
        data: result.docs,
        total: result.totalDocs,
        totalPages: result.totalPages,
        page: result.page,
        userRole: userRole, // Include user role in response for client-side handling
      });
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({
        status: 0,
        message: "Failed to retrieve bookings",
        error: error.message,
      });
    }
  },

  getAgencyBookings: async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 10;
      const agencyId = req.user._id;
      const { status, billboardId } = req.query; // Allow filtering

      const query = { agencyId: agencyId };

      // Handle multiple status values separated by commas
      if (status && status !== "all") {
        if (status.includes(",")) {
          // If multiple statuses are provided, use $in operator
          const statusArray = status.split(",").map((s) => s.trim());
          query.status = { $in: statusArray };
        } else {
          // Single status
          query.status = status;
        }
      }

      if (billboardId) query.billboardId = billboardId;

      // Log the query for debugging
      console.log("Agency bookings query with status:", query);

      const options = {
        page,
        limit,
        sort: { createdAt: -1 }, // Or sort by start date? sort: { startDate: 1}
        populate: [
          // Populate multiple fields
          { path: "billboardId", select: "title location imageUrl" },
          { path: "customerId", select: "name email" }, // Include customer info
        ],
        // Don't exclude any fields that might be needed
        select: "-__v",
      };

      const result = await Booking.paginate(query, options);

      res.json({
        status: 1,
        message: "Bookings for your billboards retrieved successfully",
        data: result.docs,
        total: result.totalDocs,
        totalPages: result.totalPages,
        page: result.page,
      });
    } catch (error) {
      console.error("Error fetching agency bookings:", error);
      res.status(500).json({
        status: 0,
        message: "Failed to retrieve bookings",
        error: error.message,
      });
    }
  },

  updateBookingStatusByAgency: async (req, res) => {
    const { bookingId } = req.params;
    const { action, rejectionReason, feedbackMessage } = req.body;
    const agencyId = req.user._id;

    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // Validate action
      const validActions = [
        "approve",
        "reject",
        "verify_payment",
        "reject_payment",
        "reject_payment_resubmit",
        "approve_content",
        "reject_content",
        "reject_content_resubmit",
        "set_live",
      ];
      if (!action || !validActions.includes(action)) {
        throw new Error(
          `Invalid action. Must be one of: ${validActions.join(", ")}.`
        );
      }

      // Validate rejection reason when rejecting
      if (
        (action === "reject" ||
          action === "reject_content" ||
          action === "reject_payment" ||
          action === "reject_content_resubmit" ||
          action === "reject_payment_resubmit") &&
        !rejectionReason
      ) {
        throw new Error(
          "Rejection reason is required when rejecting a booking, payment, or content."
        );
      }

      // Find the booking
      const booking = await Booking.findOne({
        _id: bookingId,
        agencyId: agencyId,
      }).session(session);

      if (!booking) {
        throw new Error("Booking not found");
      }

      // Validate status transitions based on action
      if (action === "approve" && !["pending"].includes(booking.status)) {
        throw new Error("Can only approve bookings with 'pending' status");
      }

      if (action === "reject" && !["pending"].includes(booking.status)) {
        throw new Error("Can only reject bookings with 'pending' status");
      }

      if (action === "verify_payment" && !["paid"].includes(booking.status)) {
        throw new Error(
          "Can only verify payments for bookings with 'paid' status"
        );
      }

      if (
        (action === "reject_payment" || action === "reject_payment_resubmit") &&
        !["paid"].includes(booking.status)
      ) {
        throw new Error(
          "Can only reject payments for bookings with 'paid' status"
        );
      }

      if (
        action === "approve_content" &&
        !["pending", "payment_verified", "content_pending"].includes(
          booking.status
        )
      ) {
        throw new Error(
          "Can only approve content for bookings with 'pending', 'payment_verified' or 'content_pending' status"
        );
      }

      if (
        (action === "reject_content" || action === "reject_content_resubmit") &&
        !["pending", "payment_verified", "content_pending"].includes(
          booking.status
        )
      ) {
        throw new Error(
          "Can only reject content for bookings with 'pending', 'payment_verified' or 'content_pending' status"
        );
      }

      // Log the current booking status for debugging
      console.log(
        `Booking ${booking._id} current status: ${booking.status}, action: ${action}`
      );

      if (
        action === "set_live" &&
        !["content_approved", "payment_verified"].includes(booking.status)
      ) {
        throw new Error(
          "Can only set live bookings with 'content_approved' or 'payment_verified' status"
        );
      }

      // Update booking status based on action
      switch (action) {
        case "approve":
          booking.status = "approved";
          booking.rejectionReason = undefined;
          booking.feedbackMessage = feedbackMessage || undefined;

          // Update billboard status
          await Billboard.findByIdAndUpdate(
            booking.billboardId,
            { status: "inactive" },
            { session: session }
          );
          break;

        case "reject":
          booking.status = "rejected";
          booking.rejectionReason = rejectionReason;
          booking.feedbackMessage = feedbackMessage || undefined;
          break;

        case "verify_payment":
          booking.status = "payment_verified";
          booking.rejectionReason = undefined;
          booking.feedbackMessage = feedbackMessage || undefined;

          // Get customer details for notification
          const paymentCustomer = await Users.findById(
            booking.customerId
          ).select("email name");
          if (paymentCustomer && paymentCustomer.email) {
            // Send email notification to customer
            const emailMessage = {
              messageSubject: "Payment Verified for Your Billboard Booking",
              messageBody: `Dear ${
                paymentCustomer.name
              },\n\nYour payment for the billboard "${
                booking.billboardId.title
              }" has been verified.\n\nBooking Details:\n- Start Date: ${new Date(
                booking.startDate
              ).toLocaleDateString()}\n- End Date: ${new Date(
                booking.endDate
              ).toLocaleDateString()}\n- Amount: ${
                booking.totalAmount
              } PKR\n\n${
                feedbackMessage
                  ? `Message from agency: ${feedbackMessage}\n\n`
                  : ""
              }The next step is content verification. Please ensure your advertisement content meets our guidelines.\n\nThank you for choosing our billboard services.\n\nBest regards,\nQAd Billboard Agency`,
            };

            try {
              await sendEmailMessage(paymentCustomer.email, emailMessage);
              console.log(
                `Payment verification email sent to ${paymentCustomer.email}`
              );
            } catch (emailError) {
              console.error(
                "Error sending payment verification email:",
                emailError
              );
            }
          }
          break;

        case "reject_payment":
          booking.status = "payment_rejected";
          booking.rejectionReason = rejectionReason;
          booking.feedbackMessage = feedbackMessage || undefined;

          // Get customer details for notification
          const paymentRejectionCustomer = await Users.findById(
            booking.customerId
          ).select("email name");
          if (paymentRejectionCustomer && paymentRejectionCustomer.email) {
            // Send email notification to customer
            const emailMessage = {
              messageSubject: "Payment Rejected for Your Billboard Booking",
              messageBody: `Dear ${
                paymentRejectionCustomer.name
              },\n\nUnfortunately, your payment for the billboard "${
                booking.billboardId.title
              }" has been rejected.\n\nReason: ${rejectionReason}\n\n${
                feedbackMessage
                  ? `Additional feedback: ${feedbackMessage}\n\n`
                  : ""
              }Your booking has been rejected and no further action can be taken.\n\nThank you for choosing our billboard services.\n\nBest regards,\nQAd Billboard Agency`,
            };

            try {
              await sendEmailMessage(
                paymentRejectionCustomer.email,
                emailMessage
              );
              console.log(
                `Payment rejection email sent to ${paymentRejectionCustomer.email}`
              );
            } catch (emailError) {
              console.error(
                "Error sending payment rejection email:",
                emailError
              );
            }
          }
          break;

        case "reject_payment_resubmit":
          booking.status = "payment_rejected_resubmit";
          booking.rejectionReason = rejectionReason;
          booking.feedbackMessage = feedbackMessage || undefined;

          // Get customer details for notification
          const paymentResubmitCustomer = await Users.findById(
            booking.customerId
          ).select("email name");
          if (paymentResubmitCustomer && paymentResubmitCustomer.email) {
            // Send email notification to customer
            const emailMessage = {
              messageSubject:
                "Payment Rejected for Your Billboard Booking - Resubmission Available",
              messageBody: `Dear ${
                paymentResubmitCustomer.name
              },\n\nYour payment for the billboard "${
                booking.billboardId.title
              }" has been rejected, but you can resubmit.\n\nReason: ${rejectionReason}\n\n${
                feedbackMessage
                  ? `Additional feedback: ${feedbackMessage}\n\n`
                  : ""
              }Please resubmit your payment with the correct information by visiting your booking dashboard.\n\nThank you for choosing our billboard services.\n\nBest regards,\nQAd Billboard Agency`,
            };

            try {
              await sendEmailMessage(
                paymentResubmitCustomer.email,
                emailMessage
              );
              console.log(
                `Payment rejection with resubmission email sent to ${paymentResubmitCustomer.email}`
              );
            } catch (emailError) {
              console.error(
                "Error sending payment rejection with resubmission email:",
                emailError
              );
            }
          }
          break;

        case "approve_content":
          booking.status = "content_approved";
          booking.rejectionReason = undefined;
          booking.feedbackMessage = feedbackMessage || undefined;

          // Get customer details for notification
          const contentCustomer = await Users.findById(
            booking.customerId
          ).select("email name");
          if (contentCustomer && contentCustomer.email) {
            // Send email notification to customer
            const emailMessage = {
              messageSubject: "Content Approved for Your Billboard Booking",
              messageBody: `Dear ${
                contentCustomer.name
              },\n\nYour advertisement content for the billboard "${
                booking.billboardId.title
              }" has been approved.\n\nBooking Details:\n- Start Date: ${new Date(
                booking.startDate
              ).toLocaleDateString()}\n- End Date: ${new Date(
                booking.endDate
              ).toLocaleDateString()}\n\n${
                feedbackMessage
                  ? `Message from agency: ${feedbackMessage}\n\n`
                  : ""
              }Please proceed with payment to complete your booking.\n\nThank you for choosing our billboard services.\n\nBest regards,\nQAd Billboard Agency`,
            };

            try {
              await sendEmailMessage(contentCustomer.email, emailMessage);
              console.log(
                `Content approval email sent to ${contentCustomer.email}`
              );
            } catch (emailError) {
              console.error(
                "Error sending content approval email:",
                emailError
              );
            }
          }
          break;

        case "reject_content":
          booking.status = "content_rejected";
          booking.rejectionReason = rejectionReason;
          booking.feedbackMessage = feedbackMessage || undefined;

          // Get customer details for notification
          const contentRejectionCustomer = await Users.findById(
            booking.customerId
          ).select("email name");
          if (contentRejectionCustomer && contentRejectionCustomer.email) {
            // Send email notification to customer
            const emailMessage = {
              messageSubject: "Content Rejected for Your Billboard Booking",
              messageBody: `Dear ${
                contentRejectionCustomer.name
              },\n\nUnfortunately, your advertisement content for the billboard "${
                booking.billboardId.title
              }" has been rejected.\n\nReason: ${rejectionReason}\n\n${
                feedbackMessage
                  ? `Additional feedback: ${feedbackMessage}\n\n`
                  : ""
              }Your content has been rejected and no further action can be taken.\n\nThank you for choosing our billboard services.\n\nBest regards,\nQAd Billboard Agency`,
            };

            try {
              await sendEmailMessage(
                contentRejectionCustomer.email,
                emailMessage
              );
              console.log(
                `Content rejection email sent to ${contentRejectionCustomer.email}`
              );
            } catch (emailError) {
              console.error(
                "Error sending content rejection email:",
                emailError
              );
            }
          }
          break;

        case "reject_content_resubmit":
          booking.status = "content_rejected_resubmit";
          booking.rejectionReason = rejectionReason;
          booking.feedbackMessage = feedbackMessage || undefined;

          // Get customer details for notification
          const contentResubmitCustomer = await Users.findById(
            booking.customerId
          ).select("email name");
          if (contentResubmitCustomer && contentResubmitCustomer.email) {
            // Send email notification to customer
            const emailMessage = {
              messageSubject:
                "Content Rejected for Your Billboard Booking - Resubmission Available",
              messageBody: `Dear ${
                contentResubmitCustomer.name
              },\n\nYour advertisement content for the billboard "${
                booking.billboardId.title
              }" has been rejected, but you can resubmit.\n\nReason: ${rejectionReason}\n\n${
                feedbackMessage
                  ? `Additional feedback: ${feedbackMessage}\n\n`
                  : ""
              }Please resubmit your content addressing the issues mentioned above by visiting your booking dashboard.\n\nThank you for choosing our billboard services.\n\nBest regards,\nQAd Billboard Agency`,
            };

            try {
              await sendEmailMessage(
                contentResubmitCustomer.email,
                emailMessage
              );
              console.log(
                `Content rejection with resubmission email sent to ${contentResubmitCustomer.email}`
              );
            } catch (emailError) {
              console.error(
                "Error sending content rejection with resubmission email:",
                emailError
              );
            }
          }
          break;

        case "set_live":
          booking.status = "live";
          booking.rejectionReason = undefined;
          booking.feedbackMessage = feedbackMessage || undefined;

          // Get customer details for notification
          const customer = await Users.findById(booking.customerId).select(
            "email name"
          );
          if (customer && customer.email) {
            // Send email notification to customer
            const emailMessage = {
              messageSubject: "Your Billboard Ad is Now Live!",
              messageBody: `Dear ${
                customer.name
              },\n\nGreat news! Your advertisement for "${
                booking.billboardId.title
              }" is now live.\n\nBooking Details:\n- Start Date: ${new Date(
                booking.startDate
              ).toLocaleDateString()}\n- End Date: ${new Date(
                booking.endDate
              ).toLocaleDateString()}\n- Duration: ${
                booking.duration
              } days\n\n${
                feedbackMessage
                  ? `Message from agency: ${feedbackMessage}\n\n`
                  : ""
              }Thank you for choosing our billboard services.\n\nBest regards,\nQAd Billboard Agency`,
            };

            try {
              await sendEmailMessage(customer.email, emailMessage);
              console.log(`Activation email sent to ${customer.email}`);
            } catch (emailError) {
              console.error("Error sending activation email:", emailError);
              // Don't throw error here, just log it - we don't want to prevent the status update
            }
          }
          break;
      }

      // Save the booking
      await booking.save({ session });

      // Commit transaction
      await session.commitTransaction();
      session.endSession();

      // Prepare response message based on action
      let message = "";
      switch (action) {
        case "approve":
          message = "Booking approved successfully";
          break;
        case "reject":
          message = "Booking rejected successfully";
          break;
        case "verify_payment":
          message = "Payment verified successfully";
          break;
        case "reject_payment":
          message = "Payment rejected successfully";
          break;
        case "reject_payment_resubmit":
          message = "Payment rejected with resubmission option successfully";
          break;
        case "approve_content":
          message = "Content approved successfully";
          break;
        case "reject_content":
          message = "Content rejected successfully";
          break;
        case "reject_content_resubmit":
          message = "Content rejected with resubmission option successfully";
          break;
        case "set_live":
          message = "Billboard set to live successfully";
          break;
      }

      res.json({
        status: 1,
        message,
        data: booking,
      });
    } catch (error) {
      // Abort transaction on error
      await session.abortTransaction();
      session.endSession();

      console.error(`Error processing booking action:`, error);
      res.status(400).json({
        status: 0,
        message: error.message || "Failed to update booking status",
      });
    }
  },

  // --- [Optional but Recommended] Stripe Webhook Handler ---
  // Create a separate route (e.g., /api/stripe/webhook) that's NOT protected by your auth
  handleStripeWebhook: async (req, res) => {
    const sig = req.headers["stripe-signature"];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET; // Get from environment variables
    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err) {
      console.log(`Webhook signature verification failed.`, err.message);
      return res.sendStatus(400);
    }

    // Handle the event
    switch (event.type) {
      case "payment_intent.succeeded":
        const paymentIntent = event.data.object;
        console.log(`PaymentIntent ${paymentIntent.id} was successful!`);
        // Find the booking associated with this paymentIntent.id
        const booking = await Booking.findOne({
          paymentIntentId: paymentIntent.id,
        });
        if (booking) {
          // Check if already updated (idempotency)
          if (booking.paymentStatus !== "succeeded") {
            booking.paymentStatus = "succeeded";
            // If the booking was pending approval, DON'T auto-approve here.
            // If agency approval is required *after* payment, keep status 'approved' or move to 'paid'
            // If payment confirms the booking without separate approval, change status:
            // booking.status = 'paid'; // Or 'approved' if payment means approval

            // Let's assume payment follows agency approval, so we update paymentStatus only.
            // If the booking was already 'approved', change to 'paid'.
            if (booking.status === "approved") {
              booking.status = "paid";
            }
            await booking.save();
            console.log(
              `Booking ${booking._id} updated to payment status: succeeded, booking status: ${booking.status}`
            );
            // TODO: Send confirmation email/notification to customer and agency
          } else {
            console.log(`Booking ${booking._id} already marked as succeeded.`);
          }
        } else {
          console.error(
            `Webhook Error: Booking not found for PaymentIntent ${paymentIntent.id}`
          );
          // Maybe log this for investigation
        }
        break;
      case "payment_intent.payment_failed":
        const failedPaymentIntent = event.data.object;
        console.log(`PaymentIntent ${failedPaymentIntent.id} failed.`);
        const failedBooking = await Booking.findOne({
          paymentIntentId: failedPaymentIntent.id,
        });
        if (failedBooking && failedBooking.paymentStatus !== "failed") {
          failedBooking.paymentStatus = "failed";
          // Optionally change booking status back to 'pending' or to 'payment_failed'
          // failedBooking.status = 'pending';
          await failedBooking.save();
          console.log(`Booking ${failedBooking._id} marked as payment failed.`);
          // TODO: Notify customer about payment failure
        }
        break;
      // ... handle other event types (e.g., payment_intent.processing)
      default:
        console.log(`Unhandled event type ${event.type}`);
    }

    // Return a 200 response to acknowledge receipt of the event
    res.json({ received: true });
  },

  // Process test payment (for test credit cards) with payment proof upload
  processTestPayment: async (req, res) => {
    const { bookingId } = req.params;
    const userId = req.user._id;
    const { customerName, phoneNumber, paymentMethod } = req.body;

    try {
      // Find the booking
      const booking = await Booking.findById(bookingId);

      if (!booking) {
        return res.status(404).json({
          status: 0,
          message: "Booking not found",
        });
      }

      // Verify the booking belongs to the current user
      if (booking.customerId.toString() !== userId.toString()) {
        return res.status(403).json({
          status: 0,
          message: "You are not authorized to process this payment",
        });
      }

      // Check if booking is already paid
      if (booking.paymentStatus === "succeeded") {
        return res.status(400).json({
          status: 0,
          message: "This booking has already been paid for",
        });
      }

      // Handle payment proof upload
      let paymentProofUrl = null;
      if (req.file) {
        paymentProofUrl = `/public/payments/${req.file.filename}`;
        console.log("Payment proof uploaded:", req.file.filename);
      } else {
        console.log("No payment proof file found in request");
      }

      // Update booking status and payment information
      booking.paymentStatus = "succeeded";
      booking.status = "paid"; // Set to paid so it can be verified by agency
      booking.paymentIntentId = `test_payment_${Date.now()}`; // Generate a fake payment intent ID
      booking.paymentMethod = paymentMethod;
      booking.paymentProofUrl = paymentProofUrl;
      booking.customerPhone = phoneNumber;

      // Store additional payment details if needed
      booking.paymentDetails = {
        customerName,
        phoneNumber,
        paymentMethod,
        uploadedAt: new Date(),
      };

      await booking.save();

      // Return success response
      return res.status(200).json({
        status: 1,
        message: "Payment information submitted successfully",
        data: {
          booking,
        },
      });
    } catch (error) {
      console.error("Error processing payment:", error);
      return res.status(500).json({
        status: 0,
        message: error.message || "Failed to process payment",
      });
    }
  },

  // Confirm payment (for real payments)
  confirmPayment: async (req, res) => {
    const { bookingId } = req.params;
    const { paymentIntentId } = req.body;
    const userId = req.user._id;

    if (!paymentIntentId) {
      return res.status(400).json({
        status: 0,
        message: "Payment intent ID is required",
      });
    }

    try {
      // Find the booking
      const booking = await Booking.findById(bookingId);

      if (!booking) {
        return res.status(404).json({
          status: 0,
          message: "Booking not found",
        });
      }

      // Verify the booking belongs to the current user
      if (booking.customerId.toString() !== userId.toString()) {
        return res.status(403).json({
          status: 0,
          message: "You are not authorized to confirm this payment",
        });
      }

      // Check if booking is already paid
      if (booking.paymentStatus === "succeeded") {
        return res.status(400).json({
          status: 0,
          message: "This booking has already been paid for",
        });
      }

      // Update booking status
      booking.paymentStatus = "succeeded";
      booking.status = "paid"; // Set to paid so it can be verified by agency
      booking.paymentIntentId = paymentIntentId;

      await booking.save();

      // Return success response
      return res.status(200).json({
        status: 1,
        message: "Payment confirmed successfully",
        data: {
          booking,
        },
      });
    } catch (error) {
      console.error("Error confirming payment:", error);
      return res.status(500).json({
        status: 0,
        message: error.message || "Failed to confirm payment",
      });
    }
  },

  // Admin revenue overview - gets data from all agencies
  getAdminRevenue: async (req, res) => {
    try {
      const { startDate, endDate } = req.query;

      // Ensure user is admin
      if (req.user.role !== "admin") {
        return res.status(403).json({
          status: 0,
          message: "Only admin users can access this endpoint",
        });
      }

      // Base query for all bookings with payment status succeeded
      let query = {
        paymentStatus: "succeeded",
      };

      // Add date filtering if provided
      if (startDate && endDate) {
        query.createdAt = {
          $gte: new Date(startDate),
          $lte: new Date(endDate),
        };
      }

      // Get all paid bookings
      const bookings = await Booking.find(query)
        .populate({
          path: "customerId",
          select: "name email",
        })
        .populate({
          path: "billboardId",
          select: "title location",
        })
        .populate({
          path: "agencyId",
          select: "name email",
        })
        .sort({ createdAt: -1 });

      // Calculate total revenue
      const totalRevenue = bookings.reduce(
        (sum, booking) => sum + booking.totalAmount,
        0
      );

      // Get unique agencies
      const agencies = await Users.find({ role: "agency" });

      // Get agency revenues
      const agencyRevenues = await Promise.all(
        agencies.map(async (agency) => {
          const agencyBookings = bookings.filter(
            (booking) =>
              booking.agencyId?._id.toString() === agency._id.toString()
          );

          const totalRevenue = agencyBookings.reduce(
            (sum, booking) => sum + booking.totalAmount,
            0
          );

          // Get unique customer IDs for this agency
          const customerIds = [
            ...new Set(
              agencyBookings
                .map((booking) => booking.customerId?._id.toString())
                .filter(Boolean)
            ),
          ];

          // Get unique billboard IDs for this agency
          const billboardIds = [
            ...new Set(
              agencyBookings
                .map((booking) => booking.billboardId?._id.toString())
                .filter(Boolean)
            ),
          ];

          // Calculate monthly revenue
          const monthlyRevenue = [];
          if (agencyBookings.length > 0) {
            // Group bookings by month
            const bookingsByMonth = agencyBookings.reduce((acc, booking) => {
              const date = new Date(booking.createdAt);
              const monthKey = `${date.getFullYear()}-${String(
                date.getMonth() + 1
              ).padStart(2, "0")}`;

              if (!acc[monthKey]) {
                acc[monthKey] = [];
              }

              acc[monthKey].push(booking);
              return acc;
            }, {});

            // Calculate revenue for each month
            Object.keys(bookingsByMonth).forEach((month) => {
              const amount = bookingsByMonth[month].reduce(
                (sum, booking) => sum + booking.totalAmount,
                0
              );

              monthlyRevenue.push({ month, amount });
            });
          }

          return {
            agencyId: agency._id,
            agencyName: agency.name,
            agencyEmail: agency.email,
            totalRevenue,
            bookingsCount: agencyBookings.length,
            customersCount: customerIds.length,
            billboardsCount: billboardIds.length,
            monthlyRevenue,
          };
        })
      );

      // Sort agencies by revenue (descending)
      const topAgencies = [...agencyRevenues].sort(
        (a, b) => b.totalRevenue - a.totalRevenue
      );

      // Calculate monthly revenue for the entire platform
      const monthlyRevenue = [];
      if (bookings.length > 0) {
        // Group bookings by month
        const bookingsByMonth = bookings.reduce((acc, booking) => {
          const date = new Date(booking.createdAt);
          const monthKey = `${date.getFullYear()}-${String(
            date.getMonth() + 1
          ).padStart(2, "0")}`;

          if (!acc[monthKey]) {
            acc[monthKey] = [];
          }

          acc[monthKey].push(booking);
          return acc;
        }, {});

        // Calculate revenue for each month
        Object.keys(bookingsByMonth).forEach((month) => {
          const amount = bookingsByMonth[month].reduce(
            (sum, booking) => sum + booking.totalAmount,
            0
          );

          monthlyRevenue.push({ month, amount });
        });

        // Sort monthly revenue by date
        monthlyRevenue.sort((a, b) => {
          const dateA = new Date(a.month + "-01");
          const dateB = new Date(b.month + "-01");
          return dateA - dateB;
        });
      }

      // Return the data
      return res.status(200).json({
        status: 1,
        message: "Admin revenue data retrieved successfully",
        data: {
          totalRevenue,
          totalBookings: bookings.length,
          totalAgencies: agencies.length,
          totalCustomers: [
            ...new Set(
              bookings.map((b) => b.customerId?._id.toString()).filter(Boolean)
            ),
          ].length,
          totalBillboards: [
            ...new Set(
              bookings.map((b) => b.billboardId?._id.toString()).filter(Boolean)
            ),
          ].length,
          monthlyRevenue,
          agencyRevenues,
          topAgencies,
        },
      });
    } catch (error) {
      console.error("Error getting admin revenue:", error);
      return res.status(500).json({
        status: 0,
        message: error.message || "Failed to get admin revenue data",
      });
    }
  },

  // Upload content for a payment verified booking
  uploadContent: async (req, res) => {
    const { bookingId } = req.params;
    const customerId = req.user._id;

    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // Check if files were uploaded
      console.log("Files in request:", req.files);

      if (!req.files || req.files.length === 0) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "At least one advertisement file is required.",
        });
      }

      // Find the booking
      const booking = await Booking.findOne({
        _id: bookingId,
        customerId: customerId,
      }).session(session);

      if (!booking) {
        await session.abortTransaction();
        session.endSession();
        return res.status(404).json({
          status: 0,
          message: "Booking not found",
        });
      }

      // Validate booking status - allow both pending and payment_verified
      if (
        booking.status !== "payment_verified" &&
        booking.status !== "pending"
      ) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message:
            "Content can only be uploaded for bookings with 'pending' or 'payment_verified' status",
        });
      }

      // Process the uploaded files
      const adImageUrls = req.files.map(
        (file) => `/public/ads/${file.filename}`
      );
      console.log("Uploaded content files:", req.files);

      console.log("Generated image URLs:", adImageUrls);

      // Update the booking
      booking.adImageUrls = adImageUrls;
      booking.status = "content_pending";

      await booking.save({ session });

      // Commit transaction
      await session.commitTransaction();
      session.endSession();

      res.status(200).json({
        status: 1,
        message: "Content uploaded successfully",
        data: booking,
        adImageUrls: adImageUrls,
      });
    } catch (error) {
      // Abort transaction on error
      await session.abortTransaction();
      session.endSession();

      console.error(`Error uploading content:`, error);
      res.status(500).json({
        status: 0,
        message: error.message || "Failed to upload content",
      });
    }
  },

  // Resubmit content for a rejected booking
  resubmitContent: async (req, res) => {
    const { bookingId } = req.params;
    const customerId = req.user._id;

    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // Check if files were uploaded
      console.log("Files in request:", req.files);

      if (!req.files || req.files.length === 0) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "At least one advertisement file is required.",
        });
      }

      // Find the booking
      const booking = await Booking.findOne({
        _id: bookingId,
        customerId: customerId,
      }).session(session);

      if (!booking) {
        await session.abortTransaction();
        session.endSession();
        return res.status(404).json({
          status: 0,
          message: "Booking not found",
        });
      }

      // Validate booking status
      if (
        booking.status !== "content_rejected" &&
        booking.status !== "content_rejected_resubmit"
      ) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message:
            "Only rejected content with resubmission option can be resubmitted",
        });
      }

      // Process the uploaded files
      const adImageUrls = req.files.map(
        (file) => `/public/ads/${file.filename}`
      );
      console.log("Resubmitted content files:", req.files);

      console.log("Generated image URLs:", adImageUrls);

      // Update the booking
      booking.adImageUrls = adImageUrls;
      booking.status = "content_pending";
      booking.rejectionReason = undefined;
      // Keep the feedback message for reference

      await booking.save({ session });

      // Commit transaction
      await session.commitTransaction();
      session.endSession();

      res.status(200).json({
        status: 1,
        message: "Content resubmitted successfully",
        data: booking,
        adImageUrls: adImageUrls,
      });
    } catch (error) {
      // Abort transaction on error
      await session.abortTransaction();
      session.endSession();

      console.error(`Error resubmitting content:`, error);
      res.status(500).json({
        status: 0,
        message: error.message || "Failed to resubmit content",
      });
    }
  },

  // Resubmit payment for a rejected booking
  resubmitPayment: async (req, res) => {
    const { bookingId } = req.params;
    const userId = req.user._id;
    const { customerName, phoneNumber, paymentMethod } = req.body;

    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // Check if payment proof was uploaded
      if (!req.file) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message: "Payment proof is required.",
        });
      }

      // Find the booking
      const booking = await Booking.findOne({
        _id: bookingId,
        customerId: userId,
      }).session(session);

      if (!booking) {
        await session.abortTransaction();
        session.endSession();
        return res.status(404).json({
          status: 0,
          message: "Booking not found",
        });
      }

      // Validate booking status
      if (
        booking.status !== "payment_rejected" &&
        booking.status !== "payment_rejected_resubmit"
      ) {
        await session.abortTransaction();
        session.endSession();
        return res.status(400).json({
          status: 0,
          message:
            "Only rejected payments with resubmission option can be resubmitted",
        });
      }

      // Process the uploaded payment proof
      const paymentProofUrl = `/public/payments/${req.file.filename}`;
      console.log("Resubmitted payment proof:", req.file);

      // Update the booking
      booking.paymentProofUrl = paymentProofUrl;
      booking.status = "paid";
      booking.paymentStatus = "succeeded";
      booking.rejectionReason = undefined;
      booking.paymentMethod = paymentMethod;
      booking.customerPhone = phoneNumber;

      // Store additional payment details if needed
      booking.paymentDetails = {
        customerName,
        phoneNumber,
        paymentMethod,
        uploadedAt: new Date(),
      };

      await booking.save({ session });

      // Commit transaction
      await session.commitTransaction();
      session.endSession();

      res.status(200).json({
        status: 1,
        message: "Payment resubmitted successfully",
        data: booking,
      });
    } catch (error) {
      // Abort transaction on error
      await session.abortTransaction();
      session.endSession();

      console.error(`Error resubmitting payment:`, error);
      res.status(500).json({
        status: 0,
        message: error.message || "Failed to resubmit payment",
      });
    }
  },
};

module.exports = bookingController;
