// controllers/report.controller.js
const { Reports } = require("../models/Report.model");
const { Users } = require("../models/User.model");

const reportController = {
  submitReport: async (req, res) => {
    try {
      const { title, description } = req.body;
      if (!title || !description) {
        return res
          .status(400)
          .json({ message: "Title and description are required" });
      }

      const user = await Users.findById(req.user._id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const newReport = new Reports({
        userId: user._id,
        userEmail: user.email,
        title,
        description,
      });

      await newReport.save();

      return res.status(200).json({
        status: 1,
        message: "Report submitted successfully",
        report: newReport,
      });
    } catch (error) {
      console.error("Submit Report Error:", error);
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },

  getAllReports: async (req, res) => {
    try {
      const reports = await Reports.find({ userId: req.user._id }).sort({
        createdAt: -1,
      });
      return res
        .status(200)
        .json({ status: 1, reports, message: "Reports fetched successfully" });
    } catch (error) {
      console.error("Get User Reports Error:", error);
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },

  getAllUsersReports: async (req, res) => {
    try {
      const reports = await Reports.find()
        .sort({ createdAt: -1 })
        .populate("userId", "name email");
      return res.status(200).json({
        status: 1,
        reports,
        message: "All reports fetched successfully",
      });
    } catch (error) {
      console.error("Get All Reports Error:", error);
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },

  deleteReport: async (req, res) => {
    try {
      const report = await Reports.findOne({
        _id: req.params.reportId,
        userId: req.user._id,
      });
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }

      await Reports.deleteOne({ _id: req.params.reportId });
      return res
        .status(200)
        .json({ status: 1, message: "Report deleted successfully" });
    } catch (error) {
      console.error("Delete Report Error:", error);
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },

  updateReportStatus: async (req, res) => {
    try {
      const { status } = req.body;
      const report = await Reports.findById(req.params.reportId);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }

      report.status = status;
      report.updatedAt = new Date();
      await report.save();

      return res.status(200).json({
        status: 1,
        message: "Report status updated successfully",
        report,
      });
    } catch (error) {
      console.error("Update Report Status Error:", error);
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },

  adminDeleteReport: async (req, res) => {
    try {
      const report = await Reports.findById(req.params.reportId);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }

      await Reports.deleteOne({ _id: req.params.reportId });
      return res
        .status(200)
        .json({ status: 1, message: "Report deleted successfully" });
    } catch (error) {
      console.error("Admin Delete Report Error:", error);
      return res
        .status(500)
        .json({ message: error.message || "Something went wrong!" });
    }
  },
};

module.exports = reportController;
