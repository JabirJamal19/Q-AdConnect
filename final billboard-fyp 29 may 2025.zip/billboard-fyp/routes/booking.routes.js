const express = require("express");
const router = express.Router();
const bookingController = require("../controllers/booking.controller");
const { authenticate } = require("../middleware/auth");
const { hasRole } = require("../middleware/roleCheck");
const {
  uploadAdMediaMiddleware,
  uploadPaymentProofMiddleware,
} = require("../middleware/upload");

router.use(authenticate);

router.post(
  "/create",
  hasRole("customer"),
  uploadAdMediaMiddleware,
  bookingController.createBooking
);
// Allow all authenticated users to access my-bookings
router.get("/my-bookings", bookingController.getCustomerBookings);
router.post(
  "/upload-content/:bookingId",
  hasRole("customer"),
  uploadAdMediaMiddleware,
  bookingController.uploadContent
);

router.post(
  "/resubmit-content/:bookingId",
  hasRole("customer"),
  uploadAdMediaMiddleware,
  bookingController.resubmitContent
);

router.post(
  "/resubmit-payment/:bookingId",
  hasRole("customer"),
  uploadPaymentProofMiddleware,
  bookingController.resubmitPayment
);

router.post(
  "/test-payment/:bookingId",
  hasRole("customer"),
  uploadPaymentProofMiddleware,
  bookingController.processTestPayment
);
router.post(
  "/confirm-payment/:bookingId",
  hasRole("customer"),
  bookingController.confirmPayment
);

router.get(
  "/agency-view",
  hasRole("agency"),
  bookingController.getAgencyBookings
);
router.put(
  "/agency-action/:bookingId",
  hasRole("agency"),
  bookingController.updateBookingStatusByAgency
);

router.get(
  "/customer-bookings/:customerId",
  hasRole(["agency", "admin"]),
  bookingController.getAgencyCustomerBookings
);

router.get(
  "/agency-revenue",
  hasRole(["agency", "admin"]),
  bookingController.getAgencyRevenue
);

router.get(
  "/admin-revenue",
  hasRole("admin"),
  bookingController.getAdminRevenue
);

module.exports = router;
