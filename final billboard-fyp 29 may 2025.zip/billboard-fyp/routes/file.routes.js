const { Router } = require("express");
const multer = require("multer");
const path = require("path");
const controller = require("../controllers/file.controller");

function createFileRouter() {
  const router = Router();
  const storage = multer.diskStorage({
    destination: path.join(__dirname, "../public/files"),
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now();
      const fileExtension = path.extname(file.originalname);
      const baseName = path.basename(file.originalname, fileExtension);
      const safeBaseName = decodeURIComponent(baseName);
      const newFilename = `${safeBaseName}-${uniqueSuffix}${fileExtension}`;
      cb(null, newFilename);
    },
  });

  const upload = multer({ storage: storage });

  router.post("/upload", upload.single("file"), controller.upload);

  return router;
}

module.exports = createFileRouter();
