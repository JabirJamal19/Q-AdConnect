const express = require("express");
const reportController = require("../controllers/report.controller");
const { authenticate, isAdmin } = require("../middleware/auth");

const router = express.Router();


router.post("/submit", authenticate, reportController.submitReport);
router.get("/user-reports", authenticate, reportController.getAllReports);
router.delete("/delete/:reportId", authenticate, reportController.deleteReport);


router.get("/all", authenticate, isAdmin, reportController.getAllUsersReports);
router.put(
  "/:reportId/status",
  authenticate,
  isAdmin,
  reportController.updateReportStatus
);
router.delete(
  "/admin/delete/:reportId",
  authenticate,
  isAdmin,
  reportController.adminDeleteReport
);

module.exports = router;
