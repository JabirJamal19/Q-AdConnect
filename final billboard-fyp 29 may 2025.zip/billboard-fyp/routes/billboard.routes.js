const express = require("express");
const router = express.Router();
const billboardsController = require("../controllers/billboard.controller");
const { authenticate } = require("../middleware/auth");
const { hasRole } = require("../middleware/roleCheck");

router.get("/public/list", billboardsController.publicList);

router.get("/public/detail/:id", billboardsController.publicDetail);

router.use(authenticate);

router.post("/create", hasRole("agency"), billboardsController.create);
router.get("/list", hasRole("agency"), billboardsController.list);
router.get("/detail/:id", hasRole("agency"), billboardsController.detail);
router.put("/update/:id", hasRole("agency"), billboardsController.update);
router.delete(
  "/delete/:id",
  hasRole("agency"),
  billboardsController.deleteBillboard
);

module.exports = router;
