const usersController = require("../controllers/user.controller");
const upload = require("../helper/filupload.helper");
const { authenticate } = require("../middleware/auth");
const { profileUploadMiddleware } = require("../middleware/profileUpload");
const router = require("express").Router();

router.get("/me", authenticate, usersController.getMe);
router.put(
  "/update-profile",
  authenticate,
  profileUploadMiddleware,
  usersController.updateProfile
);
router.put(
  "/update/:id",
  authenticate,
  upload.fields([
    { name: "agencyImage", maxCount: 1 },
    { name: "coverImage", maxCount: 1 },
  ]),
  usersController.update
);

router.get("/users", authenticate, usersController.getUsers);
router.delete("/delete/:id", authenticate, usersController.delete);
router.put(
  "/update-approval/:id",
  authenticate,
  usersController.updateApprovalStatus
);

router.post("/submit-report", authenticate, usersController.submitReport);
router.get("/get-reports", authenticate, usersController.getAllReports);
router.delete("/report/:reportId", authenticate, usersController.deleteReport);
router.post(
  "/cleanup-reports",
  authenticate,
  usersController.cleanupInvalidReports
);

module.exports = router;
