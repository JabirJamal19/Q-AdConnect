const express = require("express");
const router = express.Router();

const bookingRoutes = require("./booking.routes");
const billboardRoutes = require("./billboard.routes");
const authRoutes = require("./auth.routes");
const userRoutes = require("./user.routes");
const reportRoutes = require("./report.routes");
const fileRoutes = require("./file.routes");
const dashboardRoutes = require("./dashboard.routes");

router.use("/booking", bookingRoutes);
router.use("/billboard", billboardRoutes);
router.use("/auth", authRoutes);
router.use("/user", userRoutes);
router.use("/report", reportRoutes);
router.use("/file", fileRoutes);
router.use("/dashboard", dashboardRoutes);

module.exports = router;
