const authController = require("../controllers/auth.controller");
const upload = require("../helper/filupload.helper");
const { authenticate } = require("../middleware/auth");
const router = require("express").Router();
const multer = require("multer");


const handleFileUploadErrors = (req, res, next) => {
  const uploadMiddleware = upload.fields([
    { name: "agencyDoc", maxCount: 5 },
    { name: "agencyImage", maxCount: 1 },
  ]);

  uploadMiddleware(req, res, (err) => {
    if (err instanceof multer.MulterError) {
   
      console.error("Multer error during file upload:", err);
      return res.status(400).json({
        status: 0,
        message: `File upload error: ${err.message}`,
        field: err.field
      });
    } else if (err) {
     
      console.error("Unknown error during file upload:", err);
      return res.status(400).json({
        status: 0,
        message: err.message || "File upload failed"
      });
    }

    
    next();
  });
};

router.post(
  "/signup",
  handleFileUploadErrors,
  authController.signup
);

router.post("/login", authController.login);
router.post("/reset-password", authController.sendResetPasswordOtp);
router.post(
  "/verify-resetpassword-otp",
  authController.verifyOtpAndResetPassword
);
router.post("/update-password", authenticate, authController.updatePassword);

module.exports = router;
