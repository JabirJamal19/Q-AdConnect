const { authenticate } = require("../middleware/auth");
const router = require("express").Router();
const { Users } = require("../models/User.model");
const Billboards = require("../models/Billboard.model");

router.get("/", authenticate, async (req, res) => {
  try {
    const agency = await Users.count({ role: "agency" });
    const users = await Users.count({ role: "customer" });

    const billboards = await Billboards.count({});
    return res.json({
      status: 1,
      users,
      agency,
      billboards,
      message: "dashboard",
    });
  } catch (error) {
    return res.status(500).json({
      status: 0,
      message: error.message,
    });
  }
});

module.exports = router;
