const multer = require("multer");
const path = require("path");
const fs = require("fs");

const uploadDir = path.join(__dirname, "../public/files");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now();
    const fileExtension = path.extname(file.originalname);
    const baseName = path.basename(file.originalname, fileExtension);
    const safeBaseName = decodeURIComponent(baseName);
    const newFilename = `${safeBaseName}-${uniqueSuffix}${fileExtension}`;
    cb(null, newFilename);
  },
});

// File filter to validate file types
const fileFilter = (req, file, cb) => {
  // Accept images only
  if (file.fieldname === "agencyImage") {
    if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/i)) {
      return cb(new Error('Only image files are allowed for agency image!'), false);
    }
  }

  // For agency documents, accept more file types
  if (file.fieldname === "agencyDoc") {
    if (!file.originalname.match(/\.(jpg|jpeg|png|gif|pdf|doc|docx)$/i)) {
      return cb(new Error('Only image, PDF, or document files are allowed for agency documents!'), false);
    }
  }

  cb(null, true);
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, 
    files: 10
  },
  fileFilter: fileFilter
});

module.exports = upload;
