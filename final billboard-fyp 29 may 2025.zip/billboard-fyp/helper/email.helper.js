const nodemailer = require("nodemailer");
const dotenv = require("dotenv");
const dotenvConfig = dotenv.config();

module.exports.sendEmailMessage = async (email, message, fromEmail = null) => {
  const transporter = nodemailer.createTransport({
    host: dotenvConfig.parsed.SMTP_HOST,
    port: dotenvConfig.parsed.SMTP_PORT,
    auth: {
      user: dotenvConfig.parsed.SMTP_USERNAME,
      pass: dotenvConfig.parsed.SMTP_PASSWORD,
    },

  });

  const mailOptions = {
    from: fromEmail || dotenvConfig.parsed.SMTP_FROM,
    to: email,
    subject: message.messageSubject,
    text: message.messageBody,
  };
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("Error sending email:", error);
    } else {
      console.log("Email sent:", info.response);
    }
  });
};
