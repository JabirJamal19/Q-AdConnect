const Joi = require("joi");

const billboardSchema = Joi.object({
  title: Joi.string().required().messages({
    'string.empty': 'Title is required',
    'any.required': 'Title is required'
  }),
  description: Joi.string().required().messages({
    'string.empty': 'Description is required',
    'any.required': 'Description is required'
  }),
  status: Joi.string().valid("active", "inactive").default("active"),
  location: Joi.string().required().messages({
    'string.empty': 'Location is required',
    'any.required': 'Location is required'
  }),
  city: Joi.string().required().messages({
    'string.empty': 'City is required',
    'any.required': 'City is required'
  }),
  area: Joi.string().required().messages({
    'string.empty': 'Area is required',
    'any.required': 'Area is required'
  }),
  price: Joi.number().required().messages({
    'number.base': 'Price must be a valid number',
    'any.required': 'Price is required'
  }),
  contact: Joi.string().required().messages({
    'string.empty': 'Contact information is required',
    'any.required': 'Contact information is required'
  }),
  size: Joi.string().required().messages({
    'string.empty': 'Size is required',
    'any.required': 'Size is required'
  }),
  imageUrl: Joi.string().required().messages({
    'string.empty': 'Image URL is required',
    'any.required': 'Image URL is required'
  }),
  agencyId: Joi.alternatives().try(
    Joi.string(),
    Joi.object()
  ).messages({
    'alternatives.match': 'Agency ID must be a valid string or object ID'
  }),
});

exports.validateBillboard = (data) => {
  return billboardSchema.validate(data, {
    abortEarly: false, 
    allowUnknown: true, 
    stripUnknown: false 
  });
};
