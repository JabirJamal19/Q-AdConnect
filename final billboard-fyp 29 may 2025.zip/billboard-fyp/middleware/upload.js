const multer = require("multer");
const path = require("path");
const fs = require("fs");


const adsUploadDir = path.join(__dirname, "..", "public", "ads");
if (!fs.existsSync(adsUploadDir)) {
  fs.mkdirSync(adsUploadDir, { recursive: true });
}

const paymentsUploadDir = path.join(__dirname, "..", "public", "payments");
if (!fs.existsSync(paymentsUploadDir)) {
  fs.mkdirSync(paymentsUploadDir, { recursive: true });
}


const adStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, adsUploadDir);
  },
  filename: function (req, file, cb) {
    const cleanFileName = file.originalname.replace(/[^a-zA-Z0-9.]/g, "");
    cb(null, `${Date.now()}-${cleanFileName}`);
  },
});


const paymentStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, paymentsUploadDir);
  },
  filename: function (req, file, cb) {

    const bookingId = req.params.bookingId || '';
    const cleanFileName = file.originalname.replace(/[^a-zA-Z0-9.]/g, "");
    cb(null, `payment_${bookingId}_${Date.now()}-${cleanFileName}`);
  },
});


const adMediaFileFilter = (req, file, cb) => {
  const allowedTypes = ["image/jpeg", "image/png", "image/gif", "video/mp4"];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(
      new Error(
        "Invalid file type. Only JPEG, PNG, GIF and MP4 files are allowed."
      ),
      false
    );
  }
};


const paymentProofFileFilter = (req, file, cb) => {
  const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(
      new Error(
        "Invalid file type. Only JPEG, PNG, and JPG files are allowed for payment proof."
      ),
      false
    );
  }
};

const uploadAdMedia = multer({
  storage: adStorage,
  fileFilter: adMediaFileFilter,
  limits: {
    fileSize: 100 * 1024 * 1024, 
    files: 5,
  },
}).array("adMedia", 5);

const uploadPaymentProof = multer({
  storage: paymentStorage,
  fileFilter: paymentProofFileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024, 
    files: 1,
  },
}).single("transactionProof");


const uploadAdMediaMiddleware = (req, res, next) => {
  uploadAdMedia(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      return res.status(400).json({
        status: 0,
        message: `Upload error: ${err.message}`,
      });
    } else if (err) {
      return res.status(400).json({
        status: 0,
        message: err.message,
      });
    }
    next();
  });
};


const uploadPaymentProofMiddleware = (req, res, next) => {
  uploadPaymentProof(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      return res.status(400).json({
        status: 0,
        message: `Upload error: ${err.message}`,
      });
    } else if (err) {
      return res.status(400).json({
        status: 0,
        message: err.message,
      });
    }
    next();
  });
};

module.exports = {
  uploadAdMediaMiddleware,
  uploadPaymentProofMiddleware,
};
