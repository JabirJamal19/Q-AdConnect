const multer = require("multer");
const path = require("path");
const fs = require("fs");

const uploadDir = path.join(__dirname, "..", "public", "profiles");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const cleanFileName = file.originalname.replace(/[^a-zA-Z0-9.]/g, "");
    cb(null, `${Date.now()}-${cleanFileName}`);
  },
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = ["image/jpeg", "image/png", "image/gif"];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(
      new Error(
        "Invalid file type. Only JPEG, PNG, and GIF files are allowed for profile images."
      ),
      false
    );
  }
};

const uploadProfileImage = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024,
    files: 1,
  },
}).single("profileImage");

const profileUploadMiddleware = (req, res, next) => {
  console.log("Profile upload middleware called");
  uploadProfileImage(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      console.error("Multer error:", err);
      return res.status(400).json({
        status: 0,
        message: `Upload error: ${err.message}`,
      });
    } else if (err) {
      console.error("Other upload error:", err);
      return res.status(400).json({
        status: 0,
        message: err.message,
      });
    }

    if (req.file) {
      console.log("File uploaded successfully:", req.file);
    } else {
      console.log("No file uploaded with request");
    }

    next();
  });
};

module.exports = {
  profileUploadMiddleware,
};
