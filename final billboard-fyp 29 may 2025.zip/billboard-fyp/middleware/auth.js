const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");
const { Users } = require("../models/User.model");

exports.authenticate = async (req, res, next) => {
  try {
    console.log("Auth middleware called");

    // Validate Users model
    if (!Users || typeof Users.findById !== "function") {
      console.error("FATAL: 'Users' model not imported correctly in auth.js.");
      return res.status(500).json({
        status: 0,
        message: "Internal Server Error: Auth config issue.",
      });
    }

    // Check for authorization header
    const authHeader = req.headers.authorization;
    console.log(
      "Auth header:",
      authHeader ? `${authHeader.substring(0, 15)}...` : "Missing"
    );

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.error("Auth header missing or invalid format");
      return res.status(401).json({
        status: 0,
        message: "No token provided or invalid format.",
      });
    }

    // Extract token
    const token = authHeader.split(" ")[1];
    if (!token) {
      console.error("Token is empty after extraction");
      return res.status(401).json({
        status: 0,
        message: "Empty token provided.",
      });
    }

    console.log("Token extracted:", token.substring(0, 10) + "...");

    // Verify token
    let decoded;
    try {
      if (!process.env.JWT_SECRET) {
        console.error("JWT_SECRET is not defined in environment variables");
        return res.status(500).json({
          status: 0,
          message: "Server configuration error.",
        });
      }

      decoded = jwt.verify(token, process.env.JWT_SECRET);
      console.log("Token decoded successfully:", {
        id: decoded._id,
        role: decoded.role,
        email: decoded.email
          ? decoded.email.substring(0, 5) + "..."
          : "missing",
      });

      // Admin test mode bypass (for development only)
      if (decoded.role === "admin" && decoded._id === "admin-id") {
        console.log("Admin bypass activated");
        req.user = {
          _id: decoded._id,
          role: decoded.role,
          email: decoded.email,
          name: "Admin Test",
        };
        return next();
      }
    } catch (jwtError) {
      console.error("JWT verification failed:", jwtError.message);
      return res.status(401).json({
        status: 0,
        message: "Invalid token: " + jwtError.message,
      });
    }

    // Validate decoded token payload
    if (!decoded || !decoded._id) {
      console.error(
        'Auth Middleware: Token payload missing user identifier ("_id")',
        decoded
      );
      return res.status(401).json({
        status: 0,
        message: "Invalid token payload.",
      });
    }

    // Find user in database
    console.log(`Looking up user with ID: ${decoded._id}`);
    try {
      const user = await Users.findById(decoded._id).select("-password");
      if (!user) {
        console.warn(
          `Auth Middleware: User not found in database for ID: ${decoded._id}`
        );
        return res.status(401).json({
          status: 0,
          message: "Unauthorized: User not found.",
        });
      }

      // Validate user role matches token role
      if (user.role !== decoded.role) {
        console.error(
          `Role mismatch: Token role ${decoded.role}, DB role ${user.role}`
        );
        return res.status(403).json({
          status: 0,
          message: "Unauthorized: Role mismatch.",
        });
      }

      // Check if user is active
      if (user.status === "inactive") {
        console.warn(`User account is inactive: ${user._id}`);
        return res.status(403).json({
          status: 0,
          message: "Your account is inactive. Please contact support.",
        });
      }

      // For agency users, check approval status
      if (user.role === "agency" && user.approvalStatus !== "approved") {
        console.warn(
          `Agency not approved: ${user._id}, status: ${user.approvalStatus}`
        );
        const message =
          user.approvalStatus === "pending"
            ? "Your account is pending approval from admin."
            : "Your account has been rejected.";

        return res.status(403).json({
          status: 0,
          message,
        });
      }

      console.log(`User authenticated: ${user.name}, role: ${user.role}`);
      req.user = user;
      next();
    } catch (dbError) {
      console.error("Database error during user lookup:", dbError);
      return res.status(500).json({
        status: 0,
        message: "Database error during authentication.",
      });
    }
  } catch (error) {
    console.error(
      "Auth Middleware Error:",
      error.name || "Error",
      "-",
      error.message
    );
    let message = "Unauthorized.";
    let status = 401;

    if (error.name === "JsonWebTokenError") message = "Invalid token.";
    if (error.name === "TokenExpiredError") message = "Token expired.";
    if (error instanceof mongoose.Error) {
      message = "Database error during authentication.";
      status = 500;
    }

    return res.status(status).json({
      status: 0,
      message,
      ...(process.env.NODE_ENV === "development" && {
        errorDetail: error.message,
      }),
    });
  }
};

const isAdmin = async (req, res, next) => {
  try {
    if (req.user && req.user.role === "admin") {
      return next();
    } else {
      return res.status(403).json({ message: "Access denied. Admin only." });
    }
  } catch (error) {
    return res.status(500).json({ message: "Authentication failed" });
  }
};

module.exports = { authenticate: exports.authenticate, isAdmin };
