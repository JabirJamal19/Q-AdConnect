const hasRole = (allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res
        .status(401)
        .json({ status: 0, message: "Authentication required." });
    }

    const rolesToCheck = Array.isArray(allowedRoles)
      ? allowedRoles.map((r) => r.toLowerCase())
      : [allowedRoles.toLowerCase()];
    const userRole = req.user.role?.toLowerCase();

    if (userRole && rolesToCheck.includes(userRole)) {
      next(); // Role permitted
    } else {
      console.warn(
        `Role check failed: User ${req.user._id} with role '${
          req.user.role
        }' tried accessing route requiring [${rolesToCheck.join(", ")}].`
      );
      return res
        .status(403)
        .json({ status: 0, message: "Forbidden: Insufficient permissions." });
    }
  };
};

const isAgencyOrAdmin = hasRole(["agency", "admin"]);

module.exports = { hasRole, isAgencyOrAdmin };
